package androidx.tvprovider.media.tv;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import androidx.tvprovider.media.tv.TvContractCompat.PreviewProgramColumns;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public abstract class BasePreviewProgram extends BaseProgram {
    private static final int ASPECT_RATIO_UNKNOWN = -1;
    private static final int AVAILABILITY_UNKNOWN = -1;
    private static final int INTERACTION_TYPE_UNKNOWN = -1;
    private static final int INVALID_INT_VALUE = -1;
    private static final long INVALID_LONG_VALUE = -1;
    private static final int IS_BROWSABLE = 1;
    private static final int IS_LIVE = 1;
    private static final int IS_TRANSIENT = 1;
    public static final String[] PROJECTION = getProjection();
    private static final int TYPE_UNKNOWN = -1;

    @Retention(RetentionPolicy.SOURCE)
    public @interface AspectRatio {
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface Availability {
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface InteractionType {
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface TvSeriesItemType {
    }

    @Retention(RetentionPolicy.SOURCE)
    public @interface Type {
    }

    public static abstract class Builder<T extends Builder> extends androidx.tvprovider.media.tv.BaseProgram.Builder<T> {
        private static final SimpleDateFormat sFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

        static {
            sFormat.setTimeZone(TimeZone.getTimeZone("GMT-0"));
        }

        public Builder(BasePreviewProgram basePreviewProgram) {
            this.mValues = new ContentValues(basePreviewProgram.mValues);
        }

        public T setInternalProviderId(String str) {
            this.mValues.put("internal_provider_id", str);
            return this;
        }

        public T setPreviewVideoUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(PreviewProgramColumns.COLUMN_PREVIEW_VIDEO_URI, uri);
            return this;
        }

        public T setLastPlaybackPositionMillis(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_LAST_PLAYBACK_POSITION_MILLIS, Integer.valueOf(i));
            return this;
        }

        public T setDurationMillis(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_DURATION_MILLIS, Integer.valueOf(i));
            return this;
        }

        public T setIntentUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(PreviewProgramColumns.COLUMN_INTENT_URI, uri);
            return this;
        }

        public T setIntent(Intent intent) {
            return setIntentUri(Uri.parse(intent.toUri(1)));
        }

        public T setTransient(boolean z) {
            this.mValues.put("transient", Integer.valueOf(z));
            return this;
        }

        public T setType(int i) {
            this.mValues.put("type", Integer.valueOf(i));
            return this;
        }

        public T setPosterArtAspectRatio(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_POSTER_ART_ASPECT_RATIO, Integer.valueOf(i));
            return this;
        }

        public T setThumbnailAspectRatio(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_THUMBNAIL_ASPECT_RATIO, Integer.valueOf(i));
            return this;
        }

        public T setLogoUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(PreviewProgramColumns.COLUMN_LOGO_URI, uri);
            return this;
        }

        public T setAvailability(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_AVAILABILITY, Integer.valueOf(i));
            return this;
        }

        public T setStartingPrice(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_STARTING_PRICE, str);
            return this;
        }

        public T setOfferPrice(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_OFFER_PRICE, str);
            return this;
        }

        public T setReleaseDate(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_RELEASE_DATE, str);
            return this;
        }

        public T setReleaseDate(Date date) {
            this.mValues.put(PreviewProgramColumns.COLUMN_RELEASE_DATE, sFormat.format(date));
            return this;
        }

        public T setItemCount(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_ITEM_COUNT, Integer.valueOf(i));
            return this;
        }

        public T setLive(boolean z) {
            this.mValues.put("live", Integer.valueOf(z));
            return this;
        }

        public T setInteractionType(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_INTERACTION_TYPE, Integer.valueOf(i));
            return this;
        }

        public T setInteractionCount(long j) {
            this.mValues.put(PreviewProgramColumns.COLUMN_INTERACTION_COUNT, Long.valueOf(j));
            return this;
        }

        public T setAuthor(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_AUTHOR, str);
            return this;
        }

        public T setBrowsable(boolean z) {
            this.mValues.put("browsable", Integer.valueOf(z));
            return this;
        }

        public T setContentId(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_CONTENT_ID, str);
            return this;
        }

        public T setLogoContentDescription(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_LOGO_CONTENT_DESCRIPTION, str);
            return this;
        }

        public T setGenre(String str) {
            this.mValues.put(PreviewProgramColumns.COLUMN_GENRE, str);
            return this;
        }

        public T setStartTimeUtcMillis(long j) {
            this.mValues.put("start_time_utc_millis", Long.valueOf(j));
            return this;
        }

        public T setEndTimeUtcMillis(long j) {
            this.mValues.put("end_time_utc_millis", Long.valueOf(j));
            return this;
        }

        public T setPreviewAudioUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(PreviewProgramColumns.COLUMN_PREVIEW_AUDIO_URI, uri);
            return this;
        }

        public T setTvSeriesItemType(int i) {
            this.mValues.put(PreviewProgramColumns.COLUMN_TV_SERIES_ITEM_TYPE, Integer.valueOf(i));
            return this;
        }
    }

    BasePreviewProgram(Builder builder) {
        super(builder);
    }

    public String getInternalProviderId() {
        return this.mValues.getAsString("internal_provider_id");
    }

    public Uri getPreviewVideoUri() {
        String asString = this.mValues.getAsString(PreviewProgramColumns.COLUMN_PREVIEW_VIDEO_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public int getLastPlaybackPositionMillis() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_LAST_PLAYBACK_POSITION_MILLIS);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public int getDurationMillis() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_DURATION_MILLIS);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public Uri getIntentUri() {
        String asString = this.mValues.getAsString(PreviewProgramColumns.COLUMN_INTENT_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public Intent getIntent() throws URISyntaxException {
        String asString = this.mValues.getAsString(PreviewProgramColumns.COLUMN_INTENT_URI);
        if (asString == null) {
            return null;
        }
        return Intent.parseUri(asString, 1);
    }

    public boolean isTransient() {
        Integer asInteger = this.mValues.getAsInteger("transient");
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public int getType() {
        Integer asInteger = this.mValues.getAsInteger("type");
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public int getTvSeriesItemType() {
        return this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_TV_SERIES_ITEM_TYPE).intValue();
    }

    public int getPosterArtAspectRatio() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_POSTER_ART_ASPECT_RATIO);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public int getThumbnailAspectRatio() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_THUMBNAIL_ASPECT_RATIO);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public Uri getLogoUri() {
        String asString = this.mValues.getAsString(PreviewProgramColumns.COLUMN_LOGO_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public int getAvailability() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_AVAILABILITY);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public String getStartingPrice() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_STARTING_PRICE);
    }

    public String getOfferPrice() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_OFFER_PRICE);
    }

    public String getReleaseDate() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_RELEASE_DATE);
    }

    public int getItemCount() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_ITEM_COUNT);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public boolean isLive() {
        Integer asInteger = this.mValues.getAsInteger("live");
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public int getInteractionType() {
        Integer asInteger = this.mValues.getAsInteger(PreviewProgramColumns.COLUMN_INTERACTION_TYPE);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public long getInteractionCount() {
        Long asLong = this.mValues.getAsLong(PreviewProgramColumns.COLUMN_INTERACTION_COUNT);
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public String getAuthor() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_AUTHOR);
    }

    public boolean isBrowsable() {
        Integer asInteger = this.mValues.getAsInteger("browsable");
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public String getContentId() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_CONTENT_ID);
    }

    public String getLogoContentDescription() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_LOGO_CONTENT_DESCRIPTION);
    }

    public String getGenre() {
        return this.mValues.getAsString(PreviewProgramColumns.COLUMN_GENRE);
    }

    public long getStartTimeUtcMillis() {
        Long asLong = this.mValues.getAsLong("start_time_utc_millis");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public long getEndTimeUtcMillis() {
        Long asLong = this.mValues.getAsLong("end_time_utc_millis");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public Uri getPreviewAudioUri() {
        String asString = this.mValues.getAsString(PreviewProgramColumns.COLUMN_PREVIEW_AUDIO_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public boolean equals(Object obj) {
        if (obj instanceof BasePreviewProgram) {
            return this.mValues.equals(((BasePreviewProgram) obj).mValues);
        }
        return null;
    }

    public ContentValues toContentValues() {
        return toContentValues(false);
    }

    public ContentValues toContentValues(boolean z) {
        ContentValues toContentValues = super.toContentValues();
        if (VERSION.SDK_INT < 26) {
            toContentValues.remove("internal_provider_id");
            toContentValues.remove(PreviewProgramColumns.COLUMN_PREVIEW_VIDEO_URI);
            toContentValues.remove(PreviewProgramColumns.COLUMN_LAST_PLAYBACK_POSITION_MILLIS);
            toContentValues.remove(PreviewProgramColumns.COLUMN_DURATION_MILLIS);
            toContentValues.remove(PreviewProgramColumns.COLUMN_INTENT_URI);
            toContentValues.remove("transient");
            toContentValues.remove("type");
            toContentValues.remove(PreviewProgramColumns.COLUMN_POSTER_ART_ASPECT_RATIO);
            toContentValues.remove(PreviewProgramColumns.COLUMN_THUMBNAIL_ASPECT_RATIO);
            toContentValues.remove(PreviewProgramColumns.COLUMN_LOGO_URI);
            toContentValues.remove(PreviewProgramColumns.COLUMN_AVAILABILITY);
            toContentValues.remove(PreviewProgramColumns.COLUMN_STARTING_PRICE);
            toContentValues.remove(PreviewProgramColumns.COLUMN_OFFER_PRICE);
            toContentValues.remove(PreviewProgramColumns.COLUMN_RELEASE_DATE);
            toContentValues.remove(PreviewProgramColumns.COLUMN_ITEM_COUNT);
            toContentValues.remove("live");
            toContentValues.remove(PreviewProgramColumns.COLUMN_INTERACTION_COUNT);
            toContentValues.remove(PreviewProgramColumns.COLUMN_AUTHOR);
            toContentValues.remove(PreviewProgramColumns.COLUMN_CONTENT_ID);
            toContentValues.remove(PreviewProgramColumns.COLUMN_LOGO_CONTENT_DESCRIPTION);
            toContentValues.remove(PreviewProgramColumns.COLUMN_GENRE);
            toContentValues.remove("start_time_utc_millis");
            toContentValues.remove("end_time_utc_millis");
            toContentValues.remove(PreviewProgramColumns.COLUMN_PREVIEW_AUDIO_URI);
            toContentValues.remove(PreviewProgramColumns.COLUMN_TV_SERIES_ITEM_TYPE);
        }
        if (VERSION.SDK_INT < 26 || !z) {
            toContentValues.remove("browsable");
        }
        return toContentValues;
    }

    static void setFieldsFromCursor(Cursor cursor, Builder builder) {
        BaseProgram.setFieldsFromCursor(cursor, builder);
        if (VERSION.SDK_INT >= 26) {
            int columnIndex = cursor.getColumnIndex("internal_provider_id");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderId(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_PREVIEW_VIDEO_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setPreviewVideoUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_LAST_PLAYBACK_POSITION_MILLIS);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setLastPlaybackPositionMillis(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_DURATION_MILLIS);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setDurationMillis(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_INTENT_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setIntentUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex("transient");
            boolean z = false;
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setTransient(cursor.getInt(columnIndex) == 1);
            }
            columnIndex = cursor.getColumnIndex("type");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setType(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_POSTER_ART_ASPECT_RATIO);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setPosterArtAspectRatio(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_THUMBNAIL_ASPECT_RATIO);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setThumbnailAspectRatio(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_LOGO_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setLogoUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_AVAILABILITY);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAvailability(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_STARTING_PRICE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setStartingPrice(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_OFFER_PRICE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setOfferPrice(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_RELEASE_DATE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setReleaseDate(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_ITEM_COUNT);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setItemCount(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("live");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setLive(cursor.getInt(columnIndex) == 1);
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_INTERACTION_TYPE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInteractionType(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_INTERACTION_COUNT);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInteractionCount((long) cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_AUTHOR);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAuthor(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("browsable");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                if (cursor.getInt(columnIndex) == 1) {
                    z = true;
                }
                builder.setBrowsable(z);
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_CONTENT_ID);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setContentId(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_LOGO_CONTENT_DESCRIPTION);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setLogoContentDescription(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_GENRE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setGenre(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("start_time_utc_millis");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setStartTimeUtcMillis(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("end_time_utc_millis");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setEndTimeUtcMillis(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_PREVIEW_AUDIO_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setPreviewAudioUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex(PreviewProgramColumns.COLUMN_TV_SERIES_ITEM_TYPE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setTvSeriesItemType(cursor.getInt(columnIndex));
            }
        }
    }

    private static String[] getProjection() {
        String[] strArr = new String[]{"internal_provider_id", PreviewProgramColumns.COLUMN_PREVIEW_VIDEO_URI, PreviewProgramColumns.COLUMN_LAST_PLAYBACK_POSITION_MILLIS, PreviewProgramColumns.COLUMN_DURATION_MILLIS, PreviewProgramColumns.COLUMN_INTENT_URI, "transient", "type", PreviewProgramColumns.COLUMN_POSTER_ART_ASPECT_RATIO, PreviewProgramColumns.COLUMN_THUMBNAIL_ASPECT_RATIO, PreviewProgramColumns.COLUMN_LOGO_URI, PreviewProgramColumns.COLUMN_AVAILABILITY, PreviewProgramColumns.COLUMN_STARTING_PRICE, PreviewProgramColumns.COLUMN_OFFER_PRICE, PreviewProgramColumns.COLUMN_RELEASE_DATE, PreviewProgramColumns.COLUMN_ITEM_COUNT, "live", PreviewProgramColumns.COLUMN_INTERACTION_TYPE, PreviewProgramColumns.COLUMN_INTERACTION_COUNT, PreviewProgramColumns.COLUMN_AUTHOR, "browsable", PreviewProgramColumns.COLUMN_CONTENT_ID, PreviewProgramColumns.COLUMN_LOGO_CONTENT_DESCRIPTION, PreviewProgramColumns.COLUMN_GENRE, "start_time_utc_millis", "end_time_utc_millis", PreviewProgramColumns.COLUMN_PREVIEW_AUDIO_URI, PreviewProgramColumns.COLUMN_TV_SERIES_ITEM_TYPE};
        return (String[]) CollectionUtils.concatAll(BaseProgram.PROJECTION, strArr);
    }
}
