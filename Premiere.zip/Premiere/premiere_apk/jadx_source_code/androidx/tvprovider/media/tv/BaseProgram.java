package androidx.tvprovider.media.tv;

import android.content.ContentValues;
import android.database.Cursor;
import android.media.tv.TvContentRating;
import android.net.Uri;
import android.os.Build.VERSION;
import androidx.tvprovider.media.tv.TvContractCompat.BaseTvColumns;
import androidx.tvprovider.media.tv.TvContractCompat.Programs;
import androidx.tvprovider.media.tv.TvContractCompat.Programs.Genres;

public abstract class BaseProgram {
    private static final int INVALID_INT_VALUE = -1;
    private static final long INVALID_LONG_VALUE = -1;
    private static final int IS_SEARCHABLE = 1;
    public static final String[] PROJECTION = getProjection();
    private static final int REVIEW_RATING_STYLE_UNKNOWN = -1;
    protected ContentValues mValues;

    public static abstract class Builder<T extends Builder> {
        protected ContentValues mValues;

        public Builder() {
            this.mValues = new ContentValues();
        }

        public Builder(BaseProgram baseProgram) {
            this.mValues = new ContentValues(baseProgram.mValues);
        }

        public T setId(long j) {
            this.mValues.put("_id", Long.valueOf(j));
            return this;
        }

        public T setPackageName(String str) {
            this.mValues.put(BaseTvColumns.COLUMN_PACKAGE_NAME, str);
            return this;
        }

        public T setTitle(String str) {
            this.mValues.put("title", str);
            return this;
        }

        public T setEpisodeTitle(String str) {
            this.mValues.put(ProgramColumns.COLUMN_EPISODE_TITLE, str);
            return this;
        }

        public T setSeasonNumber(int i) {
            setSeasonNumber(String.valueOf(i), i);
            return this;
        }

        public T setSeasonNumber(String str, int i) {
            if (VERSION.SDK_INT >= 24) {
                this.mValues.put(ProgramColumns.COLUMN_SEASON_DISPLAY_NUMBER, str);
            } else {
                this.mValues.put(Programs.COLUMN_SEASON_NUMBER, Integer.valueOf(i));
            }
            return this;
        }

        public T setEpisodeNumber(int i) {
            setEpisodeNumber(String.valueOf(i), i);
            return this;
        }

        public T setEpisodeNumber(String str, int i) {
            if (VERSION.SDK_INT >= 24) {
                this.mValues.put(ProgramColumns.COLUMN_EPISODE_DISPLAY_NUMBER, str);
            } else {
                this.mValues.put(Programs.COLUMN_EPISODE_NUMBER, Integer.valueOf(i));
            }
            return this;
        }

        public T setDescription(String str) {
            this.mValues.put(ProgramColumns.COLUMN_SHORT_DESCRIPTION, str);
            return this;
        }

        public T setLongDescription(String str) {
            this.mValues.put(ProgramColumns.COLUMN_LONG_DESCRIPTION, str);
            return this;
        }

        public T setVideoWidth(int i) {
            this.mValues.put(ProgramColumns.COLUMN_VIDEO_WIDTH, Integer.valueOf(i));
            return this;
        }

        public T setVideoHeight(int i) {
            this.mValues.put(ProgramColumns.COLUMN_VIDEO_HEIGHT, Integer.valueOf(i));
            return this;
        }

        public T setContentRatings(TvContentRating[] tvContentRatingArr) {
            this.mValues.put(ProgramColumns.COLUMN_CONTENT_RATING, TvContractUtils.contentRatingsToString(tvContentRatingArr));
            return this;
        }

        public T setPosterArtUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(ProgramColumns.COLUMN_POSTER_ART_URI, uri);
            return this;
        }

        public T setThumbnailUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(ProgramColumns.COLUMN_THUMBNAIL_URI, uri);
            return this;
        }

        public T setCanonicalGenres(String[] strArr) {
            this.mValues.put("canonical_genre", Genres.encode(strArr));
            return this;
        }

        public T setInternalProviderData(byte[] bArr) {
            this.mValues.put("internal_provider_data", bArr);
            return this;
        }

        public T setAudioLanguages(String[] strArr) {
            this.mValues.put(ProgramColumns.COLUMN_AUDIO_LANGUAGE, TvContractUtils.audioLanguagesToString(strArr));
            return this;
        }

        public T setSearchable(boolean z) {
            this.mValues.put("searchable", Integer.valueOf(z));
            return this;
        }

        public T setInternalProviderFlag1(long j) {
            this.mValues.put("internal_provider_flag1", Long.valueOf(j));
            return this;
        }

        public T setInternalProviderFlag2(long j) {
            this.mValues.put("internal_provider_flag2", Long.valueOf(j));
            return this;
        }

        public T setInternalProviderFlag3(long j) {
            this.mValues.put("internal_provider_flag3", Long.valueOf(j));
            return this;
        }

        public T setInternalProviderFlag4(long j) {
            this.mValues.put("internal_provider_flag4", Long.valueOf(j));
            return this;
        }

        public T setReviewRatingStyle(int i) {
            this.mValues.put(ProgramColumns.COLUMN_REVIEW_RATING_STYLE, Integer.valueOf(i));
            return this;
        }

        public T setReviewRating(String str) {
            this.mValues.put(ProgramColumns.COLUMN_REVIEW_RATING, str);
            return this;
        }

        public T setSeasonTitle(String str) {
            this.mValues.put(ProgramColumns.COLUMN_SEASON_TITLE, str);
            return this;
        }
    }

    BaseProgram(Builder builder) {
        this.mValues = builder.mValues;
    }

    public long getId() {
        Long asLong = this.mValues.getAsLong("_id");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public String getPackageName() {
        return this.mValues.getAsString(BaseTvColumns.COLUMN_PACKAGE_NAME);
    }

    public String getTitle() {
        return this.mValues.getAsString("title");
    }

    public String getEpisodeTitle() {
        return this.mValues.getAsString(ProgramColumns.COLUMN_EPISODE_TITLE);
    }

    public String getSeasonNumber() {
        if (VERSION.SDK_INT >= 24) {
            return this.mValues.getAsString(ProgramColumns.COLUMN_SEASON_DISPLAY_NUMBER);
        }
        return this.mValues.getAsString(Programs.COLUMN_SEASON_NUMBER);
    }

    public String getEpisodeNumber() {
        if (VERSION.SDK_INT >= 24) {
            return this.mValues.getAsString(ProgramColumns.COLUMN_EPISODE_DISPLAY_NUMBER);
        }
        return this.mValues.getAsString(Programs.COLUMN_EPISODE_NUMBER);
    }

    public String getDescription() {
        return this.mValues.getAsString(ProgramColumns.COLUMN_SHORT_DESCRIPTION);
    }

    public String getLongDescription() {
        return this.mValues.getAsString(ProgramColumns.COLUMN_LONG_DESCRIPTION);
    }

    public int getVideoWidth() {
        Integer asInteger = this.mValues.getAsInteger(ProgramColumns.COLUMN_VIDEO_WIDTH);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public int getVideoHeight() {
        Integer asInteger = this.mValues.getAsInteger(ProgramColumns.COLUMN_VIDEO_HEIGHT);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public String[] getCanonicalGenres() {
        return Genres.decode(this.mValues.getAsString("canonical_genre"));
    }

    public TvContentRating[] getContentRatings() {
        return TvContractUtils.stringToContentRatings(this.mValues.getAsString(ProgramColumns.COLUMN_CONTENT_RATING));
    }

    public Uri getPosterArtUri() {
        String asString = this.mValues.getAsString(ProgramColumns.COLUMN_POSTER_ART_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public Uri getThumbnailUri() {
        String asString = this.mValues.getAsString(ProgramColumns.COLUMN_POSTER_ART_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public byte[] getInternalProviderDataByteArray() {
        return this.mValues.getAsByteArray("internal_provider_data");
    }

    public String[] getAudioLanguages() {
        return TvContractUtils.stringToAudioLanguages(this.mValues.getAsString(ProgramColumns.COLUMN_AUDIO_LANGUAGE));
    }

    public boolean isSearchable() {
        Integer asInteger = this.mValues.getAsInteger("searchable");
        if (asInteger == null) {
            return true;
        }
        if (asInteger.intValue() == 1) {
            return true;
        }
        return false;
    }

    public Long getInternalProviderFlag1() {
        return this.mValues.getAsLong("internal_provider_flag1");
    }

    public Long getInternalProviderFlag2() {
        return this.mValues.getAsLong("internal_provider_flag2");
    }

    public Long getInternalProviderFlag3() {
        return this.mValues.getAsLong("internal_provider_flag3");
    }

    public Long getInternalProviderFlag4() {
        return this.mValues.getAsLong("internal_provider_flag4");
    }

    public String getSeasonTitle() {
        return this.mValues.getAsString(ProgramColumns.COLUMN_SEASON_TITLE);
    }

    public int getReviewRatingStyle() {
        Integer asInteger = this.mValues.getAsInteger(ProgramColumns.COLUMN_REVIEW_RATING_STYLE);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public String getReviewRating() {
        return this.mValues.getAsString(ProgramColumns.COLUMN_REVIEW_RATING);
    }

    public int hashCode() {
        return this.mValues.hashCode();
    }

    public boolean equals(Object obj) {
        if (obj instanceof BaseProgram) {
            return this.mValues.equals(((BaseProgram) obj).mValues);
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("BaseProgram{");
        stringBuilder.append(this.mValues.toString());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public ContentValues toContentValues() {
        ContentValues contentValues = new ContentValues(this.mValues);
        if (VERSION.SDK_INT < 23) {
            contentValues.remove("searchable");
            contentValues.remove("internal_provider_flag1");
            contentValues.remove("internal_provider_flag2");
            contentValues.remove("internal_provider_flag3");
            contentValues.remove("internal_provider_flag4");
        }
        if (VERSION.SDK_INT < 24) {
            contentValues.remove(ProgramColumns.COLUMN_SEASON_TITLE);
        }
        if (VERSION.SDK_INT < 26) {
            contentValues.remove(ProgramColumns.COLUMN_REVIEW_RATING_STYLE);
            contentValues.remove(ProgramColumns.COLUMN_REVIEW_RATING);
        }
        return contentValues;
    }

    static void setFieldsFromCursor(Cursor cursor, Builder builder) {
        int columnIndex = cursor.getColumnIndex("_id");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setId(cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(BaseTvColumns.COLUMN_PACKAGE_NAME);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setPackageName(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("title");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setTitle(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_EPISODE_TITLE);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setEpisodeTitle(cursor.getString(columnIndex));
        }
        if (VERSION.SDK_INT >= 24) {
            columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_SEASON_DISPLAY_NUMBER);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setSeasonNumber(cursor.getString(columnIndex), -1);
            }
        } else {
            columnIndex = cursor.getColumnIndex(Programs.COLUMN_SEASON_NUMBER);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setSeasonNumber(cursor.getInt(columnIndex));
            }
        }
        if (VERSION.SDK_INT >= 24) {
            columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_EPISODE_DISPLAY_NUMBER);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setEpisodeNumber(cursor.getString(columnIndex), -1);
            }
        } else {
            columnIndex = cursor.getColumnIndex(Programs.COLUMN_EPISODE_NUMBER);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setEpisodeNumber(cursor.getInt(columnIndex));
            }
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_SHORT_DESCRIPTION);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setDescription(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_LONG_DESCRIPTION);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setLongDescription(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_POSTER_ART_URI);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setPosterArtUri(Uri.parse(cursor.getString(columnIndex)));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_THUMBNAIL_URI);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setThumbnailUri(Uri.parse(cursor.getString(columnIndex)));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_AUDIO_LANGUAGE);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setAudioLanguages(TvContractUtils.stringToAudioLanguages(cursor.getString(columnIndex)));
        }
        columnIndex = cursor.getColumnIndex("canonical_genre");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setCanonicalGenres(Genres.decode(cursor.getString(columnIndex)));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_CONTENT_RATING);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setContentRatings(TvContractUtils.stringToContentRatings(cursor.getString(columnIndex)));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_VIDEO_WIDTH);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setVideoWidth((int) cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_VIDEO_HEIGHT);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setVideoHeight((int) cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("internal_provider_data");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setInternalProviderData(cursor.getBlob(columnIndex));
        }
        if (VERSION.SDK_INT >= 23) {
            columnIndex = cursor.getColumnIndex("searchable");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                boolean z = true;
                if (cursor.getInt(columnIndex) != 1) {
                    z = false;
                }
                builder.setSearchable(z);
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag1");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag1(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag2");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag2(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag3");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag3(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag4");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag4(cursor.getLong(columnIndex));
            }
        }
        if (VERSION.SDK_INT >= 24) {
            columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_SEASON_TITLE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setSeasonTitle(cursor.getString(columnIndex));
            }
        }
        if (VERSION.SDK_INT >= 26) {
            columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_REVIEW_RATING_STYLE);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setReviewRatingStyle(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(ProgramColumns.COLUMN_REVIEW_RATING);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setReviewRating(cursor.getString(columnIndex));
            }
        }
    }

    private static String[] getProjection() {
        String[] strArr = new String[16];
        strArr[0] = "_id";
        strArr[1] = BaseTvColumns.COLUMN_PACKAGE_NAME;
        strArr[2] = "title";
        strArr[3] = ProgramColumns.COLUMN_EPISODE_TITLE;
        strArr[4] = VERSION.SDK_INT >= 24 ? ProgramColumns.COLUMN_SEASON_DISPLAY_NUMBER : Programs.COLUMN_SEASON_NUMBER;
        strArr[5] = VERSION.SDK_INT >= 24 ? ProgramColumns.COLUMN_EPISODE_DISPLAY_NUMBER : Programs.COLUMN_EPISODE_NUMBER;
        strArr[6] = ProgramColumns.COLUMN_SHORT_DESCRIPTION;
        strArr[7] = ProgramColumns.COLUMN_LONG_DESCRIPTION;
        strArr[8] = ProgramColumns.COLUMN_POSTER_ART_URI;
        strArr[9] = ProgramColumns.COLUMN_THUMBNAIL_URI;
        strArr[10] = ProgramColumns.COLUMN_AUDIO_LANGUAGE;
        strArr[11] = "canonical_genre";
        strArr[12] = ProgramColumns.COLUMN_CONTENT_RATING;
        strArr[13] = ProgramColumns.COLUMN_VIDEO_WIDTH;
        strArr[14] = ProgramColumns.COLUMN_VIDEO_HEIGHT;
        strArr[15] = "internal_provider_data";
        String[] strArr2 = new String[]{"searchable", "internal_provider_flag1", "internal_provider_flag2", "internal_provider_flag3", "internal_provider_flag4"};
        String[] strArr3 = new String[]{ProgramColumns.COLUMN_SEASON_TITLE};
        String[] strArr4 = new String[]{ProgramColumns.COLUMN_REVIEW_RATING, ProgramColumns.COLUMN_REVIEW_RATING_STYLE};
        if (VERSION.SDK_INT >= 26) {
            return (String[]) CollectionUtils.concatAll(strArr, strArr2, strArr3, strArr4);
        } else if (VERSION.SDK_INT >= 24) {
            return (String[]) CollectionUtils.concatAll(strArr, strArr2, strArr3);
        } else {
            if (VERSION.SDK_INT >= 23) {
                strArr = (String[]) CollectionUtils.concatAll(strArr, strArr2);
            }
            return strArr;
        }
    }
}
