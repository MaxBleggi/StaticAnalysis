package androidx.tvprovider.media.tv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.tv.TvContract;
import android.util.Log;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

public class ChannelLogoUtils {
    private static final int CONNECTION_TIMEOUT_MS_FOR_URLCONNECTION = 3000;
    private static final int READ_TIMEOUT_MS_FOR_URLCONNECTION = 10000;
    private static final String TAG = "ChannelLogoUtils";

    public static boolean storeChannelLogo(android.content.Context r1, long r2, android.net.Uri r4) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.DecodeException: Load method exception in method: androidx.tvprovider.media.tv.ChannelLogoUtils.storeChannelLogo(android.content.Context, long, android.net.Uri):boolean
	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:116)
	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:249)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
Caused by: java.lang.NullPointerException
	at jadx.core.dex.nodes.MethodNode.initTryCatches(MethodNode.java:305)
	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:105)
	... 5 more
*/
        /*
        r0 = r11.normalizeScheme();
        r0 = r0.getScheme();
        r1 = 0;
        r2 = "android.resource";
        r2 = r2.equals(r0);
        if (r2 != 0) goto L_0x003c;
        r2 = "file";
        r2 = r2.equals(r0);
        if (r2 != 0) goto L_0x003c;
        r2 = "content";
        r0 = r2.equals(r0);
        if (r0 == 0) goto L_0x0022;
        goto L_0x003c;
        r0 = r11.toString();
        r0 = getUrlConnection(r0);
        r2 = r0.getInputStream();
        r7 = r2;
        r2 = r0;
        r0 = r7;
        goto L_0x0045;
    L_0x0032:
        r8 = move-exception;
        r7 = r1;
        r1 = r0;
        r0 = r7;
        goto L_0x00a1;
    L_0x0038:
        r2 = move-exception;
        r3 = r0;
        r0 = r1;
        goto L_0x0068;
        r0 = r8.getContentResolver();
        r0 = r0.openInputStream(r11);
        r2 = r1;
        r1 = android.graphics.BitmapFactory.decodeStream(r0);
        if (r0 == 0) goto L_0x0050;
        r0.close();
        goto L_0x0050;
        r11 = r2 instanceof java.net.HttpURLConnection;
        if (r11 == 0) goto L_0x0093;
        r2 = (java.net.HttpURLConnection) r2;
        r2.disconnect();
        goto L_0x0093;
    L_0x005a:
        r8 = move-exception;
        r1 = r2;
        goto L_0x00a1;
    L_0x005d:
        r3 = move-exception;
        r7 = r3;
        r3 = r2;
        r2 = r7;
        goto L_0x0068;
    L_0x0062:
        r8 = move-exception;
        r0 = r1;
        goto L_0x00a1;
    L_0x0065:
        r2 = move-exception;
        r0 = r1;
        r3 = r0;
        r4 = "ChannelLogoUtils";
        r5 = new java.lang.StringBuilder;
        r5.<init>();
        r6 = "Failed to get logo from the URI: ";
        r5.append(r6);
        r5.append(r11);
        r11 = "\n";
        r5.append(r11);
        r11 = r5.toString();
        android.util.Log.i(r4, r11, r2);
        if (r0 == 0) goto L_0x008a;
        r0.close();
        goto L_0x008a;
        r11 = r3 instanceof java.net.HttpURLConnection;
        if (r11 == 0) goto L_0x0093;
        r3 = (java.net.HttpURLConnection) r3;
        r3.disconnect();
        if (r1 == 0) goto L_0x009d;
        r8 = storeChannelLogo(r8, r9, r1);
        if (r8 == 0) goto L_0x009d;
        r8 = 1;
        goto L_0x009e;
        r8 = 0;
        return r8;
        r8 = move-exception;
        r1 = r3;
        if (r0 == 0) goto L_0x00a8;
        r0.close();
        goto L_0x00a8;
        r9 = r1 instanceof java.net.HttpURLConnection;
        if (r9 == 0) goto L_0x00b1;
        r1 = (java.net.HttpURLConnection) r1;
        r1.disconnect();
        throw r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.tvprovider.media.tv.ChannelLogoUtils.storeChannelLogo(android.content.Context, long, android.net.Uri):boolean");
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean storeChannelLogo(android.content.Context r1, long r2, android.graphics.Bitmap r4) {
        /*
        r2 = android.media.tv.TvContract.buildChannelLogoUri(r2);
        r3 = 0;
        r1 = r1.getContentResolver();	 Catch:{ SQLiteException -> 0x002e, IOException -> 0x002c }
        r1 = r1.openOutputStream(r2);	 Catch:{ SQLiteException -> 0x002e, IOException -> 0x002c }
        r2 = android.graphics.Bitmap.CompressFormat.PNG;	 Catch:{ all -> 0x001e }
        r0 = 100;
        r3 = r4.compress(r2, r0, r1);	 Catch:{ all -> 0x001e }
        r1.flush();	 Catch:{ all -> 0x001e }
        if (r1 == 0) goto L_0x0036;
    L_0x001a:
        r1.close();	 Catch:{ SQLiteException -> 0x002e, IOException -> 0x002c }
        goto L_0x0036;
    L_0x001e:
        r2 = move-exception;
        throw r2;	 Catch:{ all -> 0x0020 }
    L_0x0020:
        r4 = move-exception;
        if (r1 == 0) goto L_0x002b;
    L_0x0023:
        r1.close();	 Catch:{ all -> 0x0027 }
        goto L_0x002b;
    L_0x0027:
        r1 = move-exception;
        r2.addSuppressed(r1);	 Catch:{ SQLiteException -> 0x002e, IOException -> 0x002c }
    L_0x002b:
        throw r4;	 Catch:{ SQLiteException -> 0x002e, IOException -> 0x002c }
    L_0x002c:
        r1 = move-exception;
        goto L_0x002f;
    L_0x002e:
        r1 = move-exception;
    L_0x002f:
        r2 = "ChannelLogoUtils";
        r4 = "Failed to store the logo to the system content provider.\n";
        android.util.Log.i(r2, r4, r1);
    L_0x0036:
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.tvprovider.media.tv.ChannelLogoUtils.storeChannelLogo(android.content.Context, long, android.graphics.Bitmap):boolean");
    }

    public static Bitmap loadChannelLogo(Context context, long j) {
        try {
            return BitmapFactory.decodeStream(context.getContentResolver().openInputStream(TvContract.buildChannelLogoUri(j)));
        } catch (Context context2) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Channel logo for channel (ID:");
            stringBuilder.append(j);
            stringBuilder.append(") not found.");
            Log.i(TAG, stringBuilder.toString(), context2);
            return null;
        }
    }

    private static URLConnection getUrlConnection(String str) throws IOException {
        str = new URL(str).openConnection();
        str.setConnectTimeout(3000);
        str.setReadTimeout(10000);
        return str;
    }
}
