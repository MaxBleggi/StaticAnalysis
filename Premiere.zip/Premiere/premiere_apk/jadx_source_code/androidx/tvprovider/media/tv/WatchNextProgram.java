package androidx.tvprovider.media.tv;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Build.VERSION;
import androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Objects;

public final class WatchNextProgram extends BasePreviewProgram {
    private static final int INVALID_INT_VALUE = -1;
    private static final long INVALID_LONG_VALUE = -1;
    public static final String[] PROJECTION = getProjection();
    public static final int WATCH_NEXT_TYPE_UNKNOWN = -1;

    @Retention(RetentionPolicy.SOURCE)
    public @interface WatchNextType {
    }

    public static final class Builder extends androidx.tvprovider.media.tv.BasePreviewProgram.Builder<Builder> {
        public Builder(WatchNextProgram watchNextProgram) {
            this.mValues = new ContentValues(watchNextProgram.mValues);
        }

        public Builder setWatchNextType(int i) {
            this.mValues.put(WatchNextPrograms.COLUMN_WATCH_NEXT_TYPE, Integer.valueOf(i));
            return this;
        }

        public Builder setLastEngagementTimeUtcMillis(long j) {
            this.mValues.put(WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS, Long.valueOf(j));
            return this;
        }

        public WatchNextProgram build() {
            return new WatchNextProgram(this);
        }
    }

    WatchNextProgram(Builder builder) {
        super(builder);
    }

    public int getWatchNextType() {
        Integer asInteger = this.mValues.getAsInteger(WatchNextPrograms.COLUMN_WATCH_NEXT_TYPE);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public long getLastEngagementTimeUtcMillis() {
        Long asLong = this.mValues.getAsLong(WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS);
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public boolean equals(Object obj) {
        if (obj instanceof WatchNextProgram) {
            return this.mValues.equals(((WatchNextProgram) obj).mValues);
        }
        return null;
    }

    public boolean hasAnyUpdatedValues(WatchNextProgram watchNextProgram) {
        for (String str : watchNextProgram.mValues.keySet()) {
            if (!Objects.deepEquals(watchNextProgram.mValues.get(str), this.mValues.get(str))) {
                return true;
            }
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("WatchNextProgram{");
        stringBuilder.append(this.mValues.toString());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public ContentValues toContentValues() {
        return toContentValues(false);
    }

    public ContentValues toContentValues(boolean z) {
        z = super.toContentValues(z);
        if (VERSION.SDK_INT < 26) {
            z.remove(WatchNextPrograms.COLUMN_WATCH_NEXT_TYPE);
            z.remove(WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS);
        }
        return z;
    }

    public static WatchNextProgram fromCursor(Cursor cursor) {
        androidx.tvprovider.media.tv.BasePreviewProgram.Builder builder = new Builder();
        BasePreviewProgram.setFieldsFromCursor(cursor, builder);
        int columnIndex = cursor.getColumnIndex(WatchNextPrograms.COLUMN_WATCH_NEXT_TYPE);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setWatchNextType(cursor.getInt(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setLastEngagementTimeUtcMillis(cursor.getLong(columnIndex));
        }
        return builder.build();
    }

    private static String[] getProjection() {
        String[] strArr = new String[]{WatchNextPrograms.COLUMN_WATCH_NEXT_TYPE, WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS};
        return (String[]) CollectionUtils.concatAll(BasePreviewProgram.PROJECTION, strArr);
    }
}
