package androidx.tvprovider.media.tv;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Build.VERSION;
import androidx.tvprovider.media.tv.TvContractCompat.Programs;
import androidx.tvprovider.media.tv.TvContractCompat.Programs.Genres;

public final class Program extends BaseProgram implements Comparable<Program> {
    private static final long INVALID_LONG_VALUE = -1;
    private static final int IS_RECORDING_PROHIBITED = 1;
    public static final String[] PROJECTION = getProjection();

    public static class Builder extends androidx.tvprovider.media.tv.BaseProgram.Builder<Builder> {
        public Builder(Program program) {
            this.mValues = new ContentValues(program.mValues);
        }

        public Builder setChannelId(long j) {
            this.mValues.put("channel_id", Long.valueOf(j));
            return this;
        }

        public Builder setStartTimeUtcMillis(long j) {
            this.mValues.put("start_time_utc_millis", Long.valueOf(j));
            return this;
        }

        public Builder setEndTimeUtcMillis(long j) {
            this.mValues.put("end_time_utc_millis", Long.valueOf(j));
            return this;
        }

        public Builder setBroadcastGenres(String[] strArr) {
            this.mValues.put("broadcast_genre", Genres.encode(strArr));
            return this;
        }

        public Builder setRecordingProhibited(boolean z) {
            this.mValues.put(Programs.COLUMN_RECORDING_PROHIBITED, Integer.valueOf(z));
            return this;
        }

        public Program build() {
            return new Program(this);
        }
    }

    Program(Builder builder) {
        super(builder);
    }

    public long getChannelId() {
        Long asLong = this.mValues.getAsLong("channel_id");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public long getStartTimeUtcMillis() {
        Long asLong = this.mValues.getAsLong("start_time_utc_millis");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public long getEndTimeUtcMillis() {
        Long asLong = this.mValues.getAsLong("end_time_utc_millis");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public String[] getBroadcastGenres() {
        return Genres.decode(this.mValues.getAsString("broadcast_genre"));
    }

    public boolean isRecordingProhibited() {
        Integer asInteger = this.mValues.getAsInteger(Programs.COLUMN_RECORDING_PROHIBITED);
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.mValues.hashCode();
    }

    public boolean equals(Object obj) {
        if (obj instanceof Program) {
            return this.mValues.equals(((Program) obj).mValues);
        }
        return null;
    }

    public int compareTo(Program program) {
        String str = "start_time_utc_millis";
        return Long.compare(this.mValues.getAsLong(str).longValue(), program.mValues.getAsLong(str).longValue());
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Program{");
        stringBuilder.append(this.mValues.toString());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public ContentValues toContentValues() {
        ContentValues toContentValues = super.toContentValues();
        if (VERSION.SDK_INT < 24) {
            toContentValues.remove(Programs.COLUMN_RECORDING_PROHIBITED);
        }
        return toContentValues;
    }

    public static Program fromCursor(Cursor cursor) {
        androidx.tvprovider.media.tv.BaseProgram.Builder builder = new Builder();
        BaseProgram.setFieldsFromCursor(cursor, builder);
        int columnIndex = cursor.getColumnIndex("channel_id");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setChannelId(cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("broadcast_genre");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setBroadcastGenres(Genres.decode(cursor.getString(columnIndex)));
        }
        columnIndex = cursor.getColumnIndex("start_time_utc_millis");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setStartTimeUtcMillis(cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("end_time_utc_millis");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setEndTimeUtcMillis(cursor.getLong(columnIndex));
        }
        if (VERSION.SDK_INT >= 24) {
            columnIndex = cursor.getColumnIndex(Programs.COLUMN_RECORDING_PROHIBITED);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                cursor = cursor.getInt(columnIndex);
                boolean z = true;
                if (cursor != 1) {
                    z = false;
                }
                builder.setRecordingProhibited(z);
            }
        }
        return builder.build();
    }

    private static String[] getProjection() {
        String[] strArr = new String[]{"channel_id", "broadcast_genre", "start_time_utc_millis", "end_time_utc_millis"};
        String[] strArr2 = new String[]{Programs.COLUMN_RECORDING_PROHIBITED};
        if (VERSION.SDK_INT >= 24) {
            return (String[]) CollectionUtils.concatAll(BaseProgram.PROJECTION, strArr, strArr2);
        }
        return (String[]) CollectionUtils.concatAll(BaseProgram.PROJECTION, strArr);
    }
}
