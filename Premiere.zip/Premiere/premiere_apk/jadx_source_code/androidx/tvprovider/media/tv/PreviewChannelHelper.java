package androidx.tvprovider.media.tv;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import androidx.tvprovider.media.tv.PreviewChannel.Columns;
import androidx.tvprovider.media.tv.TvContractCompat.Channels;
import androidx.tvprovider.media.tv.TvContractCompat.PreviewPrograms;
import androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PreviewChannelHelper {
    private static final int DEFAULT_READ_TIMEOUT_MILLIS = 10000;
    private static final int DEFAULT_URL_CONNNECTION_TIMEOUT_MILLIS = 3000;
    private static final int INVALID_CONTENT_ID = -1;
    private static final String TAG = "PreviewChannelHelper";
    private final Context mContext;
    private final int mUrlConnectionTimeoutMillis;
    private final int mUrlReadTimeoutMillis;

    protected android.graphics.Bitmap downloadBitmap(android.net.Uri r1) throws java.io.IOException {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.DecodeException: Load method exception in method: androidx.tvprovider.media.tv.PreviewChannelHelper.downloadBitmap(android.net.Uri):android.graphics.Bitmap
	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:116)
	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:249)
	at jadx.core.ProcessClass.process(ProcessClass.java:34)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
Caused by: java.lang.NullPointerException
	at jadx.core.dex.nodes.MethodNode.initTryCatches(MethodNode.java:305)
	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:105)
	... 5 more
*/
        /*
        r0 = this;
        r0 = 0;
        r1 = new java.net.URL;
        r3 = r3.toString();
        r1.<init>(r3);
        r3 = r1.openConnection();
        r1 = r2.mUrlConnectionTimeoutMillis;
        r3.setConnectTimeout(r1);
        r1 = r2.mUrlReadTimeoutMillis;
        r3.setReadTimeout(r1);
        r0 = r3.getInputStream();
        r1 = android.graphics.BitmapFactory.decodeStream(r0);
        if (r0 == 0) goto L_0x0027;
        r0.close();
        goto L_0x0027;
        r0 = r3 instanceof java.net.HttpURLConnection;
        if (r0 == 0) goto L_0x0030;
        r3 = (java.net.HttpURLConnection) r3;
        r3.disconnect();
        return r1;
    L_0x0031:
        r1 = move-exception;
        goto L_0x0035;
    L_0x0033:
        r1 = move-exception;
        r3 = r0;
        if (r0 == 0) goto L_0x003c;
        r0.close();
        goto L_0x003c;
        r0 = r3 instanceof java.net.HttpURLConnection;
        if (r0 == 0) goto L_0x0045;
        r3 = (java.net.HttpURLConnection) r3;
        r3.disconnect();
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.tvprovider.media.tv.PreviewChannelHelper.downloadBitmap(android.net.Uri):android.graphics.Bitmap");
    }

    public PreviewChannelHelper(Context context) {
        this(context, 3000, 10000);
    }

    public PreviewChannelHelper(Context context, int i, int i2) {
        this.mContext = context;
        this.mUrlConnectionTimeoutMillis = i;
        this.mUrlReadTimeoutMillis = i2;
    }

    public long publishChannel(PreviewChannel previewChannel) throws IOException {
        try {
            Uri insert = this.mContext.getContentResolver().insert(Channels.CONTENT_URI, previewChannel.toContentValues());
            if (insert == null || insert.equals(Uri.EMPTY)) {
                throw new NullPointerException("Channel insertion failed");
            }
            long parseId = ContentUris.parseId(insert);
            if (addChannelLogo(parseId, previewChannel) != null) {
                return parseId;
            }
            deletePreviewChannel(parseId);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failed to add logo, so channel (ID=");
            stringBuilder.append(parseId);
            stringBuilder.append(") was not created");
            throw new IOException(stringBuilder.toString());
        } catch (PreviewChannel previewChannel2) {
            Log.e(TAG, "Your app's ability to insert data into the TvProvider may have been revoked.", previewChannel2);
            return -1;
        }
    }

    public long publishDefaultChannel(PreviewChannel previewChannel) throws IOException {
        long publishChannel = publishChannel(previewChannel);
        TvContractCompat.requestChannelBrowsable(this.mContext, publishChannel);
        return publishChannel;
    }

    public List<PreviewChannel> getAllChannels() {
        Cursor query = this.mContext.getContentResolver().query(Channels.CONTENT_URI, Columns.PROJECTION, null, null, null);
        List<PreviewChannel> arrayList = new ArrayList();
        if (query == null || !query.moveToFirst()) {
            return arrayList;
        }
        do {
            arrayList.add(PreviewChannel.fromCursor(query));
        } while (query.moveToNext());
        return arrayList;
    }

    public PreviewChannel getPreviewChannel(long j) {
        j = this.mContext.getContentResolver().query(TvContractCompat.buildChannelUri(j), Columns.PROJECTION, null, null, null);
        return (j == null || !j.moveToFirst()) ? 0 : PreviewChannel.fromCursor(j);
    }

    public void updatePreviewChannel(long j, PreviewChannel previewChannel) throws IOException {
        PreviewChannel previewChannel2 = getPreviewChannel(j);
        if (previewChannel2 != null && previewChannel2.hasAnyUpdatedValues(previewChannel)) {
            updatePreviewChannelInternal(j, previewChannel);
        }
        if (!previewChannel.isLogoChanged()) {
            return;
        }
        if (addChannelLogo(j, previewChannel) == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Fail to update channel (ID=");
            stringBuilder.append(j);
            stringBuilder.append(") logo.");
            throw new IOException(stringBuilder.toString());
        }
    }

    protected void updatePreviewChannelInternal(long j, PreviewChannel previewChannel) {
        this.mContext.getContentResolver().update(TvContractCompat.buildChannelUri(j), previewChannel.toContentValues(), null, null);
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean addChannelLogo(long r5, androidx.tvprovider.media.tv.PreviewChannel r7) {
        /*
        r4 = this;
        r0 = r7.isLogoChanged();
        r1 = 0;
        if (r0 != 0) goto L_0x0008;
    L_0x0007:
        return r1;
    L_0x0008:
        r0 = r4.mContext;
        r0 = r7.getLogo(r0);
        if (r0 != 0) goto L_0x0018;
    L_0x0010:
        r7 = r7.getLogoUri();
        r0 = r4.getLogoFromUri(r7);
    L_0x0018:
        r7 = androidx.tvprovider.media.tv.TvContractCompat.buildChannelLogoUri(r5);
        r2 = r4.mContext;	 Catch:{ SQLiteException -> 0x0049, IOException -> 0x0047, NullPointerException -> 0x0045 }
        r2 = r2.getContentResolver();	 Catch:{ SQLiteException -> 0x0049, IOException -> 0x0047, NullPointerException -> 0x0045 }
        r7 = r2.openOutputStream(r7);	 Catch:{ SQLiteException -> 0x0049, IOException -> 0x0047, NullPointerException -> 0x0045 }
        r2 = android.graphics.Bitmap.CompressFormat.PNG;	 Catch:{ all -> 0x0037 }
        r3 = 100;
        r1 = r0.compress(r2, r3, r7);	 Catch:{ all -> 0x0037 }
        r7.flush();	 Catch:{ all -> 0x0037 }
        if (r7 == 0) goto L_0x0065;
    L_0x0033:
        r7.close();	 Catch:{ SQLiteException -> 0x0049, IOException -> 0x0047, NullPointerException -> 0x0045 }
        goto L_0x0065;
    L_0x0037:
        r0 = move-exception;
        throw r0;	 Catch:{ all -> 0x0039 }
    L_0x0039:
        r2 = move-exception;
        if (r7 == 0) goto L_0x0044;
    L_0x003c:
        r7.close();	 Catch:{ all -> 0x0040 }
        goto L_0x0044;
    L_0x0040:
        r7 = move-exception;
        r0.addSuppressed(r7);	 Catch:{ SQLiteException -> 0x0049, IOException -> 0x0047, NullPointerException -> 0x0045 }
    L_0x0044:
        throw r2;	 Catch:{ SQLiteException -> 0x0049, IOException -> 0x0047, NullPointerException -> 0x0045 }
    L_0x0045:
        r7 = move-exception;
        goto L_0x004a;
    L_0x0047:
        r7 = move-exception;
        goto L_0x004a;
    L_0x0049:
        r7 = move-exception;
    L_0x004a:
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r2 = "Failed to add logo to the published channel (ID= ";
        r0.append(r2);
        r0.append(r5);
        r5 = ")";
        r0.append(r5);
        r5 = r0.toString();
        r6 = "PreviewChannelHelper";
        android.util.Log.i(r6, r5, r7);
    L_0x0065:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.tvprovider.media.tv.PreviewChannelHelper.addChannelLogo(long, androidx.tvprovider.media.tv.PreviewChannel):boolean");
    }

    private android.graphics.Bitmap getLogoFromUri(android.net.Uri r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r7 = this;
        r0 = r8.normalizeScheme();
        r0 = r0.getScheme();
        r1 = 0;
        r2 = "android.resource";	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r2 = r2.equals(r0);	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        if (r2 != 0) goto L_0x0028;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
    L_0x0011:
        r2 = "file";	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r2 = r2.equals(r0);	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        if (r2 != 0) goto L_0x0028;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
    L_0x0019:
        r2 = "content";	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r0 = r2.equals(r0);	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        if (r0 == 0) goto L_0x0022;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
    L_0x0021:
        goto L_0x0028;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
    L_0x0022:
        r8 = r7.downloadBitmap(r8);	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r0 = r1;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        goto L_0x0036;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
    L_0x0028:
        r0 = r7.mContext;	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r0 = r0.getContentResolver();	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r0 = r0.openInputStream(r8);	 Catch:{ IOException -> 0x0047, all -> 0x0045 }
        r8 = android.graphics.BitmapFactory.decodeStream(r0);	 Catch:{ IOException -> 0x0040, all -> 0x003d }
    L_0x0036:
        r1 = r8;
        if (r0 == 0) goto L_0x0064;
    L_0x0039:
        r0.close();	 Catch:{ IOException -> 0x0064 }
        goto L_0x0064;
    L_0x003d:
        r8 = move-exception;
        r1 = r0;
        goto L_0x0067;
    L_0x0040:
        r2 = move-exception;
        r6 = r2;
        r2 = r0;
        r0 = r6;
        goto L_0x0049;
    L_0x0045:
        r8 = move-exception;
        goto L_0x0067;
    L_0x0047:
        r0 = move-exception;
        r2 = r1;
    L_0x0049:
        r3 = "PreviewChannelHelper";	 Catch:{ all -> 0x0065 }
        r4 = new java.lang.StringBuilder;	 Catch:{ all -> 0x0065 }
        r4.<init>();	 Catch:{ all -> 0x0065 }
        r5 = "Failed to get logo from the URI: ";	 Catch:{ all -> 0x0065 }
        r4.append(r5);	 Catch:{ all -> 0x0065 }
        r4.append(r8);	 Catch:{ all -> 0x0065 }
        r8 = r4.toString();	 Catch:{ all -> 0x0065 }
        android.util.Log.e(r3, r8, r0);	 Catch:{ all -> 0x0065 }
        if (r2 == 0) goto L_0x0064;
    L_0x0061:
        r2.close();	 Catch:{ IOException -> 0x0064 }
    L_0x0064:
        return r1;
    L_0x0065:
        r8 = move-exception;
        r1 = r2;
    L_0x0067:
        if (r1 == 0) goto L_0x006c;
    L_0x0069:
        r1.close();	 Catch:{ IOException -> 0x006c }
    L_0x006c:
        throw r8;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.tvprovider.media.tv.PreviewChannelHelper.getLogoFromUri(android.net.Uri):android.graphics.Bitmap");
    }

    public void deletePreviewChannel(long j) {
        this.mContext.getContentResolver().delete(TvContractCompat.buildChannelUri(j), null, null);
    }

    public long publishPreviewProgram(PreviewProgram previewProgram) {
        try {
            return ContentUris.parseId(this.mContext.getContentResolver().insert(PreviewPrograms.CONTENT_URI, previewProgram.toContentValues()));
        } catch (PreviewProgram previewProgram2) {
            Log.e(TAG, "Your app's ability to insert data into the TvProvider may have been revoked.", previewProgram2);
            return -1;
        }
    }

    public PreviewProgram getPreviewProgram(long j) {
        j = this.mContext.getContentResolver().query(TvContractCompat.buildPreviewProgramUri(j), null, null, null, null);
        return (j == null || !j.moveToFirst()) ? 0 : PreviewProgram.fromCursor(j);
    }

    public void updatePreviewProgram(long j, PreviewProgram previewProgram) {
        PreviewProgram previewProgram2 = getPreviewProgram(j);
        if (previewProgram2 != null && previewProgram2.hasAnyUpdatedValues(previewProgram)) {
            updatePreviewProgramInternal(j, previewProgram);
        }
    }

    void updatePreviewProgramInternal(long j, PreviewProgram previewProgram) {
        this.mContext.getContentResolver().update(TvContractCompat.buildPreviewProgramUri(j), previewProgram.toContentValues(), null, null);
    }

    public void deletePreviewProgram(long j) {
        this.mContext.getContentResolver().delete(TvContractCompat.buildPreviewProgramUri(j), null, null);
    }

    public long publishWatchNextProgram(WatchNextProgram watchNextProgram) {
        try {
            return ContentUris.parseId(this.mContext.getContentResolver().insert(WatchNextPrograms.CONTENT_URI, watchNextProgram.toContentValues()));
        } catch (WatchNextProgram watchNextProgram2) {
            Log.e(TAG, "Your app's ability to insert data into the TvProvider may have been revoked.", watchNextProgram2);
            return -1;
        }
    }

    public WatchNextProgram getWatchNextProgram(long j) {
        j = this.mContext.getContentResolver().query(TvContractCompat.buildWatchNextProgramUri(j), null, null, null, null);
        return (j == null || !j.moveToFirst()) ? 0 : WatchNextProgram.fromCursor(j);
    }

    public void updateWatchNextProgram(WatchNextProgram watchNextProgram, long j) {
        WatchNextProgram watchNextProgram2 = getWatchNextProgram(j);
        if (watchNextProgram2 != null && watchNextProgram2.hasAnyUpdatedValues(watchNextProgram)) {
            updateWatchNextProgram(j, watchNextProgram);
        }
    }

    void updateWatchNextProgram(long j, WatchNextProgram watchNextProgram) {
        this.mContext.getContentResolver().update(TvContractCompat.buildWatchNextProgramUri(j), watchNextProgram.toContentValues(), null, null);
    }
}
