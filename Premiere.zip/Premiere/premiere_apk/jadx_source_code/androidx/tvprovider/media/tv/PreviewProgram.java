package androidx.tvprovider.media.tv;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Build.VERSION;
import androidx.tvprovider.media.tv.TvContractCompat.PreviewPrograms;
import java.util.Objects;

public final class PreviewProgram extends BasePreviewProgram {
    private static final int INVALID_INT_VALUE = -1;
    private static final long INVALID_LONG_VALUE = -1;
    public static final String[] PROJECTION = getProjection();

    public static final class Builder extends androidx.tvprovider.media.tv.BasePreviewProgram.Builder<Builder> {
        public Builder(PreviewProgram previewProgram) {
            this.mValues = new ContentValues(previewProgram.mValues);
        }

        public Builder setChannelId(long j) {
            this.mValues.put("channel_id", Long.valueOf(j));
            return this;
        }

        public Builder setWeight(int i) {
            this.mValues.put(PreviewPrograms.COLUMN_WEIGHT, Integer.valueOf(i));
            return this;
        }

        public PreviewProgram build() {
            return new PreviewProgram(this);
        }
    }

    PreviewProgram(Builder builder) {
        super(builder);
    }

    public long getChannelId() {
        Long asLong = this.mValues.getAsLong("channel_id");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public int getWeight() {
        Integer asInteger = this.mValues.getAsInteger(PreviewPrograms.COLUMN_WEIGHT);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public boolean equals(Object obj) {
        if (obj instanceof PreviewProgram) {
            return this.mValues.equals(((PreviewProgram) obj).mValues);
        }
        return null;
    }

    public boolean hasAnyUpdatedValues(PreviewProgram previewProgram) {
        for (String str : previewProgram.mValues.keySet()) {
            if (!Objects.deepEquals(previewProgram.mValues.get(str), this.mValues.get(str))) {
                return true;
            }
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("PreviewProgram{");
        stringBuilder.append(this.mValues.toString());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public ContentValues toContentValues() {
        return toContentValues(false);
    }

    public ContentValues toContentValues(boolean z) {
        z = super.toContentValues(z);
        if (VERSION.SDK_INT < 26) {
            z.remove("channel_id");
            z.remove(PreviewPrograms.COLUMN_WEIGHT);
        }
        return z;
    }

    public static PreviewProgram fromCursor(Cursor cursor) {
        androidx.tvprovider.media.tv.BasePreviewProgram.Builder builder = new Builder();
        BasePreviewProgram.setFieldsFromCursor(cursor, builder);
        int columnIndex = cursor.getColumnIndex("channel_id");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setChannelId(cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(PreviewPrograms.COLUMN_WEIGHT);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setWeight(cursor.getInt(columnIndex));
        }
        return builder.build();
    }

    private static String[] getProjection() {
        String[] strArr = new String[]{"channel_id", PreviewPrograms.COLUMN_WEIGHT};
        return (String[]) CollectionUtils.concatAll(BasePreviewProgram.PROJECTION, strArr);
    }
}
