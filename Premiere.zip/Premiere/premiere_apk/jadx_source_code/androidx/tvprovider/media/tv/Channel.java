package androidx.tvprovider.media.tv;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import androidx.tvprovider.media.tv.TvContractCompat.BaseTvColumns;
import androidx.tvprovider.media.tv.TvContractCompat.Channels;
import java.net.URISyntaxException;
import java.nio.charset.Charset;

public final class Channel {
    private static final long INVALID_CHANNEL_ID = -1;
    private static final int INVALID_INT_VALUE = -1;
    private static final int IS_BROWSABLE = 1;
    private static final int IS_LOCKED = 1;
    private static final int IS_SEARCHABLE = 1;
    private static final int IS_SYSTEM_APPROVED = 1;
    private static final int IS_TRANSIENT = 1;
    public static final String[] PROJECTION = getProjection();
    ContentValues mValues;

    public static final class Builder {
        ContentValues mValues;

        public Builder() {
            this.mValues = new ContentValues();
        }

        public Builder(Channel channel) {
            this.mValues = new ContentValues(channel.mValues);
        }

        Builder setId(long j) {
            this.mValues.put("_id", Long.valueOf(j));
            return this;
        }

        Builder setPackageName(String str) {
            this.mValues.put(BaseTvColumns.COLUMN_PACKAGE_NAME, str);
            return this;
        }

        public Builder setInputId(String str) {
            this.mValues.put("input_id", str);
            return this;
        }

        public Builder setType(String str) {
            this.mValues.put("type", str);
            return this;
        }

        public Builder setDisplayNumber(String str) {
            this.mValues.put(Channels.COLUMN_DISPLAY_NUMBER, str);
            return this;
        }

        public Builder setDisplayName(String str) {
            this.mValues.put(Channels.COLUMN_DISPLAY_NAME, str);
            return this;
        }

        public Builder setDescription(String str) {
            this.mValues.put(Channels.COLUMN_DESCRIPTION, str);
            return this;
        }

        public Builder setVideoFormat(String str) {
            this.mValues.put(Channels.COLUMN_VIDEO_FORMAT, str);
            return this;
        }

        public Builder setOriginalNetworkId(int i) {
            this.mValues.put(Channels.COLUMN_ORIGINAL_NETWORK_ID, Integer.valueOf(i));
            return this;
        }

        public Builder setTransportStreamId(int i) {
            this.mValues.put(Channels.COLUMN_TRANSPORT_STREAM_ID, Integer.valueOf(i));
            return this;
        }

        public Builder setServiceId(int i) {
            this.mValues.put(Channels.COLUMN_SERVICE_ID, Integer.valueOf(i));
            return this;
        }

        public Builder setInternalProviderData(byte[] bArr) {
            this.mValues.put("internal_provider_data", bArr);
            return this;
        }

        public Builder setInternalProviderData(String str) {
            this.mValues.put("internal_provider_data", str.getBytes(Charset.defaultCharset()));
            return this;
        }

        public Builder setAppLinkText(String str) {
            this.mValues.put(Channels.COLUMN_APP_LINK_TEXT, str);
            return this;
        }

        public Builder setAppLinkColor(int i) {
            this.mValues.put(Channels.COLUMN_APP_LINK_COLOR, Integer.valueOf(i));
            return this;
        }

        public Builder setAppLinkIconUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(Channels.COLUMN_APP_LINK_ICON_URI, uri);
            return this;
        }

        public Builder setAppLinkPosterArtUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(Channels.COLUMN_APP_LINK_POSTER_ART_URI, uri);
            return this;
        }

        public Builder setAppLinkIntent(Intent intent) {
            return setAppLinkIntentUri(Uri.parse(intent.toUri(1)));
        }

        public Builder setAppLinkIntentUri(Uri uri) {
            ContentValues contentValues = this.mValues;
            if (uri == null) {
                uri = null;
            } else {
                uri = uri.toString();
            }
            contentValues.put(Channels.COLUMN_APP_LINK_INTENT_URI, uri);
            return this;
        }

        public Builder setNetworkAffiliation(String str) {
            this.mValues.put(Channels.COLUMN_NETWORK_AFFILIATION, str);
            return this;
        }

        public Builder setSearchable(boolean z) {
            this.mValues.put("searchable", Integer.valueOf(z));
            return this;
        }

        public Builder setServiceType(String str) {
            this.mValues.put(Channels.COLUMN_SERVICE_TYPE, str);
            return this;
        }

        public Builder setInternalProviderFlag1(long j) {
            this.mValues.put("internal_provider_flag1", Long.valueOf(j));
            return this;
        }

        public Builder setInternalProviderFlag2(long j) {
            this.mValues.put("internal_provider_flag2", Long.valueOf(j));
            return this;
        }

        public Builder setInternalProviderFlag3(long j) {
            this.mValues.put("internal_provider_flag3", Long.valueOf(j));
            return this;
        }

        public Builder setInternalProviderFlag4(long j) {
            this.mValues.put("internal_provider_flag4", Long.valueOf(j));
            return this;
        }

        public Builder setInternalProviderId(String str) {
            this.mValues.put("internal_provider_id", str);
            return this;
        }

        public Builder setTransient(boolean z) {
            this.mValues.put("transient", Integer.valueOf(z));
            return this;
        }

        public Builder setBrowsable(boolean z) {
            this.mValues.put("browsable", Integer.valueOf(z));
            return this;
        }

        public Builder setSystemApproved(boolean z) {
            this.mValues.put(Channels.COLUMN_SYSTEM_APPROVED, Integer.valueOf(z));
            return this;
        }

        public Builder setConfigurationDisplayOrder(int i) {
            this.mValues.put(Channels.COLUMN_CONFIGURATION_DISPLAY_ORDER, Integer.valueOf(i));
            return this;
        }

        public Builder setSystemChannelKey(String str) {
            this.mValues.put(Channels.COLUMN_SYSTEM_CHANNEL_KEY, str);
            return this;
        }

        public Builder setLocked(boolean z) {
            this.mValues.put(Channels.COLUMN_LOCKED, Integer.valueOf(z));
            return this;
        }

        public Channel build() {
            return new Channel(this);
        }
    }

    Channel(Builder builder) {
        this.mValues = builder.mValues;
    }

    public long getId() {
        Long asLong = this.mValues.getAsLong("_id");
        if (asLong == null) {
            return -1;
        }
        return asLong.longValue();
    }

    public String getPackageName() {
        return this.mValues.getAsString(BaseTvColumns.COLUMN_PACKAGE_NAME);
    }

    public String getInputId() {
        return this.mValues.getAsString("input_id");
    }

    public String getType() {
        return this.mValues.getAsString("type");
    }

    public String getDisplayNumber() {
        return this.mValues.getAsString(Channels.COLUMN_DISPLAY_NUMBER);
    }

    public String getDisplayName() {
        return this.mValues.getAsString(Channels.COLUMN_DISPLAY_NAME);
    }

    public String getDescription() {
        return this.mValues.getAsString(Channels.COLUMN_DESCRIPTION);
    }

    public String getVideoFormat() {
        return this.mValues.getAsString(Channels.COLUMN_VIDEO_FORMAT);
    }

    public int getOriginalNetworkId() {
        Integer asInteger = this.mValues.getAsInteger(Channels.COLUMN_ORIGINAL_NETWORK_ID);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public int getTransportStreamId() {
        Integer asInteger = this.mValues.getAsInteger(Channels.COLUMN_TRANSPORT_STREAM_ID);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public int getServiceId() {
        Integer asInteger = this.mValues.getAsInteger(Channels.COLUMN_SERVICE_ID);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public String getAppLinkText() {
        return this.mValues.getAsString(Channels.COLUMN_APP_LINK_TEXT);
    }

    public int getAppLinkColor() {
        Integer asInteger = this.mValues.getAsInteger(Channels.COLUMN_APP_LINK_COLOR);
        if (asInteger == null) {
            return -1;
        }
        return asInteger.intValue();
    }

    public Uri getAppLinkIconUri() {
        String asString = this.mValues.getAsString(Channels.COLUMN_APP_LINK_ICON_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public Uri getAppLinkPosterArtUri() {
        String asString = this.mValues.getAsString(Channels.COLUMN_APP_LINK_POSTER_ART_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public Uri getAppLinkIntentUri() {
        String asString = this.mValues.getAsString(Channels.COLUMN_APP_LINK_INTENT_URI);
        if (asString == null) {
            return null;
        }
        return Uri.parse(asString);
    }

    public Intent getAppLinkIntent() throws URISyntaxException {
        String asString = this.mValues.getAsString(Channels.COLUMN_APP_LINK_INTENT_URI);
        if (asString == null) {
            return null;
        }
        return Intent.parseUri(asString.toString(), 1);
    }

    public String getNetworkAffiliation() {
        return this.mValues.getAsString(Channels.COLUMN_NETWORK_AFFILIATION);
    }

    public boolean isSearchable() {
        Integer asInteger = this.mValues.getAsInteger("searchable");
        if (asInteger == null) {
            return true;
        }
        if (asInteger.intValue() == 1) {
            return true;
        }
        return false;
    }

    public byte[] getInternalProviderDataByteArray() {
        return this.mValues.getAsByteArray("internal_provider_data");
    }

    public String getServiceType() {
        return this.mValues.getAsString(Channels.COLUMN_SERVICE_TYPE);
    }

    public Long getInternalProviderFlag1() {
        return this.mValues.getAsLong("internal_provider_flag1");
    }

    public Long getInternalProviderFlag2() {
        return this.mValues.getAsLong("internal_provider_flag2");
    }

    public Long getInternalProviderFlag3() {
        return this.mValues.getAsLong("internal_provider_flag3");
    }

    public Long getInternalProviderFlag4() {
        return this.mValues.getAsLong("internal_provider_flag4");
    }

    public String getInternalProviderId() {
        return this.mValues.getAsString("internal_provider_id");
    }

    public boolean isTransient() {
        Integer asInteger = this.mValues.getAsInteger("transient");
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public boolean isBrowsable() {
        Integer asInteger = this.mValues.getAsInteger("browsable");
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public boolean isSystemApproved() {
        Integer asInteger = this.mValues.getAsInteger(Channels.COLUMN_SYSTEM_APPROVED);
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public int getConfigurationDisplayOrder() {
        return this.mValues.getAsInteger(Channels.COLUMN_CONFIGURATION_DISPLAY_ORDER).intValue();
    }

    public String getSystemChannelKey() {
        return this.mValues.getAsString(Channels.COLUMN_SYSTEM_CHANNEL_KEY);
    }

    public boolean isLocked() {
        Integer asInteger = this.mValues.getAsInteger(Channels.COLUMN_LOCKED);
        if (asInteger == null || asInteger.intValue() != 1) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.mValues.hashCode();
    }

    public boolean equals(Object obj) {
        if (obj instanceof Channel) {
            return this.mValues.equals(((Channel) obj).mValues);
        }
        return null;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Channel{");
        stringBuilder.append(this.mValues.toString());
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    public ContentValues toContentValues() {
        return toContentValues(false);
    }

    public ContentValues toContentValues(boolean z) {
        ContentValues contentValues = new ContentValues(this.mValues);
        if (VERSION.SDK_INT < 23) {
            contentValues.remove(Channels.COLUMN_APP_LINK_COLOR);
            contentValues.remove(Channels.COLUMN_APP_LINK_TEXT);
            contentValues.remove(Channels.COLUMN_APP_LINK_ICON_URI);
            contentValues.remove(Channels.COLUMN_APP_LINK_POSTER_ART_URI);
            contentValues.remove(Channels.COLUMN_APP_LINK_INTENT_URI);
            contentValues.remove("internal_provider_flag1");
            contentValues.remove("internal_provider_flag2");
            contentValues.remove("internal_provider_flag3");
            contentValues.remove("internal_provider_flag4");
        }
        if (VERSION.SDK_INT < 26) {
            contentValues.remove("internal_provider_id");
            contentValues.remove("transient");
            contentValues.remove(Channels.COLUMN_CONFIGURATION_DISPLAY_ORDER);
            contentValues.remove(Channels.COLUMN_SYSTEM_CHANNEL_KEY);
        }
        if (!z) {
            contentValues.remove("browsable");
            contentValues.remove(Channels.COLUMN_LOCKED);
        }
        if (VERSION.SDK_INT < 26 || !z) {
            contentValues.remove(Channels.COLUMN_SYSTEM_APPROVED);
        }
        return contentValues;
    }

    public static Channel fromCursor(Cursor cursor) {
        Builder builder = new Builder();
        int columnIndex = cursor.getColumnIndex("_id");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setId(cursor.getLong(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_DESCRIPTION);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setDescription(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_DISPLAY_NAME);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setDisplayName(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_DISPLAY_NUMBER);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setDisplayNumber(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("input_id");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setInputId(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("internal_provider_data");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setInternalProviderData(cursor.getBlob(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_NETWORK_AFFILIATION);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setNetworkAffiliation(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_ORIGINAL_NETWORK_ID);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setOriginalNetworkId(cursor.getInt(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(BaseTvColumns.COLUMN_PACKAGE_NAME);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setPackageName(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("searchable");
        boolean z = false;
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setSearchable(cursor.getInt(columnIndex) == 1);
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_SERVICE_ID);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setServiceId(cursor.getInt(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_SERVICE_TYPE);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setServiceType(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_TRANSPORT_STREAM_ID);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setTransportStreamId(cursor.getInt(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("type");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setType(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_VIDEO_FORMAT);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setVideoFormat(cursor.getString(columnIndex));
        }
        columnIndex = cursor.getColumnIndex("browsable");
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setBrowsable(cursor.getInt(columnIndex) == 1);
        }
        columnIndex = cursor.getColumnIndex(Channels.COLUMN_LOCKED);
        if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
            builder.setLocked(cursor.getInt(columnIndex) == 1);
        }
        if (VERSION.SDK_INT >= 23) {
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_APP_LINK_COLOR);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAppLinkColor(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_APP_LINK_ICON_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAppLinkIconUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_APP_LINK_INTENT_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAppLinkIntentUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_APP_LINK_POSTER_ART_URI);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAppLinkPosterArtUri(Uri.parse(cursor.getString(columnIndex)));
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_APP_LINK_TEXT);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setAppLinkText(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag1");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag1(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag2");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag2(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag3");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag3(cursor.getLong(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("internal_provider_flag4");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderFlag4(cursor.getLong(columnIndex));
            }
        }
        if (VERSION.SDK_INT >= 26) {
            columnIndex = cursor.getColumnIndex("internal_provider_id");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setInternalProviderId(cursor.getString(columnIndex));
            }
            columnIndex = cursor.getColumnIndex("transient");
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setTransient(cursor.getInt(columnIndex) == 1);
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_SYSTEM_APPROVED);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                if (cursor.getInt(columnIndex) == 1) {
                    z = true;
                }
                builder.setSystemApproved(z);
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_CONFIGURATION_DISPLAY_ORDER);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setConfigurationDisplayOrder(cursor.getInt(columnIndex));
            }
            columnIndex = cursor.getColumnIndex(Channels.COLUMN_SYSTEM_CHANNEL_KEY);
            if (columnIndex >= 0 && !cursor.isNull(columnIndex)) {
                builder.setSystemChannelKey(cursor.getString(columnIndex));
            }
        }
        return builder.build();
    }

    private static String[] getProjection() {
        String[] strArr = new String[]{"_id", Channels.COLUMN_DESCRIPTION, Channels.COLUMN_DISPLAY_NAME, Channels.COLUMN_DISPLAY_NUMBER, "input_id", "internal_provider_data", Channels.COLUMN_NETWORK_AFFILIATION, Channels.COLUMN_ORIGINAL_NETWORK_ID, BaseTvColumns.COLUMN_PACKAGE_NAME, "searchable", Channels.COLUMN_SERVICE_ID, Channels.COLUMN_SERVICE_TYPE, Channels.COLUMN_TRANSPORT_STREAM_ID, "type", Channels.COLUMN_VIDEO_FORMAT, "browsable", Channels.COLUMN_LOCKED};
        String[] strArr2 = new String[]{Channels.COLUMN_APP_LINK_COLOR, Channels.COLUMN_APP_LINK_ICON_URI, Channels.COLUMN_APP_LINK_INTENT_URI, Channels.COLUMN_APP_LINK_POSTER_ART_URI, Channels.COLUMN_APP_LINK_TEXT, "internal_provider_flag1", "internal_provider_flag2", "internal_provider_flag3", "internal_provider_flag4"};
        String[] strArr3 = new String[]{"internal_provider_id", "transient", Channels.COLUMN_SYSTEM_APPROVED, Channels.COLUMN_CONFIGURATION_DISPLAY_ORDER, Channels.COLUMN_SYSTEM_CHANNEL_KEY};
        if (VERSION.SDK_INT >= 26) {
            return (String[]) CollectionUtils.concatAll(strArr, strArr2, strArr3);
        }
        if (VERSION.SDK_INT >= 23) {
            strArr = (String[]) CollectionUtils.concatAll(strArr, strArr2);
        }
        return strArr;
    }
}
