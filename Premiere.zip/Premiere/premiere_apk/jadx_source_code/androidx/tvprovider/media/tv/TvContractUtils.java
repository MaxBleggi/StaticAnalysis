package androidx.tvprovider.media.tv;

import android.media.tv.TvContentRating;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;

public class TvContractUtils {
    private static final boolean DEBUG = false;
    private static final String DELIMITER = ",";
    static final TvContentRating[] EMPTY = new TvContentRating[0];
    private static final String TAG = "TvContractUtils";

    public static TvContentRating[] stringToContentRatings(String str) {
        if (TextUtils.isEmpty(str)) {
            return EMPTY;
        }
        str = str.split("\\s*,\\s*", -1);
        List arrayList = new ArrayList(str.length);
        for (String str2 : str) {
            try {
                arrayList.add(TvContentRating.unflattenFromString(str2));
            } catch (Throwable e) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Can't parse the content rating: '");
                stringBuilder.append(str2);
                stringBuilder.append("', skipping");
                Log.w(TAG, stringBuilder.toString(), e);
            }
        }
        if (arrayList.size() == null) {
            str = EMPTY;
        } else {
            str = (TvContentRating[]) arrayList.toArray(new TvContentRating[arrayList.size()]);
        }
        return str;
    }

    public static String contentRatingsToString(TvContentRating[] tvContentRatingArr) {
        if (tvContentRatingArr != null) {
            if (tvContentRatingArr.length != 0) {
                StringBuilder stringBuilder = new StringBuilder(tvContentRatingArr[0].flattenToString());
                for (int i = 1; i < tvContentRatingArr.length; i++) {
                    stringBuilder.append(DELIMITER);
                    stringBuilder.append(tvContentRatingArr[i].flattenToString());
                }
                return stringBuilder.toString();
            }
        }
        return null;
    }

    public static String[] stringToAudioLanguages(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        return str.split("\\s*,\\s*");
    }

    public static String audioLanguagesToString(String[] strArr) {
        if (strArr != null) {
            if (strArr.length != 0) {
                StringBuilder stringBuilder = new StringBuilder(strArr[0]);
                for (int i = 1; i < strArr.length; i++) {
                    stringBuilder.append(DELIMITER);
                    stringBuilder.append(strArr[i]);
                }
                return stringBuilder.toString();
            }
        }
        return null;
    }

    private TvContractUtils() {
    }
}
