package androidx.core.provider;

import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ProviderInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.CancellationSignal;
import android.os.Handler;
import android.provider.BaseColumns;
import androidx.collection.LruCache;
import androidx.collection.SimpleArrayMap;
import androidx.core.content.res.FontResourcesParserCompat;
import androidx.core.graphics.TypefaceCompat;
import androidx.core.graphics.TypefaceCompatUtil;
import androidx.core.provider.SelfDestructiveThread.ReplyCallback;
import androidx.core.util.Preconditions;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FontsContractCompat {
    private static final int BACKGROUND_THREAD_KEEP_ALIVE_DURATION_MS = 10000;
    public static final String PARCEL_FONT_RESULTS = "font_results";
    static final int RESULT_CODE_PROVIDER_NOT_FOUND = -1;
    static final int RESULT_CODE_WRONG_CERTIFICATES = -2;
    private static final String TAG = "FontsContractCompat";
    private static final SelfDestructiveThread sBackgroundThread = new SelfDestructiveThread("fonts", 10, 10000);
    private static final Comparator<byte[]> sByteArrayComparator = new Comparator<byte[]>() {
        public int compare(byte[] bArr, byte[] bArr2) {
            if (bArr.length != bArr2.length) {
                bArr = bArr.length;
                bArr2 = bArr2.length;
            } else {
                int i = 0;
                while (i < bArr.length) {
                    if (bArr[i] != bArr2[i]) {
                        bArr = bArr[i];
                        bArr2 = bArr2[i];
                    } else {
                        i++;
                    }
                }
                return 0;
            }
            return bArr - bArr2;
        }
    };
    static final Object sLock = new Object();
    static final SimpleArrayMap<String, ArrayList<ReplyCallback<TypefaceResult>>> sPendingReplies = new SimpleArrayMap();
    static final LruCache<String, Typeface> sTypefaceCache = new LruCache(16);

    public static final class Columns implements BaseColumns {
        public static final String FILE_ID = "file_id";
        public static final String ITALIC = "font_italic";
        public static final String RESULT_CODE = "result_code";
        public static final int RESULT_CODE_FONT_NOT_FOUND = 1;
        public static final int RESULT_CODE_FONT_UNAVAILABLE = 2;
        public static final int RESULT_CODE_MALFORMED_QUERY = 3;
        public static final int RESULT_CODE_OK = 0;
        public static final String TTC_INDEX = "font_ttc_index";
        public static final String VARIATION_SETTINGS = "font_variation_settings";
        public static final String WEIGHT = "font_weight";
    }

    public static class FontFamilyResult {
        public static final int STATUS_OK = 0;
        public static final int STATUS_UNEXPECTED_DATA_PROVIDED = 2;
        public static final int STATUS_WRONG_CERTIFICATES = 1;
        private final FontInfo[] mFonts;
        private final int mStatusCode;

        public FontFamilyResult(int i, FontInfo[] fontInfoArr) {
            this.mStatusCode = i;
            this.mFonts = fontInfoArr;
        }

        public int getStatusCode() {
            return this.mStatusCode;
        }

        public FontInfo[] getFonts() {
            return this.mFonts;
        }
    }

    public static class FontInfo {
        private final boolean mItalic;
        private final int mResultCode;
        private final int mTtcIndex;
        private final Uri mUri;
        private final int mWeight;

        public FontInfo(Uri uri, int i, int i2, boolean z, int i3) {
            this.mUri = (Uri) Preconditions.checkNotNull(uri);
            this.mTtcIndex = i;
            this.mWeight = i2;
            this.mItalic = z;
            this.mResultCode = i3;
        }

        public Uri getUri() {
            return this.mUri;
        }

        public int getTtcIndex() {
            return this.mTtcIndex;
        }

        public int getWeight() {
            return this.mWeight;
        }

        public boolean isItalic() {
            return this.mItalic;
        }

        public int getResultCode() {
            return this.mResultCode;
        }
    }

    public static class FontRequestCallback {
        public static final int FAIL_REASON_FONT_LOAD_ERROR = -3;
        public static final int FAIL_REASON_FONT_NOT_FOUND = 1;
        public static final int FAIL_REASON_FONT_UNAVAILABLE = 2;
        public static final int FAIL_REASON_MALFORMED_QUERY = 3;
        public static final int FAIL_REASON_PROVIDER_NOT_FOUND = -1;
        public static final int FAIL_REASON_SECURITY_VIOLATION = -4;
        public static final int FAIL_REASON_WRONG_CERTIFICATES = -2;
        public static final int RESULT_OK = 0;

        @Retention(RetentionPolicy.SOURCE)
        public @interface FontRequestFailReason {
        }

        public void onTypefaceRequestFailed(int i) {
        }

        public void onTypefaceRetrieved(Typeface typeface) {
        }
    }

    private static final class TypefaceResult {
        final int mResult;
        final Typeface mTypeface;

        TypefaceResult(Typeface typeface, int i) {
            this.mTypeface = typeface;
            this.mResult = i;
        }
    }

    private FontsContractCompat() {
    }

    static androidx.core.provider.FontsContractCompat.TypefaceResult getFontInternal(android.content.Context r3, androidx.core.provider.FontRequest r4, int r5) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = 0;
        r4 = fetchFonts(r3, r0, r4);	 Catch:{ NameNotFoundException -> 0x002b }
        r1 = r4.getStatusCode();
        r2 = -3;
        if (r1 != 0) goto L_0x001d;
    L_0x000c:
        r4 = r4.getFonts();
        r3 = androidx.core.graphics.TypefaceCompat.createFromFontInfo(r3, r0, r4, r5);
        r4 = new androidx.core.provider.FontsContractCompat$TypefaceResult;
        if (r3 == 0) goto L_0x0019;
    L_0x0018:
        r2 = 0;
    L_0x0019:
        r4.<init>(r3, r2);
        return r4;
    L_0x001d:
        r3 = r4.getStatusCode();
        r4 = 1;
        if (r3 != r4) goto L_0x0025;
    L_0x0024:
        r2 = -2;
    L_0x0025:
        r3 = new androidx.core.provider.FontsContractCompat$TypefaceResult;
        r3.<init>(r0, r2);
        return r3;
    L_0x002b:
        r3 = new androidx.core.provider.FontsContractCompat$TypefaceResult;
        r4 = -1;
        r3.<init>(r0, r4);
        return r3;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.provider.FontsContractCompat.getFontInternal(android.content.Context, androidx.core.provider.FontRequest, int):androidx.core.provider.FontsContractCompat$TypefaceResult");
    }

    public static void resetCache() {
        sTypefaceCache.evictAll();
    }

    public static android.graphics.Typeface getFontSync(final android.content.Context r2, final androidx.core.provider.FontRequest r3, final androidx.core.content.res.ResourcesCompat.FontCallback r4, final android.os.Handler r5, boolean r6, int r7, final int r8) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = new java.lang.StringBuilder;
        r0.<init>();
        r1 = r3.getIdentifier();
        r0.append(r1);
        r1 = "-";
        r0.append(r1);
        r0.append(r8);
        r0 = r0.toString();
        r1 = sTypefaceCache;
        r1 = r1.get(r0);
        r1 = (android.graphics.Typeface) r1;
        if (r1 == 0) goto L_0x0028;
    L_0x0022:
        if (r4 == 0) goto L_0x0027;
    L_0x0024:
        r4.onFontRetrieved(r1);
    L_0x0027:
        return r1;
    L_0x0028:
        if (r6 == 0) goto L_0x0045;
    L_0x002a:
        r1 = -1;
        if (r7 != r1) goto L_0x0045;
    L_0x002d:
        r2 = getFontInternal(r2, r3, r8);
        if (r4 == 0) goto L_0x0042;
    L_0x0033:
        r3 = r2.mResult;
        if (r3 != 0) goto L_0x003d;
    L_0x0037:
        r3 = r2.mTypeface;
        r4.callbackSuccessAsync(r3, r5);
        goto L_0x0042;
    L_0x003d:
        r3 = r2.mResult;
        r4.callbackFailAsync(r3, r5);
    L_0x0042:
        r2 = r2.mTypeface;
        return r2;
    L_0x0045:
        r1 = new androidx.core.provider.FontsContractCompat$1;
        r1.<init>(r2, r3, r8, r0);
        r2 = 0;
        if (r6 == 0) goto L_0x0058;
    L_0x004d:
        r3 = sBackgroundThread;	 Catch:{ InterruptedException -> 0x0057 }
        r3 = r3.postAndWait(r1, r7);	 Catch:{ InterruptedException -> 0x0057 }
        r3 = (androidx.core.provider.FontsContractCompat.TypefaceResult) r3;	 Catch:{ InterruptedException -> 0x0057 }
        r2 = r3.mTypeface;	 Catch:{ InterruptedException -> 0x0057 }
    L_0x0057:
        return r2;
    L_0x0058:
        if (r4 != 0) goto L_0x005c;
    L_0x005a:
        r3 = r2;
        goto L_0x0061;
    L_0x005c:
        r3 = new androidx.core.provider.FontsContractCompat$2;
        r3.<init>(r4, r5);
    L_0x0061:
        r4 = sLock;
        monitor-enter(r4);
        r5 = sPendingReplies;	 Catch:{ all -> 0x0096 }
        r5 = r5.containsKey(r0);	 Catch:{ all -> 0x0096 }
        if (r5 == 0) goto L_0x007b;	 Catch:{ all -> 0x0096 }
    L_0x006c:
        if (r3 == 0) goto L_0x0079;	 Catch:{ all -> 0x0096 }
    L_0x006e:
        r5 = sPendingReplies;	 Catch:{ all -> 0x0096 }
        r5 = r5.get(r0);	 Catch:{ all -> 0x0096 }
        r5 = (java.util.ArrayList) r5;	 Catch:{ all -> 0x0096 }
        r5.add(r3);	 Catch:{ all -> 0x0096 }
    L_0x0079:
        monitor-exit(r4);	 Catch:{ all -> 0x0096 }
        return r2;	 Catch:{ all -> 0x0096 }
    L_0x007b:
        if (r3 == 0) goto L_0x008a;	 Catch:{ all -> 0x0096 }
    L_0x007d:
        r5 = new java.util.ArrayList;	 Catch:{ all -> 0x0096 }
        r5.<init>();	 Catch:{ all -> 0x0096 }
        r5.add(r3);	 Catch:{ all -> 0x0096 }
        r3 = sPendingReplies;	 Catch:{ all -> 0x0096 }
        r3.put(r0, r5);	 Catch:{ all -> 0x0096 }
    L_0x008a:
        monitor-exit(r4);	 Catch:{ all -> 0x0096 }
        r3 = sBackgroundThread;
        r4 = new androidx.core.provider.FontsContractCompat$3;
        r4.<init>(r0);
        r3.postAndReply(r1, r4);
        return r2;
    L_0x0096:
        r2 = move-exception;
        monitor-exit(r4);	 Catch:{ all -> 0x0096 }
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.provider.FontsContractCompat.getFontSync(android.content.Context, androidx.core.provider.FontRequest, androidx.core.content.res.ResourcesCompat$FontCallback, android.os.Handler, boolean, int, int):android.graphics.Typeface");
    }

    public static void requestFont(final Context context, final FontRequest fontRequest, final FontRequestCallback fontRequestCallback, Handler handler) {
        final Handler handler2 = new Handler();
        handler.post(new Runnable() {
            public void run() {
                /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:14)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
                /*
                r6 = this;
                r0 = r2;	 Catch:{ NameNotFoundException -> 0x0098 }
                r1 = r3;	 Catch:{ NameNotFoundException -> 0x0098 }
                r2 = 0;	 Catch:{ NameNotFoundException -> 0x0098 }
                r0 = androidx.core.provider.FontsContractCompat.fetchFonts(r0, r2, r1);	 Catch:{ NameNotFoundException -> 0x0098 }
                r1 = r0.getStatusCode();
                if (r1 == 0) goto L_0x003a;
            L_0x000f:
                r0 = r0.getStatusCode();
                r1 = 1;
                if (r0 == r1) goto L_0x002f;
            L_0x0016:
                r1 = 2;
                if (r0 == r1) goto L_0x0024;
            L_0x0019:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$4;
                r1.<init>();
                r0.post(r1);
                return;
            L_0x0024:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$3;
                r1.<init>();
                r0.post(r1);
                return;
            L_0x002f:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$2;
                r1.<init>();
                r0.post(r1);
                return;
            L_0x003a:
                r0 = r0.getFonts();
                if (r0 == 0) goto L_0x008d;
            L_0x0040:
                r1 = r0.length;
                if (r1 != 0) goto L_0x0044;
            L_0x0043:
                goto L_0x008d;
            L_0x0044:
                r1 = r0.length;
                r3 = 0;
            L_0x0046:
                if (r3 >= r1) goto L_0x006f;
            L_0x0048:
                r4 = r0[r3];
                r5 = r4.getResultCode();
                if (r5 == 0) goto L_0x006c;
            L_0x0050:
                r0 = r4.getResultCode();
                if (r0 >= 0) goto L_0x0061;
            L_0x0056:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$6;
                r1.<init>();
                r0.post(r1);
                goto L_0x006b;
            L_0x0061:
                r1 = r0;
                r2 = new androidx.core.provider.FontsContractCompat$4$7;
                r2.<init>(r0);
                r1.post(r2);
            L_0x006b:
                return;
            L_0x006c:
                r3 = r3 + 1;
                goto L_0x0046;
            L_0x006f:
                r1 = r2;
                r0 = androidx.core.provider.FontsContractCompat.buildTypeface(r1, r2, r0);
                if (r0 != 0) goto L_0x0082;
            L_0x0077:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$8;
                r1.<init>();
                r0.post(r1);
                return;
            L_0x0082:
                r1 = r0;
                r2 = new androidx.core.provider.FontsContractCompat$4$9;
                r2.<init>(r0);
                r1.post(r2);
                return;
            L_0x008d:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$5;
                r1.<init>();
                r0.post(r1);
                return;
            L_0x0098:
                r0 = r0;
                r1 = new androidx.core.provider.FontsContractCompat$4$1;
                r1.<init>();
                r0.post(r1);
                return;
                */
                throw new UnsupportedOperationException("Method not decompiled: androidx.core.provider.FontsContractCompat.4.run():void");
            }
        });
    }

    public static Typeface buildTypeface(Context context, CancellationSignal cancellationSignal, FontInfo[] fontInfoArr) {
        return TypefaceCompat.createFromFontInfo(context, cancellationSignal, fontInfoArr, 0);
    }

    public static Map<Uri, ByteBuffer> prepareFontData(Context context, FontInfo[] fontInfoArr, CancellationSignal cancellationSignal) {
        Map hashMap = new HashMap();
        for (FontInfo fontInfo : fontInfoArr) {
            if (fontInfo.getResultCode() == 0) {
                Uri uri = fontInfo.getUri();
                if (!hashMap.containsKey(uri)) {
                    hashMap.put(uri, TypefaceCompatUtil.mmap(context, cancellationSignal, uri));
                }
            }
        }
        return Collections.unmodifiableMap(hashMap);
    }

    public static FontFamilyResult fetchFonts(Context context, CancellationSignal cancellationSignal, FontRequest fontRequest) throws NameNotFoundException {
        ProviderInfo provider = getProvider(context.getPackageManager(), fontRequest, context.getResources());
        if (provider == null) {
            return new FontFamilyResult(1, null);
        }
        return new FontFamilyResult(null, getFontFromProvider(context, fontRequest, provider.authority, cancellationSignal));
    }

    public static ProviderInfo getProvider(PackageManager packageManager, FontRequest fontRequest, Resources resources) throws NameNotFoundException {
        String providerAuthority = fontRequest.getProviderAuthority();
        int i = 0;
        ProviderInfo resolveContentProvider = packageManager.resolveContentProvider(providerAuthority, 0);
        if (resolveContentProvider == null) {
            fontRequest = new StringBuilder();
            fontRequest.append("No package found for authority: ");
            fontRequest.append(providerAuthority);
            throw new NameNotFoundException(fontRequest.toString());
        } else if (resolveContentProvider.packageName.equals(fontRequest.getProviderPackage())) {
            packageManager = convertToByteArrayList(packageManager.getPackageInfo(resolveContentProvider.packageName, 64).signatures);
            Collections.sort(packageManager, sByteArrayComparator);
            fontRequest = getCertificates(fontRequest, resources);
            while (i < fontRequest.size()) {
                resources = new ArrayList((Collection) fontRequest.get(i));
                Collections.sort(resources, sByteArrayComparator);
                if (equalsByteArrayList(packageManager, resources) != null) {
                    return resolveContentProvider;
                }
                i++;
            }
            return null;
        } else {
            resources = new StringBuilder();
            resources.append("Found content provider ");
            resources.append(providerAuthority);
            resources.append(", but package was not ");
            resources.append(fontRequest.getProviderPackage());
            throw new NameNotFoundException(resources.toString());
        }
    }

    private static List<List<byte[]>> getCertificates(FontRequest fontRequest, Resources resources) {
        if (fontRequest.getCertificates() != null) {
            return fontRequest.getCertificates();
        }
        return FontResourcesParserCompat.readCerts(resources, fontRequest.getCertificatesArrayResId());
    }

    private static boolean equalsByteArrayList(List<byte[]> list, List<byte[]> list2) {
        if (list.size() != list2.size()) {
            return false;
        }
        for (int i = 0; i < list.size(); i++) {
            if (!Arrays.equals((byte[]) list.get(i), (byte[]) list2.get(i))) {
                return false;
            }
        }
        return true;
    }

    private static List<byte[]> convertToByteArrayList(Signature[] signatureArr) {
        List<byte[]> arrayList = new ArrayList();
        for (Signature toByteArray : signatureArr) {
            arrayList.add(toByteArray.toByteArray());
        }
        return arrayList;
    }

    static FontInfo[] getFontFromProvider(Context context, FontRequest fontRequest, String str, CancellationSignal cancellationSignal) {
        String str2 = str;
        ArrayList arrayList = new ArrayList();
        Builder builder = new Builder();
        String str3 = Param.CONTENT;
        Uri build = builder.scheme(str3).authority(str2).build();
        Uri build2 = new Builder().scheme(str3).authority(str2).appendPath("file").build();
        Cursor cursor = null;
        try {
            if (VERSION.SDK_INT > 16) {
                cursor = context.getContentResolver().query(build, new String[]{"_id", Columns.FILE_ID, Columns.TTC_INDEX, Columns.VARIATION_SETTINGS, Columns.WEIGHT, Columns.ITALIC, Columns.RESULT_CODE}, "query = ?", new String[]{fontRequest.getQuery()}, null, cancellationSignal);
            } else {
                cursor = context.getContentResolver().query(build, new String[]{"_id", Columns.FILE_ID, Columns.TTC_INDEX, Columns.VARIATION_SETTINGS, Columns.WEIGHT, Columns.ITALIC, Columns.RESULT_CODE}, "query = ?", new String[]{fontRequest.getQuery()}, null);
            }
            if (cursor != null && cursor.getCount() > 0) {
                int columnIndex = cursor.getColumnIndex(Columns.RESULT_CODE);
                ArrayList arrayList2 = new ArrayList();
                int columnIndex2 = cursor.getColumnIndex("_id");
                int columnIndex3 = cursor.getColumnIndex(Columns.FILE_ID);
                int columnIndex4 = cursor.getColumnIndex(Columns.TTC_INDEX);
                int columnIndex5 = cursor.getColumnIndex(Columns.WEIGHT);
                int columnIndex6 = cursor.getColumnIndex(Columns.ITALIC);
                while (cursor.moveToNext()) {
                    Uri withAppendedId;
                    int i = columnIndex != -1 ? cursor.getInt(columnIndex) : 0;
                    int i2 = columnIndex4 != -1 ? cursor.getInt(columnIndex4) : 0;
                    if (columnIndex3 == -1) {
                        withAppendedId = ContentUris.withAppendedId(build, cursor.getLong(columnIndex2));
                    } else {
                        withAppendedId = ContentUris.withAppendedId(build2, cursor.getLong(columnIndex3));
                    }
                    Uri uri = withAppendedId;
                    int i3 = columnIndex5 != -1 ? cursor.getInt(columnIndex5) : Style.FONT_WEIGHT_NORMAL;
                    boolean z = columnIndex6 != -1 && cursor.getInt(columnIndex6) == 1;
                    arrayList2.add(new FontInfo(uri, i2, i3, z, i));
                }
                arrayList = arrayList2;
            }
            if (cursor != null) {
                cursor.close();
            }
            return (FontInfo[]) arrayList.toArray(new FontInfo[0]);
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}
