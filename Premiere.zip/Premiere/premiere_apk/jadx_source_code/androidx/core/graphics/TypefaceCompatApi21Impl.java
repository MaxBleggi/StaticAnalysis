package androidx.core.graphics;

class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl {
    private static final String TAG = "TypefaceCompatApi21Impl";

    TypefaceCompatApi21Impl() {
    }

    private java.io.File getFile(android.os.ParcelFileDescriptor r4) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = 0;
        r1 = new java.lang.StringBuilder;	 Catch:{ ErrnoException -> 0x002c }
        r1.<init>();	 Catch:{ ErrnoException -> 0x002c }
        r2 = "/proc/self/fd/";	 Catch:{ ErrnoException -> 0x002c }
        r1.append(r2);	 Catch:{ ErrnoException -> 0x002c }
        r4 = r4.getFd();	 Catch:{ ErrnoException -> 0x002c }
        r1.append(r4);	 Catch:{ ErrnoException -> 0x002c }
        r4 = r1.toString();	 Catch:{ ErrnoException -> 0x002c }
        r4 = android.system.Os.readlink(r4);	 Catch:{ ErrnoException -> 0x002c }
        r1 = android.system.Os.stat(r4);	 Catch:{ ErrnoException -> 0x002c }
        r1 = r1.st_mode;	 Catch:{ ErrnoException -> 0x002c }
        r1 = android.system.OsConstants.S_ISREG(r1);	 Catch:{ ErrnoException -> 0x002c }
        if (r1 == 0) goto L_0x002c;	 Catch:{ ErrnoException -> 0x002c }
    L_0x0026:
        r1 = new java.io.File;	 Catch:{ ErrnoException -> 0x002c }
        r1.<init>(r4);	 Catch:{ ErrnoException -> 0x002c }
        return r1;
    L_0x002c:
        return r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.TypefaceCompatApi21Impl.getFile(android.os.ParcelFileDescriptor):java.io.File");
    }

    public android.graphics.Typeface createFromFontInfo(android.content.Context r4, android.os.CancellationSignal r5, androidx.core.provider.FontsContractCompat.FontInfo[] r6, int r7) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r3 = this;
        r0 = r6.length;
        r1 = 0;
        r2 = 1;
        if (r0 >= r2) goto L_0x0006;
    L_0x0005:
        return r1;
    L_0x0006:
        r6 = r3.findBestInfo(r6, r7);
        r7 = r4.getContentResolver();
        r6 = r6.getUri();	 Catch:{ IOException -> 0x005f }
        r0 = "r";	 Catch:{ IOException -> 0x005f }
        r5 = r7.openFileDescriptor(r6, r0, r5);	 Catch:{ IOException -> 0x005f }
        r6 = r3.getFile(r5);	 Catch:{ all -> 0x0051 }
        if (r6 == 0) goto L_0x002f;	 Catch:{ all -> 0x0051 }
    L_0x001e:
        r7 = r6.canRead();	 Catch:{ all -> 0x0051 }
        if (r7 != 0) goto L_0x0025;	 Catch:{ all -> 0x0051 }
    L_0x0024:
        goto L_0x002f;	 Catch:{ all -> 0x0051 }
    L_0x0025:
        r4 = android.graphics.Typeface.createFromFile(r6);	 Catch:{ all -> 0x0051 }
        if (r5 == 0) goto L_0x002e;
    L_0x002b:
        r5.close();	 Catch:{ IOException -> 0x005f }
    L_0x002e:
        return r4;
    L_0x002f:
        r6 = new java.io.FileInputStream;	 Catch:{ all -> 0x0051 }
        r7 = r5.getFileDescriptor();	 Catch:{ all -> 0x0051 }
        r6.<init>(r7);	 Catch:{ all -> 0x0051 }
        r4 = super.createFromInputStream(r4, r6);	 Catch:{ all -> 0x0045 }
        r6.close();	 Catch:{ all -> 0x0051 }
        if (r5 == 0) goto L_0x0044;
    L_0x0041:
        r5.close();	 Catch:{ IOException -> 0x005f }
    L_0x0044:
        return r4;
    L_0x0045:
        r4 = move-exception;
        throw r4;	 Catch:{ all -> 0x0047 }
    L_0x0047:
        r7 = move-exception;
        r6.close();	 Catch:{ all -> 0x004c }
        goto L_0x0050;
    L_0x004c:
        r6 = move-exception;
        r4.addSuppressed(r6);	 Catch:{ all -> 0x0051 }
    L_0x0050:
        throw r7;	 Catch:{ all -> 0x0051 }
    L_0x0051:
        r4 = move-exception;
        throw r4;	 Catch:{ all -> 0x0053 }
    L_0x0053:
        r6 = move-exception;
        if (r5 == 0) goto L_0x005e;
    L_0x0056:
        r5.close();	 Catch:{ all -> 0x005a }
        goto L_0x005e;
    L_0x005a:
        r5 = move-exception;
        r4.addSuppressed(r5);	 Catch:{ IOException -> 0x005f }
    L_0x005e:
        throw r6;	 Catch:{ IOException -> 0x005f }
    L_0x005f:
        return r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.TypefaceCompatApi21Impl.createFromFontInfo(android.content.Context, android.os.CancellationSignal, androidx.core.provider.FontsContractCompat$FontInfo[], int):android.graphics.Typeface");
    }
}
