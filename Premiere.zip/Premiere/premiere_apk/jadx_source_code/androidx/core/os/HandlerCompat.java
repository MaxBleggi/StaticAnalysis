package androidx.core.os;

import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;

public final class HandlerCompat {
    public static boolean postDelayed(Handler handler, Runnable runnable, Object obj, long j) {
        if (VERSION.SDK_INT >= 28) {
            return handler.postDelayed(runnable, obj, j);
        }
        runnable = Message.obtain(handler, runnable);
        runnable.obj = obj;
        return handler.sendMessageDelayed(runnable, j);
    }

    private HandlerCompat() {
    }
}
