package androidx.core.os;

import android.os.Build.VERSION;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;

final class LocaleListHelper {
    private static final Locale EN_LATN = LocaleHelper.forLanguageTag("en-Latn");
    private static final Locale LOCALE_AR_XB = new Locale("ar", "XB");
    private static final Locale LOCALE_EN_XA = new Locale("en", "XA");
    private static final int NUM_PSEUDO_LOCALES = 2;
    private static final String STRING_AR_XB = "ar-XB";
    private static final String STRING_EN_XA = "en-XA";
    private static LocaleListHelper sDefaultAdjustedLocaleList = null;
    private static LocaleListHelper sDefaultLocaleList = null;
    private static final Locale[] sEmptyList = new Locale[0];
    private static final LocaleListHelper sEmptyLocaleList = new LocaleListHelper(new Locale[0]);
    private static Locale sLastDefaultLocale = null;
    private static LocaleListHelper sLastExplicitlySetLocaleList = null;
    private static final Object sLock = new Object();
    private final Locale[] mList;
    private final String mStringRepresentation;

    Locale get(int i) {
        if (i >= 0) {
            Locale[] localeArr = this.mList;
            if (i < localeArr.length) {
                return localeArr[i];
            }
        }
        return 0;
    }

    boolean isEmpty() {
        return this.mList.length == 0;
    }

    int size() {
        return this.mList.length;
    }

    int indexOf(Locale locale) {
        int i = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i >= localeArr.length) {
                return -1;
            }
            if (localeArr[i].equals(locale)) {
                return i;
            }
            i++;
        }
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LocaleListHelper)) {
            return false;
        }
        obj = ((LocaleListHelper) obj).mList;
        if (this.mList.length != obj.length) {
            return false;
        }
        int i = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i >= localeArr.length) {
                return true;
            }
            if (!localeArr[i].equals(obj[i])) {
                return false;
            }
            i++;
        }
    }

    public int hashCode() {
        int i = 1;
        int i2 = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i2 >= localeArr.length) {
                return i;
            }
            i = (i * 31) + localeArr[i2].hashCode();
            i2++;
        }
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        int i = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i < localeArr.length) {
                stringBuilder.append(localeArr[i]);
                if (i < this.mList.length - 1) {
                    stringBuilder.append(',');
                }
                i++;
            } else {
                stringBuilder.append("]");
                return stringBuilder.toString();
            }
        }
    }

    String toLanguageTags() {
        return this.mStringRepresentation;
    }

    LocaleListHelper(Locale... localeArr) {
        if (localeArr.length == 0) {
            this.mList = sEmptyList;
            this.mStringRepresentation = "";
            return;
        }
        Locale[] localeArr2 = new Locale[localeArr.length];
        HashSet hashSet = new HashSet();
        StringBuilder stringBuilder = new StringBuilder();
        int i = 0;
        while (i < localeArr.length) {
            Locale locale = localeArr[i];
            String str = "list[";
            StringBuilder stringBuilder2;
            if (locale == null) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(i);
                stringBuilder2.append("] is null");
                throw new NullPointerException(stringBuilder2.toString());
            } else if (hashSet.contains(locale)) {
                stringBuilder2 = new StringBuilder();
                stringBuilder2.append(str);
                stringBuilder2.append(i);
                stringBuilder2.append("] is a repetition");
                throw new IllegalArgumentException(stringBuilder2.toString());
            } else {
                locale = (Locale) locale.clone();
                localeArr2[i] = locale;
                stringBuilder.append(LocaleHelper.toLanguageTag(locale));
                if (i < localeArr.length - 1) {
                    stringBuilder.append(',');
                }
                hashSet.add(locale);
                i++;
            }
        }
        this.mList = localeArr2;
        this.mStringRepresentation = stringBuilder.toString();
    }

    LocaleListHelper(Locale locale, LocaleListHelper localeListHelper) {
        if (locale != null) {
            int i;
            int i2 = 0;
            if (localeListHelper == null) {
                i = 0;
            } else {
                i = localeListHelper.mList.length;
            }
            int i3 = 0;
            while (i3 < i) {
                if (locale.equals(localeListHelper.mList[i3])) {
                    break;
                }
                i3++;
            }
            i3 = -1;
            int i4 = (i3 == -1 ? 1 : 0) + i;
            Locale[] localeArr = new Locale[i4];
            localeArr[0] = (Locale) locale.clone();
            if (i3 == -1) {
                locale = null;
                while (locale < i) {
                    i3 = locale + 1;
                    localeArr[i3] = (Locale) localeListHelper.mList[locale].clone();
                    locale = i3;
                }
            } else {
                locale = null;
                while (locale < i3) {
                    int i5 = locale + 1;
                    localeArr[i5] = (Locale) localeListHelper.mList[locale].clone();
                    locale = i5;
                }
                for (i3++; i3 < i; i3++) {
                    localeArr[i3] = (Locale) localeListHelper.mList[i3].clone();
                }
            }
            locale = new StringBuilder();
            while (i2 < i4) {
                locale.append(LocaleHelper.toLanguageTag(localeArr[i2]));
                if (i2 < i4 - 1) {
                    locale.append(',');
                }
                i2++;
            }
            this.mList = localeArr;
            this.mStringRepresentation = locale.toString();
            return;
        }
        throw new NullPointerException("topLocale is null");
    }

    static LocaleListHelper getEmptyLocaleList() {
        return sEmptyLocaleList;
    }

    static LocaleListHelper forLanguageTags(String str) {
        if (str != null) {
            if (!str.isEmpty()) {
                str = str.split(",", -1);
                Locale[] localeArr = new Locale[str.length];
                for (int i = 0; i < localeArr.length; i++) {
                    localeArr[i] = LocaleHelper.forLanguageTag(str[i]);
                }
                return new LocaleListHelper(localeArr);
            }
        }
        return getEmptyLocaleList();
    }

    private static String getLikelyScript(Locale locale) {
        String str = "";
        if (VERSION.SDK_INT >= 21) {
            locale = locale.getScript();
            if (!locale.isEmpty()) {
                return locale;
            }
        }
        return str;
    }

    private static boolean isPseudoLocale(String str) {
        if (!STRING_EN_XA.equals(str)) {
            if (STRING_AR_XB.equals(str) == null) {
                return null;
            }
        }
        return true;
    }

    private static boolean isPseudoLocale(Locale locale) {
        if (!LOCALE_EN_XA.equals(locale)) {
            if (LOCALE_AR_XB.equals(locale) == null) {
                return null;
            }
        }
        return true;
    }

    private static int matchScore(Locale locale, Locale locale2) {
        int i = 1;
        if (locale.equals(locale2)) {
            return 1;
        }
        if (locale.getLanguage().equals(locale2.getLanguage()) && !isPseudoLocale(locale)) {
            if (!isPseudoLocale(locale2)) {
                String likelyScript = getLikelyScript(locale);
                if (!likelyScript.isEmpty()) {
                    return likelyScript.equals(getLikelyScript(locale2));
                }
                locale = locale.getCountry();
                if (!locale.isEmpty()) {
                    if (locale.equals(locale2.getCountry()) == null) {
                        i = 0;
                    }
                }
                return i;
            }
        }
        return 0;
    }

    private int findFirstMatchIndex(Locale locale) {
        int i = 0;
        while (true) {
            Locale[] localeArr = this.mList;
            if (i >= localeArr.length) {
                return Integer.MAX_VALUE;
            }
            if (matchScore(locale, localeArr[i]) > 0) {
                return i;
            }
            i++;
        }
    }

    private int computeFirstMatchIndex(Collection<String> collection, boolean z) {
        Locale[] localeArr = this.mList;
        if (localeArr.length == 1) {
            return 0;
        }
        if (localeArr.length == 0) {
            return -1;
        }
        boolean findFirstMatchIndex;
        if (z) {
            z = findFirstMatchIndex(EN_LATN);
            if (!z) {
                return 0;
            }
            if (z < true) {
                for (String forLanguageTag : collection) {
                    findFirstMatchIndex = findFirstMatchIndex(LocaleHelper.forLanguageTag(forLanguageTag));
                    if (!findFirstMatchIndex) {
                        return 0;
                    }
                    if (findFirstMatchIndex < z) {
                        z = findFirstMatchIndex;
                    }
                }
                if (!z) {
                    return 0;
                }
                return z;
            }
        }
        z = true;
        while (collection.hasNext()) {
            findFirstMatchIndex = findFirstMatchIndex(LocaleHelper.forLanguageTag(forLanguageTag));
            if (!findFirstMatchIndex) {
                return 0;
            }
            if (findFirstMatchIndex < z) {
                z = findFirstMatchIndex;
            }
        }
        if (!z) {
            return z;
        }
        return 0;
    }

    private Locale computeFirstMatch(Collection<String> collection, boolean z) {
        collection = computeFirstMatchIndex(collection, z);
        if (collection == true) {
            return null;
        }
        return this.mList[collection];
    }

    Locale getFirstMatch(String[] strArr) {
        return computeFirstMatch(Arrays.asList(strArr), false);
    }

    int getFirstMatchIndex(String[] strArr) {
        return computeFirstMatchIndex(Arrays.asList(strArr), false);
    }

    Locale getFirstMatchWithEnglishSupported(String[] strArr) {
        return computeFirstMatch(Arrays.asList(strArr), true);
    }

    int getFirstMatchIndexWithEnglishSupported(Collection<String> collection) {
        return computeFirstMatchIndex(collection, true);
    }

    int getFirstMatchIndexWithEnglishSupported(String[] strArr) {
        return getFirstMatchIndexWithEnglishSupported(Arrays.asList(strArr));
    }

    static boolean isPseudoLocalesOnly(String[] strArr) {
        if (strArr == null) {
            return true;
        }
        if (strArr.length > 3) {
            return false;
        }
        for (String str : strArr) {
            if (!str.isEmpty() && !isPseudoLocale(str)) {
                return false;
            }
        }
        return true;
    }

    static LocaleListHelper getDefault() {
        Locale locale = Locale.getDefault();
        synchronized (sLock) {
            LocaleListHelper localeListHelper;
            if (!locale.equals(sLastDefaultLocale)) {
                sLastDefaultLocale = locale;
                if (sDefaultLocaleList == null || !locale.equals(sDefaultLocaleList.get(0))) {
                    sDefaultLocaleList = new LocaleListHelper(locale, sLastExplicitlySetLocaleList);
                    sDefaultAdjustedLocaleList = sDefaultLocaleList;
                } else {
                    localeListHelper = sDefaultLocaleList;
                    return localeListHelper;
                }
            }
            localeListHelper = sDefaultLocaleList;
            return localeListHelper;
        }
    }

    static LocaleListHelper getAdjustedDefault() {
        LocaleListHelper localeListHelper;
        getDefault();
        synchronized (sLock) {
            localeListHelper = sDefaultAdjustedLocaleList;
        }
        return localeListHelper;
    }

    static void setDefault(LocaleListHelper localeListHelper) {
        setDefault(localeListHelper, 0);
    }

    static void setDefault(LocaleListHelper localeListHelper, int i) {
        if (localeListHelper == null) {
            throw new NullPointerException("locales is null");
        } else if (localeListHelper.isEmpty()) {
            throw new IllegalArgumentException("locales is empty");
        } else {
            synchronized (sLock) {
                sLastDefaultLocale = localeListHelper.get(i);
                Locale.setDefault(sLastDefaultLocale);
                sLastExplicitlySetLocaleList = localeListHelper;
                sDefaultLocaleList = localeListHelper;
                if (i == 0) {
                    sDefaultAdjustedLocaleList = sDefaultLocaleList;
                } else {
                    sDefaultAdjustedLocaleList = new LocaleListHelper(sLastDefaultLocale, sDefaultLocaleList);
                }
            }
        }
    }
}
