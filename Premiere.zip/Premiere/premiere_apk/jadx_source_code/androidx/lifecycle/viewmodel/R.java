package androidx.lifecycle.viewmodel;

public final class R {
    private R() {
    }
}
