package androidx.lifecycle.service;

public final class R {
    private R() {
    }
}
