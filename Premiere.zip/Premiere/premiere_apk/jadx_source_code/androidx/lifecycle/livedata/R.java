package androidx.lifecycle.livedata;

public final class R {
    private R() {
    }
}
