package androidx.versionedparcelable;

public final class R {
    private R() {
    }
}
