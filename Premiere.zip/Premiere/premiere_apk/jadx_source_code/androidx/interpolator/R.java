package androidx.interpolator;

public final class R {
    private R() {
    }
}
