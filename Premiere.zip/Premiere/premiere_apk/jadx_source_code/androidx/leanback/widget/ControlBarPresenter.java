package androidx.leanback.widget;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import androidx.leanback.R;
import androidx.leanback.widget.ControlBar.OnChildFocusedListener;
import androidx.leanback.widget.ObjectAdapter.DataObserver;

class ControlBarPresenter extends Presenter {
    static final int MAX_CONTROLS = 7;
    private static int sChildMarginDefault;
    private static int sControlIconWidth;
    boolean mDefaultFocusToMiddle = true;
    private int mLayoutResourceId;
    OnControlClickedListener mOnControlClickedListener;
    OnControlSelectedListener mOnControlSelectedListener;

    static class BoundData {
        ObjectAdapter adapter;
        Presenter presenter;

        BoundData() {
        }
    }

    interface OnControlClickedListener {
        void onControlClicked(androidx.leanback.widget.Presenter.ViewHolder viewHolder, Object obj, BoundData boundData);
    }

    interface OnControlSelectedListener {
        void onControlSelected(androidx.leanback.widget.Presenter.ViewHolder viewHolder, Object obj, BoundData boundData);
    }

    class ViewHolder extends androidx.leanback.widget.Presenter.ViewHolder {
        ObjectAdapter mAdapter;
        ControlBar mControlBar;
        View mControlsContainer;
        BoundData mData;
        DataObserver mDataObserver;
        Presenter mPresenter;
        SparseArray<androidx.leanback.widget.Presenter.ViewHolder> mViewHolders = new SparseArray();

        ViewHolder(View view) {
            super(view);
            this.mControlsContainer = view.findViewById(R.id.controls_container);
            this.mControlBar = (ControlBar) view.findViewById(R.id.control_bar);
            view = this.mControlBar;
            if (view != null) {
                view.setDefaultFocusToMiddle(ControlBarPresenter.this.mDefaultFocusToMiddle);
                this.mControlBar.setOnChildFocusedListener(new OnChildFocusedListener(ControlBarPresenter.this) {
                    public void onChildFocusedListener(View view, View view2) {
                        if (ControlBarPresenter.this.mOnControlSelectedListener != null) {
                            for (view2 = null; view2 < ViewHolder.this.mViewHolders.size(); view2++) {
                                if (((androidx.leanback.widget.Presenter.ViewHolder) ViewHolder.this.mViewHolders.get(view2)).view == view) {
                                    ControlBarPresenter.this.mOnControlSelectedListener.onControlSelected((androidx.leanback.widget.Presenter.ViewHolder) ViewHolder.this.mViewHolders.get(view2), ViewHolder.this.getDisplayedAdapter().get(view2), ViewHolder.this.mData);
                                    break;
                                }
                            }
                        }
                    }
                });
                this.mDataObserver = new DataObserver(ControlBarPresenter.this) {
                    public void onChanged() {
                        if (ViewHolder.this.mAdapter == ViewHolder.this.getDisplayedAdapter()) {
                            ViewHolder viewHolder = ViewHolder.this;
                            viewHolder.showControls(viewHolder.mPresenter);
                        }
                    }

                    public void onItemRangeChanged(int i, int i2) {
                        if (ViewHolder.this.mAdapter == ViewHolder.this.getDisplayedAdapter()) {
                            for (int i3 = 0; i3 < i2; i3++) {
                                ViewHolder viewHolder = ViewHolder.this;
                                viewHolder.bindControlToAction(i + i3, viewHolder.mPresenter);
                            }
                        }
                    }
                };
                return;
            }
            throw new IllegalStateException("Couldn't find control_bar");
        }

        int getChildMarginFromCenter(Context context, int i) {
            return ControlBarPresenter.this.getChildMarginDefault(context) + ControlBarPresenter.this.getControlIconWidth(context);
        }

        void showControls(Presenter presenter) {
            int i;
            ObjectAdapter displayedAdapter = getDisplayedAdapter();
            int i2 = 0;
            if (displayedAdapter == null) {
                i = 0;
            } else {
                i = displayedAdapter.size();
            }
            View focusedChild = this.mControlBar.getFocusedChild();
            if (focusedChild != null && i > 0 && this.mControlBar.indexOfChild(focusedChild) >= i) {
                this.mControlBar.getChildAt(displayedAdapter.size() - 1).requestFocus();
            }
            for (int childCount = this.mControlBar.getChildCount() - 1; childCount >= i; childCount--) {
                this.mControlBar.removeViewAt(childCount);
            }
            while (i2 < i && i2 < 7) {
                bindControlToAction(i2, displayedAdapter, presenter);
                i2++;
            }
            presenter = this.mControlBar;
            presenter.setChildMarginFromCenter(getChildMarginFromCenter(presenter.getContext(), i));
        }

        void bindControlToAction(int i, Presenter presenter) {
            bindControlToAction(i, getDisplayedAdapter(), presenter);
        }

        private void bindControlToAction(final int i, ObjectAdapter objectAdapter, Presenter presenter) {
            androidx.leanback.widget.Presenter.ViewHolder viewHolder = (androidx.leanback.widget.Presenter.ViewHolder) this.mViewHolders.get(i);
            objectAdapter = objectAdapter.get(i);
            if (viewHolder == null) {
                viewHolder = presenter.onCreateViewHolder(this.mControlBar);
                this.mViewHolders.put(i, viewHolder);
                presenter.setOnClickListener(viewHolder, new OnClickListener() {
                    public void onClick(View view) {
                        view = ViewHolder.this.getDisplayedAdapter().get(i);
                        if (ControlBarPresenter.this.mOnControlClickedListener != null) {
                            ControlBarPresenter.this.mOnControlClickedListener.onControlClicked(viewHolder, view, ViewHolder.this.mData);
                        }
                    }
                });
            }
            if (viewHolder.view.getParent() == 0) {
                this.mControlBar.addView(viewHolder.view);
            }
            presenter.onBindViewHolder(viewHolder, objectAdapter);
        }

        ObjectAdapter getDisplayedAdapter() {
            return this.mAdapter;
        }
    }

    public ControlBarPresenter(int i) {
        this.mLayoutResourceId = i;
    }

    public int getLayoutResourceId() {
        return this.mLayoutResourceId;
    }

    public void setOnControlClickedListener(OnControlClickedListener onControlClickedListener) {
        this.mOnControlClickedListener = onControlClickedListener;
    }

    public OnControlClickedListener getOnItemViewClickedListener() {
        return this.mOnControlClickedListener;
    }

    public void setOnControlSelectedListener(OnControlSelectedListener onControlSelectedListener) {
        this.mOnControlSelectedListener = onControlSelectedListener;
    }

    public OnControlSelectedListener getOnItemControlListener() {
        return this.mOnControlSelectedListener;
    }

    public void setBackgroundColor(ViewHolder viewHolder, int i) {
        viewHolder.mControlsContainer.setBackgroundColor(i);
    }

    public androidx.leanback.widget.Presenter.ViewHolder onCreateViewHolder(ViewGroup viewGroup) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(getLayoutResourceId(), viewGroup, false));
    }

    public void onBindViewHolder(androidx.leanback.widget.Presenter.ViewHolder viewHolder, Object obj) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        BoundData boundData = (BoundData) obj;
        if (viewHolder2.mAdapter != boundData.adapter) {
            viewHolder2.mAdapter = boundData.adapter;
            if (viewHolder2.mAdapter != null) {
                viewHolder2.mAdapter.registerObserver(viewHolder2.mDataObserver);
            }
        }
        viewHolder2.mPresenter = boundData.presenter;
        viewHolder2.mData = boundData;
        viewHolder2.showControls(viewHolder2.mPresenter);
    }

    public void onUnbindViewHolder(androidx.leanback.widget.Presenter.ViewHolder viewHolder) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        if (viewHolder2.mAdapter != null) {
            viewHolder2.mAdapter.unregisterObserver(viewHolder2.mDataObserver);
            viewHolder2.mAdapter = null;
        }
        viewHolder2.mData = null;
    }

    int getChildMarginDefault(Context context) {
        if (sChildMarginDefault == 0) {
            sChildMarginDefault = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_controls_child_margin_default);
        }
        return sChildMarginDefault;
    }

    int getControlIconWidth(Context context) {
        if (sControlIconWidth == 0) {
            sControlIconWidth = context.getResources().getDimensionPixelSize(R.dimen.lb_control_icon_width);
        }
        return sControlIconWidth;
    }

    void setDefaultFocusToMiddle(boolean z) {
        this.mDefaultFocusToMiddle = z;
    }
}
