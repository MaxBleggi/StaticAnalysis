package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;

public class Util {
    public static boolean isDescendant(ViewGroup viewGroup, View view) {
        while (view != null) {
            if (view == viewGroup) {
                return true;
            }
            view = view.getParent();
            if (!(view instanceof View)) {
                return false;
            }
            view = view;
        }
        return false;
    }

    private Util() {
    }
}
