package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import androidx.leanback.R;
import androidx.leanback.system.Settings;
import androidx.leanback.transition.TransitionHelper;
import androidx.leanback.widget.BaseGridView.OnUnhandledKeyListener;
import androidx.leanback.widget.ItemBridgeAdapter.Wrapper;
import androidx.leanback.widget.Presenter.ViewHolderTask;
import androidx.leanback.widget.ShadowOverlayHelper.Builder;
import androidx.leanback.widget.ShadowOverlayHelper.Options;
import java.util.HashMap;

public class ListRowPresenter extends RowPresenter {
    private static final boolean DEBUG = false;
    private static final int DEFAULT_RECYCLED_POOL_SIZE = 24;
    private static final String TAG = "ListRowPresenter";
    private static int sExpandedRowNoHovercardBottomPadding;
    private static int sExpandedSelectedRowTopPadding;
    private static int sSelectedRowTopPadding;
    private int mBrowseRowsFadingEdgeLength;
    private int mExpandedRowHeight;
    private int mFocusZoomFactor;
    private PresenterSelector mHoverCardPresenterSelector;
    private boolean mKeepChildForeground;
    private int mNumRows;
    private HashMap<Presenter, Integer> mRecycledPoolSize;
    private boolean mRoundedCornersEnabled;
    private int mRowHeight;
    private boolean mShadowEnabled;
    ShadowOverlayHelper mShadowOverlayHelper;
    private Wrapper mShadowOverlayWrapper;
    private boolean mUseFocusDimmer;

    public static class SelectItemViewHolderTask extends ViewHolderTask {
        private int mItemPosition;
        ViewHolderTask mItemTask;
        private boolean mSmoothScroll = true;

        public SelectItemViewHolderTask(int i) {
            setItemPosition(i);
        }

        public void setItemPosition(int i) {
            this.mItemPosition = i;
        }

        public int getItemPosition() {
            return this.mItemPosition;
        }

        public void setSmoothScroll(boolean z) {
            this.mSmoothScroll = z;
        }

        public boolean isSmoothScroll() {
            return this.mSmoothScroll;
        }

        public ViewHolderTask getItemTask() {
            return this.mItemTask;
        }

        public void setItemTask(ViewHolderTask viewHolderTask) {
            this.mItemTask = viewHolderTask;
        }

        public void run(androidx.leanback.widget.Presenter.ViewHolder viewHolder) {
            if (viewHolder instanceof ViewHolder) {
                viewHolder = ((ViewHolder) viewHolder).getGridView();
                ViewHolderTask viewHolderTask = null;
                if (this.mItemTask != null) {
                    viewHolderTask = new ViewHolderTask() {
                        final ViewHolderTask itemTask = SelectItemViewHolderTask.this.mItemTask;

                        public void run(androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder) {
                            this.itemTask.run(((androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) viewHolder).getViewHolder());
                        }
                    };
                }
                if (isSmoothScroll()) {
                    viewHolder.setSelectedPositionSmooth(this.mItemPosition, viewHolderTask);
                } else {
                    viewHolder.setSelectedPosition(this.mItemPosition, viewHolderTask);
                }
            }
        }
    }

    class ListRowPresenterItemBridgeAdapter extends ItemBridgeAdapter {
        ViewHolder mRowViewHolder;

        ListRowPresenterItemBridgeAdapter(ViewHolder viewHolder) {
            this.mRowViewHolder = viewHolder;
        }

        protected void onCreate(androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder) {
            if (viewHolder.itemView instanceof ViewGroup) {
                TransitionHelper.setTransitionGroup((ViewGroup) viewHolder.itemView, true);
            }
            if (ListRowPresenter.this.mShadowOverlayHelper != null) {
                ListRowPresenter.this.mShadowOverlayHelper.onViewCreated(viewHolder.itemView);
            }
        }

        public void onBind(final androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder) {
            if (this.mRowViewHolder.getOnItemViewClickedListener() != null) {
                viewHolder.mHolder.view.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder = (androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) ListRowPresenterItemBridgeAdapter.this.mRowViewHolder.mGridView.getChildViewHolder(viewHolder.itemView);
                        if (ListRowPresenterItemBridgeAdapter.this.mRowViewHolder.getOnItemViewClickedListener() != null) {
                            ListRowPresenterItemBridgeAdapter.this.mRowViewHolder.getOnItemViewClickedListener().onItemClicked(viewHolder.mHolder, viewHolder.mItem, ListRowPresenterItemBridgeAdapter.this.mRowViewHolder, (ListRow) ListRowPresenterItemBridgeAdapter.this.mRowViewHolder.mRow);
                        }
                    }
                });
            }
        }

        public void onUnbind(androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder) {
            if (this.mRowViewHolder.getOnItemViewClickedListener() != null) {
                viewHolder.mHolder.view.setOnClickListener(null);
            }
        }

        public void onAttachedToWindow(androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder) {
            ListRowPresenter.this.applySelectLevelToChild(this.mRowViewHolder, viewHolder.itemView);
            this.mRowViewHolder.syncActivatedStatus(viewHolder.itemView);
        }

        public void onAddPresenter(Presenter presenter, int i) {
            this.mRowViewHolder.getGridView().getRecycledViewPool().setMaxRecycledViews(i, ListRowPresenter.this.getRecycledPoolSize(presenter));
        }
    }

    public static class ViewHolder extends androidx.leanback.widget.RowPresenter.ViewHolder {
        final HorizontalGridView mGridView;
        final HorizontalHoverCardSwitcher mHoverCardViewSwitcher = new HorizontalHoverCardSwitcher();
        ItemBridgeAdapter mItemBridgeAdapter;
        final ListRowPresenter mListRowPresenter;
        final int mPaddingBottom;
        final int mPaddingLeft;
        final int mPaddingRight;
        final int mPaddingTop;

        public ViewHolder(View view, HorizontalGridView horizontalGridView, ListRowPresenter listRowPresenter) {
            super(view);
            this.mGridView = horizontalGridView;
            this.mListRowPresenter = listRowPresenter;
            this.mPaddingTop = this.mGridView.getPaddingTop();
            this.mPaddingBottom = this.mGridView.getPaddingBottom();
            this.mPaddingLeft = this.mGridView.getPaddingLeft();
            this.mPaddingRight = this.mGridView.getPaddingRight();
        }

        public final ListRowPresenter getListRowPresenter() {
            return this.mListRowPresenter;
        }

        public final HorizontalGridView getGridView() {
            return this.mGridView;
        }

        public final ItemBridgeAdapter getBridgeAdapter() {
            return this.mItemBridgeAdapter;
        }

        public int getSelectedPosition() {
            return this.mGridView.getSelectedPosition();
        }

        public androidx.leanback.widget.Presenter.ViewHolder getItemViewHolder(int i) {
            androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder = (androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) this.mGridView.findViewHolderForAdapterPosition(i);
            if (viewHolder == null) {
                return 0;
            }
            return viewHolder.getViewHolder();
        }

        public androidx.leanback.widget.Presenter.ViewHolder getSelectedItemViewHolder() {
            return getItemViewHolder(getSelectedPosition());
        }

        public Object getSelectedItem() {
            androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder = (androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) this.mGridView.findViewHolderForAdapterPosition(getSelectedPosition());
            if (viewHolder == null) {
                return null;
            }
            return viewHolder.getItem();
        }
    }

    public boolean isUsingDefaultListSelectEffect() {
        return true;
    }

    public final boolean isUsingDefaultSelectEffect() {
        return false;
    }

    public ListRowPresenter() {
        this(2);
    }

    public ListRowPresenter(int i) {
        this(i, false);
    }

    public ListRowPresenter(int i, boolean z) {
        this.mNumRows = 1;
        this.mShadowEnabled = true;
        this.mBrowseRowsFadingEdgeLength = -1;
        this.mRoundedCornersEnabled = true;
        this.mKeepChildForeground = true;
        this.mRecycledPoolSize = new HashMap();
        if (FocusHighlightHelper.isValidZoomIndex(i)) {
            this.mFocusZoomFactor = i;
            this.mUseFocusDimmer = z;
            return;
        }
        throw new IllegalArgumentException("Unhandled zoom factor");
    }

    public void setRowHeight(int i) {
        this.mRowHeight = i;
    }

    public int getRowHeight() {
        return this.mRowHeight;
    }

    public void setExpandedRowHeight(int i) {
        this.mExpandedRowHeight = i;
    }

    public int getExpandedRowHeight() {
        int i = this.mExpandedRowHeight;
        return i != 0 ? i : this.mRowHeight;
    }

    public final int getFocusZoomFactor() {
        return this.mFocusZoomFactor;
    }

    @Deprecated
    public final int getZoomFactor() {
        return this.mFocusZoomFactor;
    }

    public final boolean isFocusDimmerUsed() {
        return this.mUseFocusDimmer;
    }

    public void setNumRows(int i) {
        this.mNumRows = i;
    }

    protected void initializeRowViewHolder(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        super.initializeRowViewHolder(viewHolder);
        final ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder = viewHolder.view.getContext();
        boolean z = true;
        if (this.mShadowOverlayHelper == null) {
            Builder needsShadow = new Builder().needsOverlay(needsDefaultListSelectEffect()).needsShadow(needsDefaultShadow());
            boolean z2 = isUsingOutlineClipping(viewHolder) && areChildRoundedCornersEnabled();
            this.mShadowOverlayHelper = needsShadow.needsRoundedCorner(z2).preferZOrder(isUsingZOrder(viewHolder)).keepForegroundDrawable(this.mKeepChildForeground).options(createShadowOverlayOptions()).build(viewHolder);
            if (this.mShadowOverlayHelper.needsWrapper() != null) {
                this.mShadowOverlayWrapper = new ItemBridgeAdapterShadowOverlayWrapper(this.mShadowOverlayHelper);
            }
        }
        viewHolder2.mItemBridgeAdapter = new ListRowPresenterItemBridgeAdapter(viewHolder2);
        viewHolder2.mItemBridgeAdapter.setWrapper(this.mShadowOverlayWrapper);
        this.mShadowOverlayHelper.prepareParentForShadow(viewHolder2.mGridView);
        FocusHighlightHelper.setupBrowseItemFocusHighlight(viewHolder2.mItemBridgeAdapter, this.mFocusZoomFactor, this.mUseFocusDimmer);
        viewHolder = viewHolder2.mGridView;
        if (this.mShadowOverlayHelper.getShadowType() == 3) {
            z = false;
        }
        viewHolder.setFocusDrawingOrderEnabled(z);
        viewHolder2.mGridView.setOnChildSelectedListener(new OnChildSelectedListener() {
            public void onChildSelected(ViewGroup viewGroup, View view, int i, long j) {
                ListRowPresenter.this.selectChildView(viewHolder2, view, 1);
            }
        });
        viewHolder2.mGridView.setOnUnhandledKeyListener(new OnUnhandledKeyListener() {
            public boolean onUnhandledKey(KeyEvent keyEvent) {
                return (viewHolder2.getOnKeyListener() == null || viewHolder2.getOnKeyListener().onKey(viewHolder2.view, keyEvent.getKeyCode(), keyEvent) == null) ? null : true;
            }
        });
        viewHolder2.mGridView.setNumRows(this.mNumRows);
    }

    final boolean needsDefaultListSelectEffect() {
        return isUsingDefaultListSelectEffect() && getSelectEffectEnabled();
    }

    public void setRecycledPoolSize(Presenter presenter, int i) {
        this.mRecycledPoolSize.put(presenter, Integer.valueOf(i));
    }

    public int getRecycledPoolSize(Presenter presenter) {
        return this.mRecycledPoolSize.containsKey(presenter) ? ((Integer) this.mRecycledPoolSize.get(presenter)).intValue() : 24;
    }

    public final void setHoverCardPresenterSelector(PresenterSelector presenterSelector) {
        this.mHoverCardPresenterSelector = presenterSelector;
    }

    public final PresenterSelector getHoverCardPresenterSelector() {
        return this.mHoverCardPresenterSelector;
    }

    void selectChildView(ViewHolder viewHolder, View view, boolean z) {
        if (view == null) {
            if (this.mHoverCardPresenterSelector != null) {
                viewHolder.mHoverCardViewSwitcher.unselect();
            }
            if (z && viewHolder.getOnItemViewSelectedListener() != null) {
                viewHolder.getOnItemViewSelectedListener().onItemSelected(null, null, viewHolder, viewHolder.mRow);
            }
        } else if (viewHolder.mSelected) {
            androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder2 = (androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) viewHolder.mGridView.getChildViewHolder(view);
            if (this.mHoverCardPresenterSelector != null) {
                viewHolder.mHoverCardViewSwitcher.select(viewHolder.mGridView, view, viewHolder2.mItem);
            }
            if (z && viewHolder.getOnItemViewSelectedListener() != null) {
                viewHolder.getOnItemViewSelectedListener().onItemSelected(viewHolder2.mHolder, viewHolder2.mItem, viewHolder, viewHolder.mRow);
            }
        }
    }

    private static void initStatics(Context context) {
        if (sSelectedRowTopPadding == 0) {
            sSelectedRowTopPadding = context.getResources().getDimensionPixelSize(R.dimen.lb_browse_selected_row_top_padding);
            sExpandedSelectedRowTopPadding = context.getResources().getDimensionPixelSize(R.dimen.lb_browse_expanded_selected_row_top_padding);
            sExpandedRowNoHovercardBottomPadding = context.getResources().getDimensionPixelSize(R.dimen.lb_browse_expanded_row_no_hovercard_bottom_padding);
        }
    }

    private int getSpaceUnderBaseline(ViewHolder viewHolder) {
        viewHolder = viewHolder.getHeaderViewHolder();
        if (viewHolder == null) {
            return null;
        }
        if (getHeaderPresenter() != null) {
            return getHeaderPresenter().getSpaceUnderBaseline(viewHolder);
        }
        return viewHolder.view.getPaddingBottom();
    }

    private void setVerticalPadding(ViewHolder viewHolder) {
        int spaceUnderBaseline;
        int i;
        if (viewHolder.isExpanded()) {
            spaceUnderBaseline = (viewHolder.isSelected() ? sExpandedSelectedRowTopPadding : viewHolder.mPaddingTop) - getSpaceUnderBaseline(viewHolder);
            i = this.mHoverCardPresenterSelector == null ? sExpandedRowNoHovercardBottomPadding : viewHolder.mPaddingBottom;
        } else if (viewHolder.isSelected()) {
            spaceUnderBaseline = sSelectedRowTopPadding - viewHolder.mPaddingBottom;
            i = sSelectedRowTopPadding;
        } else {
            spaceUnderBaseline = 0;
            i = viewHolder.mPaddingBottom;
        }
        viewHolder.getGridView().setPadding(viewHolder.mPaddingLeft, spaceUnderBaseline, viewHolder.mPaddingRight, i);
    }

    protected androidx.leanback.widget.RowPresenter.ViewHolder createRowViewHolder(ViewGroup viewGroup) {
        initStatics(viewGroup.getContext());
        View listRowView = new ListRowView(viewGroup.getContext());
        setupFadingEffect(listRowView);
        if (this.mRowHeight != null) {
            listRowView.getGridView().setRowHeight(this.mRowHeight);
        }
        return new ViewHolder(listRowView, listRowView.getGridView(), this);
    }

    protected void dispatchItemSelectedListener(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, boolean z) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder3 = (androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) viewHolder2.mGridView.findViewHolderForPosition(viewHolder2.mGridView.getSelectedPosition());
        if (viewHolder3 == null) {
            super.dispatchItemSelectedListener(viewHolder, z);
            return;
        }
        if (z && viewHolder.getOnItemViewSelectedListener()) {
            viewHolder.getOnItemViewSelectedListener().onItemSelected(viewHolder3.getViewHolder(), viewHolder3.mItem, viewHolder2, viewHolder2.getRow());
        }
    }

    protected void onRowViewSelected(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, boolean z) {
        super.onRowViewSelected(viewHolder, z);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        setVerticalPadding(viewHolder2);
        updateFooterViewSwitcher(viewHolder2);
    }

    private void updateFooterViewSwitcher(ViewHolder viewHolder) {
        if (viewHolder.mExpanded && viewHolder.mSelected) {
            View view;
            if (this.mHoverCardPresenterSelector != null) {
                viewHolder.mHoverCardViewSwitcher.init((ViewGroup) viewHolder.view, this.mHoverCardPresenterSelector);
            }
            androidx.leanback.widget.ItemBridgeAdapter.ViewHolder viewHolder2 = (androidx.leanback.widget.ItemBridgeAdapter.ViewHolder) viewHolder.mGridView.findViewHolderForPosition(viewHolder.mGridView.getSelectedPosition());
            if (viewHolder2 == null) {
                view = null;
            } else {
                view = viewHolder2.itemView;
            }
            selectChildView(viewHolder, view, false);
        } else if (this.mHoverCardPresenterSelector != null) {
            viewHolder.mHoverCardViewSwitcher.unselect();
        }
    }

    private void setupFadingEffect(ListRowView listRowView) {
        listRowView = listRowView.getGridView();
        if (this.mBrowseRowsFadingEdgeLength < 0) {
            TypedArray obtainStyledAttributes = listRowView.getContext().obtainStyledAttributes(R.styleable.LeanbackTheme);
            this.mBrowseRowsFadingEdgeLength = (int) obtainStyledAttributes.getDimension(R.styleable.LeanbackTheme_browseRowsFadingEdgeLength, 0.0f);
            obtainStyledAttributes.recycle();
        }
        listRowView.setFadingLeftEdgeLength(this.mBrowseRowsFadingEdgeLength);
    }

    protected void onRowViewExpanded(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, boolean z) {
        super.onRowViewExpanded(viewHolder, z);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        if (getRowHeight() != getExpandedRowHeight()) {
            viewHolder2.getGridView().setRowHeight(z ? getExpandedRowHeight() : getRowHeight());
        }
        setVerticalPadding(viewHolder2);
        updateFooterViewSwitcher(viewHolder2);
    }

    protected void onBindRowViewHolder(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, Object obj) {
        super.onBindRowViewHolder(viewHolder, obj);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        ListRow listRow = (ListRow) obj;
        viewHolder2.mItemBridgeAdapter.setAdapter(listRow.getAdapter());
        viewHolder2.mGridView.setAdapter(viewHolder2.mItemBridgeAdapter);
        viewHolder2.mGridView.setContentDescription(listRow.getContentDescription());
    }

    protected void onUnbindRowViewHolder(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder2.mGridView.setAdapter(null);
        viewHolder2.mItemBridgeAdapter.clear();
        super.onUnbindRowViewHolder(viewHolder);
    }

    public boolean isUsingDefaultShadow() {
        return ShadowOverlayHelper.supportsShadow();
    }

    public boolean isUsingZOrder(Context context) {
        return Settings.getInstance(context).preferStaticShadows() ^ 1;
    }

    public boolean isUsingOutlineClipping(Context context) {
        return Settings.getInstance(context).isOutlineClippingDisabled() ^ 1;
    }

    public final void setShadowEnabled(boolean z) {
        this.mShadowEnabled = z;
    }

    public final boolean getShadowEnabled() {
        return this.mShadowEnabled;
    }

    public final void enableChildRoundedCorners(boolean z) {
        this.mRoundedCornersEnabled = z;
    }

    public final boolean areChildRoundedCornersEnabled() {
        return this.mRoundedCornersEnabled;
    }

    final boolean needsDefaultShadow() {
        return isUsingDefaultShadow() && getShadowEnabled();
    }

    public final void setKeepChildForeground(boolean z) {
        this.mKeepChildForeground = z;
    }

    public final boolean isKeepChildForeground() {
        return this.mKeepChildForeground;
    }

    protected Options createShadowOverlayOptions() {
        return Options.DEFAULT;
    }

    protected void onSelectLevelChanged(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        super.onSelectLevelChanged(viewHolder);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        int childCount = viewHolder2.mGridView.getChildCount();
        for (int i = 0; i < childCount; i++) {
            applySelectLevelToChild(viewHolder2, viewHolder2.mGridView.getChildAt(i));
        }
    }

    protected void applySelectLevelToChild(ViewHolder viewHolder, View view) {
        ShadowOverlayHelper shadowOverlayHelper = this.mShadowOverlayHelper;
        if (shadowOverlayHelper != null && shadowOverlayHelper.needsOverlay()) {
            this.mShadowOverlayHelper.setOverlayColor(view, viewHolder.mColorDimmer.getPaint().getColor());
        }
    }

    public void freeze(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, boolean z) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        viewHolder2.mGridView.setScrollEnabled(z ^ 1);
        viewHolder2.mGridView.setAnimateChildLayout(z ^ 1);
    }

    public void setEntranceTransitionState(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, boolean z) {
        super.setEntranceTransitionState(viewHolder, z);
        ((ViewHolder) viewHolder).mGridView.setChildrenVisibility(z ? false : true);
    }
}
