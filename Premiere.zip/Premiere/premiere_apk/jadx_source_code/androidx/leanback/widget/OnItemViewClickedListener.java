package androidx.leanback.widget;

public interface OnItemViewClickedListener extends BaseOnItemViewClickedListener<Row> {
}
