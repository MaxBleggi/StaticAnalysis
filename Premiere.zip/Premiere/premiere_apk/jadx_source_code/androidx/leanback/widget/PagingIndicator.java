package androidx.leanback.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.animation.DecelerateInterpolator;
import androidx.leanback.R;

public class PagingIndicator extends View {
    private static final TimeInterpolator DECELERATE_INTERPOLATOR = new DecelerateInterpolator();
    private static final Property<Dot, Float> DOT_ALPHA = new Property<Dot, Float>(Float.class, "alpha") {
        public Float get(Dot dot) {
            return Float.valueOf(dot.getAlpha());
        }

        public void set(Dot dot, Float f) {
            dot.setAlpha(f.floatValue());
        }
    };
    private static final Property<Dot, Float> DOT_DIAMETER = new Property<Dot, Float>(Float.class, "diameter") {
        public Float get(Dot dot) {
            return Float.valueOf(dot.getDiameter());
        }

        public void set(Dot dot, Float f) {
            dot.setDiameter(f.floatValue());
        }
    };
    private static final Property<Dot, Float> DOT_TRANSLATION_X = new Property<Dot, Float>(Float.class, "translation_x") {
        public Float get(Dot dot) {
            return Float.valueOf(dot.getTranslationX());
        }

        public void set(Dot dot, Float f) {
            dot.setTranslationX(f.floatValue());
        }
    };
    private static final long DURATION_ALPHA = 167;
    private static final long DURATION_DIAMETER = 417;
    private static final long DURATION_TRANSLATION_X = 417;
    private final AnimatorSet mAnimator;
    Bitmap mArrow;
    final int mArrowDiameter;
    private final int mArrowGap;
    Paint mArrowPaint;
    final int mArrowRadius;
    final Rect mArrowRect;
    final float mArrowToBgRatio;
    final Paint mBgPaint;
    private int mCurrentPage;
    int mDotCenterY;
    final int mDotDiameter;
    int mDotFgSelectColor;
    private final int mDotGap;
    final int mDotRadius;
    private int[] mDotSelectedNextX;
    private int[] mDotSelectedPrevX;
    private int[] mDotSelectedX;
    private Dot[] mDots;
    final Paint mFgPaint;
    private final AnimatorSet mHideAnimator;
    boolean mIsLtr;
    private int mPageCount;
    private int mPreviousPage;
    private final int mShadowRadius;
    private final AnimatorSet mShowAnimator;

    public class Dot {
        static final float LEFT = -1.0f;
        static final float LTR = 1.0f;
        static final float RIGHT = 1.0f;
        static final float RTL = -1.0f;
        float mAlpha;
        float mArrowImageRadius;
        float mCenterX;
        float mDiameter;
        float mDirection = 1.0f;
        int mFgColor;
        float mLayoutDirection;
        float mRadius;
        float mTranslationX;

        public Dot() {
            PagingIndicator pagingIndicator = 1065353216;
            if (!PagingIndicator.this.mIsLtr) {
                pagingIndicator = -1082130432;
            }
            this.mLayoutDirection = pagingIndicator;
        }

        void select() {
            this.mTranslationX = 0.0f;
            this.mCenterX = 0.0f;
            this.mDiameter = (float) PagingIndicator.this.mArrowDiameter;
            this.mRadius = (float) PagingIndicator.this.mArrowRadius;
            this.mArrowImageRadius = this.mRadius * PagingIndicator.this.mArrowToBgRatio;
            this.mAlpha = 1.0f;
            adjustAlpha();
        }

        void deselect() {
            this.mTranslationX = 0.0f;
            this.mCenterX = 0.0f;
            this.mDiameter = (float) PagingIndicator.this.mDotDiameter;
            this.mRadius = (float) PagingIndicator.this.mDotRadius;
            this.mArrowImageRadius = this.mRadius * PagingIndicator.this.mArrowToBgRatio;
            this.mAlpha = 0.0f;
            adjustAlpha();
        }

        public void adjustAlpha() {
            this.mFgColor = Color.argb(Math.round(this.mAlpha * 255.0f), Color.red(PagingIndicator.this.mDotFgSelectColor), Color.green(PagingIndicator.this.mDotFgSelectColor), Color.blue(PagingIndicator.this.mDotFgSelectColor));
        }

        public float getAlpha() {
            return this.mAlpha;
        }

        public void setAlpha(float f) {
            this.mAlpha = f;
            adjustAlpha();
            PagingIndicator.this.invalidate();
        }

        public float getTranslationX() {
            return this.mTranslationX;
        }

        public void setTranslationX(float f) {
            this.mTranslationX = (f * this.mDirection) * this.mLayoutDirection;
            PagingIndicator.this.invalidate();
        }

        public float getDiameter() {
            return this.mDiameter;
        }

        public void setDiameter(float f) {
            this.mDiameter = f;
            f /= 2.0f;
            this.mRadius = f;
            this.mArrowImageRadius = f * PagingIndicator.this.mArrowToBgRatio;
            PagingIndicator.this.invalidate();
        }

        void draw(Canvas canvas) {
            float f = this.mCenterX + this.mTranslationX;
            canvas.drawCircle(f, (float) PagingIndicator.this.mDotCenterY, this.mRadius, PagingIndicator.this.mBgPaint);
            if (this.mAlpha > 0.0f) {
                PagingIndicator.this.mFgPaint.setColor(this.mFgColor);
                canvas.drawCircle(f, (float) PagingIndicator.this.mDotCenterY, this.mRadius, PagingIndicator.this.mFgPaint);
                Bitmap bitmap = PagingIndicator.this.mArrow;
                Rect rect = PagingIndicator.this.mArrowRect;
                int i = (int) (f - this.mArrowImageRadius);
                float f2 = (float) PagingIndicator.this.mDotCenterY;
                float f3 = this.mArrowImageRadius;
                canvas.drawBitmap(bitmap, rect, new Rect(i, (int) (f2 - f3), (int) (f + f3), (int) (((float) PagingIndicator.this.mDotCenterY) + this.mArrowImageRadius)), PagingIndicator.this.mArrowPaint);
            }
        }

        void onRtlPropertiesChanged() {
            this.mLayoutDirection = PagingIndicator.this.mIsLtr ? 1.0f : -1.0f;
        }
    }

    public PagingIndicator(Context context) {
        this(context, null, 0);
    }

    public PagingIndicator(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PagingIndicator(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mAnimator = new AnimatorSet();
        Resources resources = getResources();
        context = context.obtainStyledAttributes(attributeSet, R.styleable.PagingIndicator, i, 0);
        this.mDotRadius = getDimensionFromTypedArray(context, R.styleable.PagingIndicator_lbDotRadius, R.dimen.lb_page_indicator_dot_radius);
        this.mDotDiameter = this.mDotRadius * 2;
        this.mArrowRadius = getDimensionFromTypedArray(context, R.styleable.PagingIndicator_arrowRadius, R.dimen.lb_page_indicator_arrow_radius);
        this.mArrowDiameter = this.mArrowRadius * 2;
        this.mDotGap = getDimensionFromTypedArray(context, R.styleable.PagingIndicator_dotToDotGap, R.dimen.lb_page_indicator_dot_gap);
        this.mArrowGap = getDimensionFromTypedArray(context, R.styleable.PagingIndicator_dotToArrowGap, R.dimen.lb_page_indicator_arrow_gap);
        attributeSet = getColorFromTypedArray(context, R.styleable.PagingIndicator_dotBgColor, R.color.lb_page_indicator_dot);
        this.mBgPaint = new Paint(1);
        this.mBgPaint.setColor(attributeSet);
        this.mDotFgSelectColor = getColorFromTypedArray(context, R.styleable.PagingIndicator_arrowBgColor, R.color.lb_page_indicator_arrow_background);
        if (this.mArrowPaint == null && context.hasValue(R.styleable.PagingIndicator_arrowColor) != null) {
            setArrowColor(context.getColor(R.styleable.PagingIndicator_arrowColor, 0));
        }
        context.recycle();
        this.mIsLtr = resources.getConfiguration().getLayoutDirection() == null ? true : null;
        context = resources.getColor(R.color.lb_page_indicator_arrow_shadow);
        this.mShadowRadius = resources.getDimensionPixelSize(R.dimen.lb_page_indicator_arrow_shadow_radius);
        this.mFgPaint = new Paint(1);
        attributeSet = (float) resources.getDimensionPixelSize(R.dimen.lb_page_indicator_arrow_shadow_offset);
        this.mFgPaint.setShadowLayer((float) this.mShadowRadius, attributeSet, attributeSet, context);
        this.mArrow = loadArrow();
        this.mArrowRect = new Rect(0, 0, this.mArrow.getWidth(), this.mArrow.getHeight());
        this.mArrowToBgRatio = ((float) this.mArrow.getWidth()) / ((float) this.mArrowDiameter);
        this.mShowAnimator = new AnimatorSet();
        this.mShowAnimator.playTogether(new Animator[]{createDotAlphaAnimator(0.0f, 1.0f), createDotDiameterAnimator((float) (this.mDotRadius * 2), (float) (this.mArrowRadius * 2)), createDotTranslationXAnimator()});
        this.mHideAnimator = new AnimatorSet();
        this.mHideAnimator.playTogether(new Animator[]{createDotAlphaAnimator(1.0f, 0.0f), createDotDiameterAnimator((float) (this.mArrowRadius * 2), (float) (this.mDotRadius * 2)), createDotTranslationXAnimator()});
        this.mAnimator.playTogether(new Animator[]{this.mShowAnimator, this.mHideAnimator});
        setLayerType(1, null);
    }

    private int getDimensionFromTypedArray(TypedArray typedArray, int i, int i2) {
        return typedArray.getDimensionPixelOffset(i, getResources().getDimensionPixelOffset(i2));
    }

    private int getColorFromTypedArray(TypedArray typedArray, int i, int i2) {
        return typedArray.getColor(i, getResources().getColor(i2));
    }

    private Bitmap loadArrow() {
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), R.drawable.lb_ic_nav_arrow);
        if (this.mIsLtr) {
            return decodeResource;
        }
        Matrix matrix = new Matrix();
        matrix.preScale(-1.0f, 1.0f);
        return Bitmap.createBitmap(decodeResource, 0, 0, decodeResource.getWidth(), decodeResource.getHeight(), matrix, false);
    }

    public void setArrowColor(int i) {
        if (this.mArrowPaint == null) {
            this.mArrowPaint = new Paint();
        }
        this.mArrowPaint.setColorFilter(new PorterDuffColorFilter(i, Mode.SRC_IN));
    }

    public void setDotBackgroundColor(int i) {
        this.mBgPaint.setColor(i);
    }

    public void setArrowBackgroundColor(int i) {
        this.mDotFgSelectColor = i;
    }

    private Animator createDotAlphaAnimator(float f, float f2) {
        f = ObjectAnimator.ofFloat(0.0f, DOT_ALPHA, new float[]{f, f2});
        f.setDuration(DURATION_ALPHA);
        f.setInterpolator(DECELERATE_INTERPOLATOR);
        return f;
    }

    private Animator createDotDiameterAnimator(float f, float f2) {
        f = ObjectAnimator.ofFloat(0.0f, DOT_DIAMETER, new float[]{f, f2});
        f.setDuration(417);
        f.setInterpolator(DECELERATE_INTERPOLATOR);
        return f;
    }

    private Animator createDotTranslationXAnimator() {
        Animator ofFloat = ObjectAnimator.ofFloat(null, DOT_TRANSLATION_X, new float[]{(float) ((-this.mArrowGap) + this.mDotGap), 0.0f});
        ofFloat.setDuration(417);
        ofFloat.setInterpolator(DECELERATE_INTERPOLATOR);
        return ofFloat;
    }

    public void setPageCount(int i) {
        if (i > 0) {
            this.mPageCount = i;
            this.mDots = new Dot[this.mPageCount];
            for (int i2 = 0; i2 < this.mPageCount; i2++) {
                this.mDots[i2] = new Dot();
            }
            calculateDotPositions();
            setSelectedPage(0);
            return;
        }
        throw new IllegalArgumentException("The page count should be a positive integer");
    }

    public void onPageSelected(int i, boolean z) {
        if (this.mCurrentPage != i) {
            if (this.mAnimator.isStarted()) {
                this.mAnimator.end();
            }
            this.mPreviousPage = this.mCurrentPage;
            if (z) {
                this.mHideAnimator.setTarget(this.mDots[this.mPreviousPage]);
                this.mShowAnimator.setTarget(this.mDots[i]);
                this.mAnimator.start();
            }
            setSelectedPage(i);
        }
    }

    private void calculateDotPositions() {
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int width = getWidth() - getPaddingRight();
        int requiredWidth = getRequiredWidth();
        paddingLeft = (paddingLeft + width) / 2;
        width = this.mPageCount;
        this.mDotSelectedX = new int[width];
        this.mDotSelectedPrevX = new int[width];
        this.mDotSelectedNextX = new int[width];
        int i = 1;
        int[] iArr;
        int i2;
        int i3;
        int i4;
        int[] iArr2;
        int i5;
        if (this.mIsLtr) {
            paddingLeft -= requiredWidth / 2;
            iArr = this.mDotSelectedX;
            requiredWidth = this.mDotRadius;
            i2 = paddingLeft + requiredWidth;
            i3 = this.mDotGap;
            i2 -= i3;
            i4 = this.mArrowGap;
            iArr[0] = i2 + i4;
            this.mDotSelectedPrevX[0] = paddingLeft + requiredWidth;
            this.mDotSelectedNextX[0] = ((paddingLeft + requiredWidth) - (i3 * 2)) + (i4 * 2);
            while (i < this.mPageCount) {
                iArr2 = this.mDotSelectedX;
                iArr = this.mDotSelectedPrevX;
                requiredWidth = i - 1;
                i5 = iArr[requiredWidth];
                i2 = this.mArrowGap;
                iArr2[i] = i5 + i2;
                iArr[i] = iArr[requiredWidth] + this.mDotGap;
                this.mDotSelectedNextX[i] = iArr2[requiredWidth] + i2;
                i++;
            }
        } else {
            paddingLeft += requiredWidth / 2;
            iArr = this.mDotSelectedX;
            requiredWidth = this.mDotRadius;
            i2 = paddingLeft - requiredWidth;
            i3 = this.mDotGap;
            i2 += i3;
            i4 = this.mArrowGap;
            iArr[0] = i2 - i4;
            this.mDotSelectedPrevX[0] = paddingLeft - requiredWidth;
            this.mDotSelectedNextX[0] = ((paddingLeft - requiredWidth) + (i3 * 2)) - (i4 * 2);
            while (i < this.mPageCount) {
                iArr2 = this.mDotSelectedX;
                iArr = this.mDotSelectedPrevX;
                requiredWidth = i - 1;
                i5 = iArr[requiredWidth];
                i2 = this.mArrowGap;
                iArr2[i] = i5 - i2;
                iArr[i] = iArr[requiredWidth] - this.mDotGap;
                this.mDotSelectedNextX[i] = iArr2[requiredWidth] - i2;
                i++;
            }
        }
        this.mDotCenterY = paddingTop + this.mArrowRadius;
        adjustDotPosition();
    }

    int getPageCount() {
        return this.mPageCount;
    }

    int[] getDotSelectedX() {
        return this.mDotSelectedX;
    }

    int[] getDotSelectedLeftX() {
        return this.mDotSelectedPrevX;
    }

    int[] getDotSelectedRightX() {
        return this.mDotSelectedNextX;
    }

    protected void onMeasure(int i, int i2) {
        int desiredHeight = getDesiredHeight();
        int mode = MeasureSpec.getMode(i2);
        if (mode == Integer.MIN_VALUE) {
            desiredHeight = Math.min(desiredHeight, MeasureSpec.getSize(i2));
        } else if (mode == 1073741824) {
            desiredHeight = MeasureSpec.getSize(i2);
        }
        i2 = getDesiredWidth();
        mode = MeasureSpec.getMode(i);
        if (mode == Integer.MIN_VALUE) {
            i2 = Math.min(i2, MeasureSpec.getSize(i));
        } else if (mode == 1073741824) {
            i2 = MeasureSpec.getSize(i);
        }
        setMeasuredDimension(i2, desiredHeight);
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        setMeasuredDimension(i, i2);
        calculateDotPositions();
    }

    private int getDesiredHeight() {
        return ((getPaddingTop() + this.mArrowDiameter) + getPaddingBottom()) + this.mShadowRadius;
    }

    private int getRequiredWidth() {
        return ((this.mDotRadius * 2) + (this.mArrowGap * 2)) + ((this.mPageCount - 3) * this.mDotGap);
    }

    private int getDesiredWidth() {
        return (getPaddingLeft() + getRequiredWidth()) + getPaddingRight();
    }

    protected void onDraw(Canvas canvas) {
        for (int i = 0; i < this.mPageCount; i++) {
            this.mDots[i].draw(canvas);
        }
    }

    private void setSelectedPage(int i) {
        if (i != this.mCurrentPage) {
            this.mCurrentPage = i;
            adjustDotPosition();
        }
    }

    private void adjustDotPosition() {
        int i;
        float f;
        int i2 = 0;
        while (true) {
            i = this.mCurrentPage;
            f = -1.0f;
            if (i2 >= i) {
                break;
            }
            this.mDots[i2].deselect();
            Dot dot = this.mDots[i2];
            if (i2 != this.mPreviousPage) {
                f = 1.0f;
            }
            dot.mDirection = f;
            this.mDots[i2].mCenterX = (float) this.mDotSelectedPrevX[i2];
            i2++;
        }
        this.mDots[i].select();
        Dot[] dotArr = this.mDots;
        i = this.mCurrentPage;
        Dot dot2 = dotArr[i];
        if (this.mPreviousPage >= i) {
            f = 1.0f;
        }
        dot2.mDirection = f;
        dotArr = this.mDots;
        i = this.mCurrentPage;
        dotArr[i].mCenterX = (float) this.mDotSelectedX[i];
        while (true) {
            i++;
            if (i < this.mPageCount) {
                this.mDots[i].deselect();
                dotArr = this.mDots;
                dotArr[i].mDirection = 1.0f;
                dotArr[i].mCenterX = (float) this.mDotSelectedNextX[i];
            } else {
                return;
            }
        }
    }

    public void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        boolean z = i == 0;
        if (this.mIsLtr != z) {
            this.mIsLtr = z;
            this.mArrow = loadArrow();
            i = this.mDots;
            if (i != 0) {
                for (Dot onRtlPropertiesChanged : i) {
                    onRtlPropertiesChanged.onRtlPropertiesChanged();
                }
            }
            calculateDotPositions();
            invalidate();
        }
    }
}
