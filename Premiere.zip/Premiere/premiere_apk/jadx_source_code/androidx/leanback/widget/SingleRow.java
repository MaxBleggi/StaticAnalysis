package androidx.leanback.widget;

import androidx.collection.CircularIntArray;
import androidx.leanback.widget.Grid.Location;
import java.io.PrintWriter;

class SingleRow extends Grid {
    private final Location mTmpLocation = new Location(0);

    SingleRow() {
        setNumRows(1);
    }

    public final Location getLocation(int i) {
        return this.mTmpLocation;
    }

    public final void debugPrint(PrintWriter printWriter) {
        printWriter.print("SingleRow<");
        printWriter.print(this.mFirstVisibleIndex);
        printWriter.print(",");
        printWriter.print(this.mLastVisibleIndex);
        printWriter.print(">");
        printWriter.println();
    }

    int getStartIndexForAppend() {
        if (this.mLastVisibleIndex >= 0) {
            return this.mLastVisibleIndex + 1;
        }
        return this.mStartIndex != -1 ? Math.min(this.mStartIndex, this.mProvider.getCount() - 1) : 0;
    }

    int getStartIndexForPrepend() {
        if (this.mFirstVisibleIndex >= 0) {
            return this.mFirstVisibleIndex - 1;
        }
        if (this.mStartIndex != -1) {
            return Math.min(this.mStartIndex, this.mProvider.getCount() - 1);
        }
        return this.mProvider.getCount() - 1;
    }

    protected final boolean prependVisibleItems(int i, boolean z) {
        if (this.mProvider.getCount() == 0) {
            return false;
        }
        if (!z && checkPrependOverLimit(i)) {
            return false;
        }
        int minIndex = this.mProvider.getMinIndex();
        int startIndexForPrepend = getStartIndexForPrepend();
        boolean z2 = true;
        boolean z3 = false;
        while (startIndexForPrepend >= minIndex) {
            int edge;
            int createItem = this.mProvider.createItem(startIndexForPrepend, false, this.mTmpItem, false);
            if (this.mFirstVisibleIndex >= 0) {
                if (this.mLastVisibleIndex >= 0) {
                    if (this.mReversedFlow) {
                        edge = (this.mProvider.getEdge(startIndexForPrepend + 1) + this.mSpacing) + createItem;
                    } else {
                        edge = (this.mProvider.getEdge(startIndexForPrepend + 1) - this.mSpacing) - createItem;
                    }
                    this.mFirstVisibleIndex = startIndexForPrepend;
                    this.mProvider.addItem(this.mTmpItem[0], startIndexForPrepend, createItem, 0, edge);
                    if (!z) {
                        break;
                    } else if (checkPrependOverLimit(i)) {
                        break;
                    } else {
                        startIndexForPrepend--;
                        z3 = true;
                    }
                }
            }
            edge = this.mReversedFlow ? Integer.MIN_VALUE : Integer.MAX_VALUE;
            this.mFirstVisibleIndex = startIndexForPrepend;
            this.mLastVisibleIndex = startIndexForPrepend;
            this.mProvider.addItem(this.mTmpItem[0], startIndexForPrepend, createItem, 0, edge);
            if (!z) {
                if (checkPrependOverLimit(i)) {
                    break;
                }
                startIndexForPrepend--;
                z3 = true;
            } else {
                break;
            }
        }
        z2 = z3;
        return z2;
    }

    protected final boolean appendVisibleItems(int i, boolean z) {
        if (this.mProvider.getCount() == 0) {
            return false;
        }
        if (!z && checkAppendOverLimit(i)) {
            return false;
        }
        int startIndexForAppend = getStartIndexForAppend();
        boolean z2 = true;
        boolean z3 = false;
        while (startIndexForAppend < this.mProvider.getCount()) {
            int edge;
            int createItem = this.mProvider.createItem(startIndexForAppend, true, this.mTmpItem, false);
            if (this.mFirstVisibleIndex >= 0) {
                if (this.mLastVisibleIndex >= 0) {
                    int i2;
                    if (this.mReversedFlow) {
                        i2 = startIndexForAppend - 1;
                        edge = (this.mProvider.getEdge(i2) - this.mProvider.getSize(i2)) - this.mSpacing;
                    } else {
                        i2 = startIndexForAppend - 1;
                        edge = (this.mProvider.getEdge(i2) + this.mProvider.getSize(i2)) + this.mSpacing;
                    }
                    this.mLastVisibleIndex = startIndexForAppend;
                    this.mProvider.addItem(this.mTmpItem[0], startIndexForAppend, createItem, 0, edge);
                    if (!z) {
                        break;
                    } else if (checkAppendOverLimit(i)) {
                        break;
                    } else {
                        startIndexForAppend++;
                        z3 = true;
                    }
                }
            }
            edge = this.mReversedFlow ? Integer.MAX_VALUE : Integer.MIN_VALUE;
            this.mFirstVisibleIndex = startIndexForAppend;
            this.mLastVisibleIndex = startIndexForAppend;
            this.mProvider.addItem(this.mTmpItem[0], startIndexForAppend, createItem, 0, edge);
            if (!z) {
                if (checkAppendOverLimit(i)) {
                    break;
                }
                startIndexForAppend++;
                z3 = true;
            } else {
                break;
            }
        }
        z2 = z3;
        return z2;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void collectAdjacentPrefetchPositions(int r4, int r5, androidx.recyclerview.widget.RecyclerView.LayoutManager.LayoutPrefetchRegistry r6) {
        /*
        r3 = this;
        r0 = r3.mReversedFlow;
        if (r0 == 0) goto L_0x0007;
    L_0x0004:
        if (r5 <= 0) goto L_0x0028;
    L_0x0006:
        goto L_0x0009;
    L_0x0007:
        if (r5 >= 0) goto L_0x0028;
    L_0x0009:
        r5 = r3.getFirstVisibleIndex();
        if (r5 != 0) goto L_0x0010;
    L_0x000f:
        return;
    L_0x0010:
        r5 = r3.getStartIndexForPrepend();
        r0 = r3.mProvider;
        r1 = r3.mFirstVisibleIndex;
        r0 = r0.getEdge(r1);
        r1 = r3.mReversedFlow;
        if (r1 == 0) goto L_0x0023;
    L_0x0020:
        r1 = r3.mSpacing;
        goto L_0x0026;
    L_0x0023:
        r1 = r3.mSpacing;
        r1 = -r1;
    L_0x0026:
        r0 = r0 + r1;
        goto L_0x0054;
    L_0x0028:
        r5 = r3.getLastVisibleIndex();
        r0 = r3.mProvider;
        r0 = r0.getCount();
        r0 = r0 + -1;
        if (r5 != r0) goto L_0x0037;
    L_0x0036:
        return;
    L_0x0037:
        r5 = r3.getStartIndexForAppend();
        r0 = r3.mProvider;
        r1 = r3.mLastVisibleIndex;
        r0 = r0.getSize(r1);
        r1 = r3.mSpacing;
        r0 = r0 + r1;
        r1 = r3.mProvider;
        r2 = r3.mLastVisibleIndex;
        r1 = r1.getEdge(r2);
        r2 = r3.mReversedFlow;
        if (r2 == 0) goto L_0x0053;
    L_0x0052:
        r0 = -r0;
    L_0x0053:
        r0 = r0 + r1;
    L_0x0054:
        r0 = r0 - r4;
        r4 = java.lang.Math.abs(r0);
        r6.addPosition(r5, r4);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.SingleRow.collectAdjacentPrefetchPositions(int, int, androidx.recyclerview.widget.RecyclerView$LayoutManager$LayoutPrefetchRegistry):void");
    }

    public final CircularIntArray[] getItemPositionsInRows(int i, int i2) {
        this.mTmpItemPositionsInRows[0].clear();
        this.mTmpItemPositionsInRows[0].addLast(i);
        this.mTmpItemPositionsInRows[0].addLast(i2);
        return this.mTmpItemPositionsInRows;
    }

    protected final int findRowMin(boolean z, int i, int[] iArr) {
        if (iArr != null) {
            iArr[0] = 0;
            iArr[true] = i;
        }
        if (this.mReversedFlow) {
            return this.mProvider.getEdge(i) - this.mProvider.getSize(i);
        }
        return this.mProvider.getEdge(i);
    }

    protected final int findRowMax(boolean z, int i, int[] iArr) {
        if (iArr != null) {
            iArr[0] = 0;
            iArr[true] = i;
        }
        if (this.mReversedFlow) {
            return this.mProvider.getEdge(i);
        }
        return this.mProvider.getEdge(i) + this.mProvider.getSize(i);
    }
}
