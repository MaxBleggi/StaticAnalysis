package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import androidx.leanback.R;

public class ThumbsBar extends LinearLayout {
    final SparseArray<Bitmap> mBitmaps;
    int mHeroThumbHeightInPixel;
    int mHeroThumbWidthInPixel;
    private boolean mIsUserSets;
    int mMeasuredMarginInPixel;
    int mNumOfThumbs;
    int mThumbHeightInPixel;
    int mThumbWidthInPixel;

    public ThumbsBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ThumbsBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mNumOfThumbs = -1;
        this.mBitmaps = new SparseArray();
        this.mIsUserSets = null;
        this.mThumbWidthInPixel = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_thumbs_width);
        this.mThumbHeightInPixel = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_thumbs_height);
        this.mHeroThumbHeightInPixel = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_hero_thumbs_width);
        this.mHeroThumbWidthInPixel = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_hero_thumbs_height);
        this.mMeasuredMarginInPixel = context.getResources().getDimensionPixelSize(R.dimen.lb_playback_transport_thumbs_margin);
    }

    public int getHeroIndex() {
        return getChildCount() / 2;
    }

    public void setThumbSize(int i, int i2) {
        this.mThumbHeightInPixel = i2;
        this.mThumbWidthInPixel = i;
        int heroIndex = getHeroIndex();
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            if (heroIndex != i3) {
                Object obj;
                View childAt = getChildAt(i3);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.height != i2) {
                    layoutParams.height = i2;
                    obj = 1;
                } else {
                    obj = null;
                }
                if (layoutParams.width != i) {
                    layoutParams.width = i;
                    obj = 1;
                }
                if (obj != null) {
                    childAt.setLayoutParams(layoutParams);
                }
            }
        }
    }

    public void setHeroThumbSize(int i, int i2) {
        this.mHeroThumbHeightInPixel = i2;
        this.mHeroThumbWidthInPixel = i;
        int heroIndex = getHeroIndex();
        for (int i3 = 0; i3 < getChildCount(); i3++) {
            if (heroIndex == i3) {
                Object obj;
                View childAt = getChildAt(i3);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.height != i2) {
                    layoutParams.height = i2;
                    obj = 1;
                } else {
                    obj = null;
                }
                if (layoutParams.width != i) {
                    layoutParams.width = i;
                    obj = 1;
                }
                if (obj != null) {
                    childAt.setLayoutParams(layoutParams);
                }
            }
        }
    }

    public void setThumbSpace(int i) {
        this.mMeasuredMarginInPixel = i;
        requestLayout();
    }

    public void setNumberOfThumbs(int i) {
        this.mIsUserSets = true;
        this.mNumOfThumbs = i;
        setNumberOfThumbsInternal();
    }

    private void setNumberOfThumbsInternal() {
        while (getChildCount() > this.mNumOfThumbs) {
            removeView(getChildAt(getChildCount() - 1));
        }
        while (getChildCount() < this.mNumOfThumbs) {
            addView(createThumbView(this), new LayoutParams(this.mThumbWidthInPixel, this.mThumbHeightInPixel));
        }
        int heroIndex = getHeroIndex();
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (heroIndex == i) {
                layoutParams.width = this.mHeroThumbWidthInPixel;
                layoutParams.height = this.mHeroThumbHeightInPixel;
            } else {
                layoutParams.width = this.mThumbWidthInPixel;
                layoutParams.height = this.mThumbHeightInPixel;
            }
            childAt.setLayoutParams(layoutParams);
        }
    }

    private static int roundUp(int i, int i2) {
        return ((i + i2) - 1) / i2;
    }

    private int calculateNumOfThumbs(int i) {
        i = roundUp(i - this.mHeroThumbWidthInPixel, this.mThumbWidthInPixel + this.mMeasuredMarginInPixel);
        if (i < 2) {
            i = 2;
        } else if ((i & 1) != 0) {
            i++;
        }
        return i + 1;
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        i = getMeasuredWidth();
        if (this.mIsUserSets == 0) {
            i = calculateNumOfThumbs(i);
            if (this.mNumOfThumbs != i) {
                this.mNumOfThumbs = i;
                setNumberOfThumbsInternal();
            }
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        z = getHeroIndex();
        i = getChildAt(z);
        i2 = (getWidth() / 2) - (i.getMeasuredWidth() / 2);
        i3 = (getWidth() / 2) + (i.getMeasuredWidth() / 2);
        i.layout(i2, getPaddingTop(), i3, getPaddingTop() + i.getMeasuredHeight());
        i4 = getPaddingTop() + (i.getMeasuredHeight() / 2);
        for (i = z - 1; i >= 0; i--) {
            i2 -= this.mMeasuredMarginInPixel;
            View childAt = getChildAt(i);
            childAt.layout(i2 - childAt.getMeasuredWidth(), i4 - (childAt.getMeasuredHeight() / 2), i2, (childAt.getMeasuredHeight() / 2) + i4);
            i2 -= childAt.getMeasuredWidth();
        }
        while (true) {
            z++;
            if (z < this.mNumOfThumbs) {
                i3 += this.mMeasuredMarginInPixel;
                i = getChildAt(z);
                i.layout(i3, i4 - (i.getMeasuredHeight() / 2), i.getMeasuredWidth() + i3, (i.getMeasuredHeight() / 2) + i4);
                i3 += i.getMeasuredWidth();
            } else {
                return;
            }
        }
    }

    protected View createThumbView(ViewGroup viewGroup) {
        return new ImageView(viewGroup.getContext());
    }

    public void clearThumbBitmaps() {
        for (int i = 0; i < getChildCount(); i++) {
            setThumbBitmap(i, null);
        }
        this.mBitmaps.clear();
    }

    public Bitmap getThumbBitmap(int i) {
        return (Bitmap) this.mBitmaps.get(i);
    }

    public void setThumbBitmap(int i, Bitmap bitmap) {
        this.mBitmaps.put(i, bitmap);
        ((ImageView) getChildAt(i)).setImageBitmap(bitmap);
    }
}
