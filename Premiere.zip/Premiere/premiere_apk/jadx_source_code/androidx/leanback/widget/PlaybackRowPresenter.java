package androidx.leanback.widget;

import android.view.View;

public abstract class PlaybackRowPresenter extends RowPresenter {

    public static class ViewHolder extends androidx.leanback.widget.RowPresenter.ViewHolder {
        public ViewHolder(View view) {
            super(view);
        }
    }

    public void onReappear(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
    }
}
