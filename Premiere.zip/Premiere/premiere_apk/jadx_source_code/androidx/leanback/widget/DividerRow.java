package androidx.leanback.widget;

public class DividerRow extends Row {
    public final boolean isRenderedAsRowView() {
        return false;
    }
}
