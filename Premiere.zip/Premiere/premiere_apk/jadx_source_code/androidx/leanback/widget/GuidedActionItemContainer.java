package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

class GuidedActionItemContainer extends NonOverlappingLinearLayoutWithForeground {
    private boolean mFocusOutAllowed;

    public GuidedActionItemContainer(Context context) {
        this(context, null);
    }

    public GuidedActionItemContainer(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public GuidedActionItemContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mFocusOutAllowed = true;
    }

    public View focusSearch(View view, int i) {
        if (!this.mFocusOutAllowed) {
            if (Util.isDescendant(this, view)) {
                view = super.focusSearch(view, i);
                return Util.isDescendant(this, view) != 0 ? view : null;
            }
        }
        return super.focusSearch(view, i);
    }

    public void setFocusOutAllowed(boolean z) {
        this.mFocusOutAllowed = z;
    }
}
