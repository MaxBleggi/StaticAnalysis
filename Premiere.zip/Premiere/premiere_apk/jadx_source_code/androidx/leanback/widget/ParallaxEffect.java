package androidx.leanback.widget;

import android.animation.PropertyValuesHolder;
import android.util.Property;
import androidx.leanback.widget.Parallax.FloatProperty;
import androidx.leanback.widget.Parallax.IntProperty;
import androidx.leanback.widget.Parallax.PropertyMarkerValue;
import androidx.leanback.widget.ParallaxTarget.DirectPropertyTarget;
import androidx.leanback.widget.ParallaxTarget.PropertyValuesHolderTarget;
import java.util.ArrayList;
import java.util.List;

public abstract class ParallaxEffect {
    final List<PropertyMarkerValue> mMarkerValues = new ArrayList(2);
    final List<ParallaxTarget> mTargets = new ArrayList(4);
    final List<Float> mTotalWeights = new ArrayList(2);
    final List<Float> mWeights = new ArrayList(2);

    static final class FloatEffect extends ParallaxEffect {
        FloatEffect() {
        }

        Number calculateDirectValue(Parallax parallax) {
            if (this.mMarkerValues.size() != 2) {
                throw new RuntimeException("Must use two marker values for direct mapping");
            } else if (((PropertyMarkerValue) this.mMarkerValues.get(0)).getProperty() == ((PropertyMarkerValue) this.mMarkerValues.get(1)).getProperty()) {
                float markerValue = ((FloatPropertyMarkerValue) this.mMarkerValues.get(0)).getMarkerValue(parallax);
                float markerValue2 = ((FloatPropertyMarkerValue) this.mMarkerValues.get(1)).getMarkerValue(parallax);
                if (markerValue > markerValue2) {
                    float f = markerValue2;
                    markerValue2 = markerValue;
                    markerValue = f;
                }
                parallax = ((FloatProperty) ((PropertyMarkerValue) this.mMarkerValues.get(0)).getProperty()).get(parallax);
                if (parallax.floatValue() < markerValue) {
                    return Float.valueOf(markerValue);
                }
                if (parallax.floatValue() > markerValue2) {
                    return Float.valueOf(markerValue2);
                }
                return parallax;
            } else {
                throw new RuntimeException("Marker value must use same Property for direct mapping");
            }
        }

        float calculateFraction(Parallax parallax) {
            int i = 0;
            int i2 = 0;
            float f = 0.0f;
            float f2 = 0.0f;
            while (i < this.mMarkerValues.size()) {
                FloatPropertyMarkerValue floatPropertyMarkerValue = (FloatPropertyMarkerValue) this.mMarkerValues.get(i);
                int index = ((FloatProperty) floatPropertyMarkerValue.getProperty()).getIndex();
                float markerValue = floatPropertyMarkerValue.getMarkerValue(parallax);
                float floatPropertyValue = parallax.getFloatPropertyValue(index);
                if (i != 0) {
                    if (i2 == index) {
                        if (f < markerValue) {
                            throw new IllegalStateException("marker value of same variable must be descendant order");
                        }
                    }
                    if (floatPropertyValue == Float.MAX_VALUE) {
                        return getFractionWithWeightAdjusted((f - f2) / parallax.getMaxValue(), i);
                    }
                    if (floatPropertyValue >= markerValue) {
                        if (i2 != index) {
                            if (f2 != FloatProperty.UNKNOWN_BEFORE) {
                                f += floatPropertyValue - f2;
                            } else {
                                parallax = 1065353216 - ((floatPropertyValue - markerValue) / parallax.getMaxValue());
                                return getFractionWithWeightAdjusted(parallax, i);
                            }
                        }
                        parallax = (f - floatPropertyValue) / (f - markerValue);
                        return getFractionWithWeightAdjusted(parallax, i);
                    }
                } else if (floatPropertyValue >= markerValue) {
                    return 0.0f;
                }
                i++;
                f = markerValue;
                i2 = index;
                f2 = floatPropertyValue;
            }
            return 1.0f;
        }
    }

    static final class IntEffect extends ParallaxEffect {
        IntEffect() {
        }

        Number calculateDirectValue(Parallax parallax) {
            if (this.mMarkerValues.size() != 2) {
                throw new RuntimeException("Must use two marker values for direct mapping");
            } else if (((PropertyMarkerValue) this.mMarkerValues.get(0)).getProperty() == ((PropertyMarkerValue) this.mMarkerValues.get(1)).getProperty()) {
                int markerValue = ((IntPropertyMarkerValue) this.mMarkerValues.get(0)).getMarkerValue(parallax);
                int markerValue2 = ((IntPropertyMarkerValue) this.mMarkerValues.get(1)).getMarkerValue(parallax);
                if (markerValue > markerValue2) {
                    int i = markerValue2;
                    markerValue2 = markerValue;
                    markerValue = i;
                }
                parallax = ((IntProperty) ((PropertyMarkerValue) this.mMarkerValues.get(0)).getProperty()).get(parallax);
                if (parallax.intValue() < markerValue) {
                    return Integer.valueOf(markerValue);
                }
                if (parallax.intValue() > markerValue2) {
                    return Integer.valueOf(markerValue2);
                }
                return parallax;
            } else {
                throw new RuntimeException("Marker value must use same Property for direct mapping");
            }
        }

        float calculateFraction(Parallax parallax) {
            int i = 0;
            int i2 = 0;
            int i3 = 0;
            int i4 = 0;
            while (i < this.mMarkerValues.size()) {
                IntPropertyMarkerValue intPropertyMarkerValue = (IntPropertyMarkerValue) this.mMarkerValues.get(i);
                int index = ((IntProperty) intPropertyMarkerValue.getProperty()).getIndex();
                int markerValue = intPropertyMarkerValue.getMarkerValue(parallax);
                int intPropertyValue = parallax.getIntPropertyValue(index);
                if (i != 0) {
                    if (i2 == index) {
                        if (i3 < markerValue) {
                            throw new IllegalStateException("marker value of same variable must be descendant order");
                        }
                    }
                    if (intPropertyValue == Integer.MAX_VALUE) {
                        return getFractionWithWeightAdjusted(((float) (i3 - i4)) / parallax.getMaxValue(), i);
                    }
                    if (intPropertyValue >= markerValue) {
                        if (i2 != index) {
                            if (i4 != Integer.MIN_VALUE) {
                                i3 += intPropertyValue - i4;
                            } else {
                                parallax = 1065353216 - (((float) (intPropertyValue - markerValue)) / parallax.getMaxValue());
                                return getFractionWithWeightAdjusted(parallax, i);
                            }
                        }
                        parallax = ((float) (i3 - intPropertyValue)) / ((float) (i3 - markerValue));
                        return getFractionWithWeightAdjusted(parallax, i);
                    }
                } else if (intPropertyValue >= markerValue) {
                    return null;
                }
                i++;
                i3 = markerValue;
                i2 = index;
                i4 = intPropertyValue;
            }
            return 1.0f;
        }
    }

    abstract Number calculateDirectValue(Parallax parallax);

    abstract float calculateFraction(Parallax parallax);

    ParallaxEffect() {
    }

    public final List<PropertyMarkerValue> getPropertyRanges() {
        return this.mMarkerValues;
    }

    public final List<Float> getWeights() {
        return this.mWeights;
    }

    public final void setPropertyRanges(PropertyMarkerValue... propertyMarkerValueArr) {
        this.mMarkerValues.clear();
        for (Object add : propertyMarkerValueArr) {
            this.mMarkerValues.add(add);
        }
    }

    public final void setWeights(float... fArr) {
        int length = fArr.length;
        int i = 0;
        while (true) {
            float f = 0.0f;
            if (i >= length) {
                break;
            } else if (fArr[i] > 0.0f) {
                i++;
            } else {
                throw new IllegalArgumentException();
            }
        }
        this.mWeights.clear();
        this.mTotalWeights.clear();
        for (float f2 : fArr) {
            this.mWeights.add(Float.valueOf(f2));
            f += f2;
            this.mTotalWeights.add(Float.valueOf(f));
        }
    }

    public final ParallaxEffect weights(float... fArr) {
        setWeights(fArr);
        return this;
    }

    public final void addTarget(ParallaxTarget parallaxTarget) {
        this.mTargets.add(parallaxTarget);
    }

    public final ParallaxEffect target(ParallaxTarget parallaxTarget) {
        this.mTargets.add(parallaxTarget);
        return this;
    }

    public final ParallaxEffect target(Object obj, PropertyValuesHolder propertyValuesHolder) {
        this.mTargets.add(new PropertyValuesHolderTarget(obj, propertyValuesHolder));
        return this;
    }

    public final <T, V extends Number> ParallaxEffect target(T t, Property<T, V> property) {
        this.mTargets.add(new DirectPropertyTarget(t, property));
        return this;
    }

    public final List<ParallaxTarget> getTargets() {
        return this.mTargets;
    }

    public final void removeTarget(ParallaxTarget parallaxTarget) {
        this.mTargets.remove(parallaxTarget);
    }

    public final void performMapping(Parallax parallax) {
        if (this.mMarkerValues.size() >= 2) {
            if (this instanceof IntEffect) {
                parallax.verifyIntProperties();
            } else {
                parallax.verifyFloatProperties();
            }
            Number number = null;
            Object obj = null;
            float f = 0.0f;
            for (int i = 0; i < this.mTargets.size(); i++) {
                ParallaxTarget parallaxTarget = (ParallaxTarget) this.mTargets.get(i);
                if (parallaxTarget.isDirectMapping()) {
                    if (number == null) {
                        number = calculateDirectValue(parallax);
                    }
                    parallaxTarget.directUpdate(number);
                } else {
                    if (obj == null) {
                        f = calculateFraction(parallax);
                        obj = 1;
                    }
                    parallaxTarget.update(f);
                }
            }
        }
    }

    final float getFractionWithWeightAdjusted(float f, int i) {
        if (this.mMarkerValues.size() < 3) {
            return f;
        }
        float floatValue;
        if ((this.mWeights.size() == this.mMarkerValues.size() - 1 ? 1 : null) != null) {
            List list = this.mTotalWeights;
            floatValue = ((Float) list.get(list.size() - 1)).floatValue();
            f = (f * ((Float) this.mWeights.get(i - 1)).floatValue()) / floatValue;
            if (i < 2) {
                return f;
            }
            i = ((Float) this.mTotalWeights.get(i - 2)).floatValue();
        } else {
            floatValue = (float) (this.mMarkerValues.size() - 1);
            f /= floatValue;
            if (i < 2) {
                return f;
            }
            i = (float) (i - 1);
        }
        return f + (i / floatValue);
    }
}
