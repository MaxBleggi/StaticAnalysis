package androidx.leanback.widget;

import android.content.Context;
import android.text.Layout;
import android.util.AttributeSet;
import android.view.ActionMode.Callback;
import android.widget.TextView;
import androidx.core.widget.TextViewCompat;
import androidx.leanback.R;

class ResizingTextView extends TextView {
    public static final int TRIGGER_MAX_LINES = 1;
    private float mDefaultLineSpacingExtra;
    private int mDefaultPaddingBottom;
    private int mDefaultPaddingTop;
    private int mDefaultTextSize;
    private boolean mDefaultsInitialized;
    private boolean mIsResized;
    private boolean mMaintainLineSpacing;
    private int mResizedPaddingAdjustmentBottom;
    private int mResizedPaddingAdjustmentTop;
    private int mResizedTextSize;
    private int mTriggerConditions;

    public ResizingTextView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i);
        this.mIsResized = false;
        this.mDefaultsInitialized = false;
        context = context.obtainStyledAttributes(attributeSet, R.styleable.lbResizingTextView, i, i2);
        try {
            this.mTriggerConditions = context.getInt(R.styleable.lbResizingTextView_resizeTrigger, 1);
            this.mResizedTextSize = context.getDimensionPixelSize(R.styleable.lbResizingTextView_resizedTextSize, -1);
            this.mMaintainLineSpacing = context.getBoolean(R.styleable.lbResizingTextView_maintainLineSpacing, false);
            this.mResizedPaddingAdjustmentTop = context.getDimensionPixelOffset(R.styleable.lbResizingTextView_resizedPaddingAdjustmentTop, 0);
            this.mResizedPaddingAdjustmentBottom = context.getDimensionPixelOffset(R.styleable.lbResizingTextView_resizedPaddingAdjustmentBottom, 0);
        } finally {
            context.recycle();
        }
    }

    public ResizingTextView(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public ResizingTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public ResizingTextView(Context context) {
        this(context, null);
    }

    public int getTriggerConditions() {
        return this.mTriggerConditions;
    }

    public void setTriggerConditions(int i) {
        if (this.mTriggerConditions != i) {
            this.mTriggerConditions = i;
            requestLayout();
        }
    }

    public int getResizedTextSize() {
        return this.mResizedTextSize;
    }

    public void setResizedTextSize(int i) {
        if (this.mResizedTextSize != i) {
            this.mResizedTextSize = i;
            resizeParamsChanged();
        }
    }

    public boolean getMaintainLineSpacing() {
        return this.mMaintainLineSpacing;
    }

    public void setMaintainLineSpacing(boolean z) {
        if (this.mMaintainLineSpacing != z) {
            this.mMaintainLineSpacing = z;
            resizeParamsChanged();
        }
    }

    public int getResizedPaddingAdjustmentTop() {
        return this.mResizedPaddingAdjustmentTop;
    }

    public void setResizedPaddingAdjustmentTop(int i) {
        if (this.mResizedPaddingAdjustmentTop != i) {
            this.mResizedPaddingAdjustmentTop = i;
            resizeParamsChanged();
        }
    }

    public int getResizedPaddingAdjustmentBottom() {
        return this.mResizedPaddingAdjustmentBottom;
    }

    public void setResizedPaddingAdjustmentBottom(int i) {
        if (this.mResizedPaddingAdjustmentBottom != i) {
            this.mResizedPaddingAdjustmentBottom = i;
            resizeParamsChanged();
        }
    }

    private void resizeParamsChanged() {
        if (this.mIsResized) {
            requestLayout();
        }
    }

    protected void onMeasure(int i, int i2) {
        int maxLines;
        boolean z;
        int i3;
        float lineSpacingExtra;
        float f;
        int i4;
        boolean z2 = true;
        if (!this.mDefaultsInitialized) {
            this.mDefaultTextSize = (int) getTextSize();
            this.mDefaultLineSpacingExtra = getLineSpacingExtra();
            this.mDefaultPaddingTop = getPaddingTop();
            this.mDefaultPaddingBottom = getPaddingBottom();
            this.mDefaultsInitialized = true;
        }
        boolean z3 = false;
        setTextSize(0, (float) this.mDefaultTextSize);
        setLineSpacing(this.mDefaultLineSpacingExtra, getLineSpacingMultiplier());
        setPaddingTopAndBottom(this.mDefaultPaddingTop, this.mDefaultPaddingBottom);
        super.onMeasure(i, i2);
        Layout layout = getLayout();
        if (layout != null && (this.mTriggerConditions & 1) > 0) {
            int lineCount = layout.getLineCount();
            maxLines = getMaxLines();
            if (maxLines > 1 && lineCount == maxLines) {
                z = true;
                maxLines = (int) getTextSize();
                if (z) {
                    if (this.mResizedTextSize != -1) {
                        i3 = this.mDefaultTextSize;
                        if (maxLines != i3) {
                            setTextSize(0, (float) i3);
                            z3 = true;
                        }
                    }
                    if (this.mMaintainLineSpacing) {
                        lineSpacingExtra = getLineSpacingExtra();
                        f = this.mDefaultLineSpacingExtra;
                        if (lineSpacingExtra != f) {
                            setLineSpacing(f, getLineSpacingMultiplier());
                            z3 = true;
                        }
                    }
                    if (getPaddingTop() == this.mDefaultPaddingTop) {
                        if (getPaddingBottom() != this.mDefaultPaddingBottom) {
                        }
                    }
                    setPaddingTopAndBottom(this.mDefaultPaddingTop, this.mDefaultPaddingBottom);
                    this.mIsResized = z;
                    if (z2) {
                        super.onMeasure(i, i2);
                    }
                }
                i4 = this.mResizedTextSize;
                if (!(i4 == -1 || maxLines == i4)) {
                    setTextSize(0, (float) i4);
                    z3 = true;
                }
                lineSpacingExtra = (this.mDefaultLineSpacingExtra + ((float) this.mDefaultTextSize)) - ((float) this.mResizedTextSize);
                if (this.mMaintainLineSpacing && getLineSpacingExtra() != lineSpacingExtra) {
                    setLineSpacing(lineSpacingExtra, getLineSpacingMultiplier());
                    z3 = true;
                }
                maxLines = this.mDefaultPaddingTop + this.mResizedPaddingAdjustmentTop;
                i3 = this.mDefaultPaddingBottom + this.mResizedPaddingAdjustmentBottom;
                if (!(getPaddingTop() == maxLines && getPaddingBottom() == i3)) {
                    setPaddingTopAndBottom(maxLines, i3);
                    this.mIsResized = z;
                    if (z2) {
                        super.onMeasure(i, i2);
                    }
                }
                z2 = z3;
                this.mIsResized = z;
                if (z2) {
                    super.onMeasure(i, i2);
                }
            }
        }
        z = false;
        maxLines = (int) getTextSize();
        if (z) {
            if (this.mResizedTextSize != -1) {
                i3 = this.mDefaultTextSize;
                if (maxLines != i3) {
                    setTextSize(0, (float) i3);
                    z3 = true;
                }
            }
            if (this.mMaintainLineSpacing) {
                lineSpacingExtra = getLineSpacingExtra();
                f = this.mDefaultLineSpacingExtra;
                if (lineSpacingExtra != f) {
                    setLineSpacing(f, getLineSpacingMultiplier());
                    z3 = true;
                }
            }
            if (getPaddingTop() == this.mDefaultPaddingTop) {
                if (getPaddingBottom() != this.mDefaultPaddingBottom) {
                }
            }
            setPaddingTopAndBottom(this.mDefaultPaddingTop, this.mDefaultPaddingBottom);
            this.mIsResized = z;
            if (z2) {
                super.onMeasure(i, i2);
            }
        }
        i4 = this.mResizedTextSize;
        setTextSize(0, (float) i4);
        z3 = true;
        lineSpacingExtra = (this.mDefaultLineSpacingExtra + ((float) this.mDefaultTextSize)) - ((float) this.mResizedTextSize);
        setLineSpacing(lineSpacingExtra, getLineSpacingMultiplier());
        z3 = true;
        maxLines = this.mDefaultPaddingTop + this.mResizedPaddingAdjustmentTop;
        i3 = this.mDefaultPaddingBottom + this.mResizedPaddingAdjustmentBottom;
        setPaddingTopAndBottom(maxLines, i3);
        this.mIsResized = z;
        if (z2) {
            super.onMeasure(i, i2);
        }
        z2 = z3;
        this.mIsResized = z;
        if (z2) {
            super.onMeasure(i, i2);
        }
    }

    private void setPaddingTopAndBottom(int i, int i2) {
        if (isPaddingRelative()) {
            setPaddingRelative(getPaddingStart(), i, getPaddingEnd(), i2);
        } else {
            setPadding(getPaddingLeft(), i, getPaddingRight(), i2);
        }
    }

    public void setCustomSelectionActionModeCallback(Callback callback) {
        super.setCustomSelectionActionModeCallback(TextViewCompat.wrapCustomSelectionActionModeCallback(this, callback));
    }
}
