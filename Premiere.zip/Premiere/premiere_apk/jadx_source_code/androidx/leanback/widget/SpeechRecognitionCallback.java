package androidx.leanback.widget;

@Deprecated
public interface SpeechRecognitionCallback {
    void recognizeSpeech();
}
