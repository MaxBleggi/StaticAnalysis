package androidx.leanback.widget;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MediaNowPlayingView extends LinearLayout {
    private final ImageView mImage1;
    private final ImageView mImage2;
    private final ImageView mImage3;
    protected final LinearInterpolator mLinearInterpolator = new LinearInterpolator();
    private final ObjectAnimator mObjectAnimator1;
    private final ObjectAnimator mObjectAnimator2;
    private final ObjectAnimator mObjectAnimator3;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public MediaNowPlayingView(android.content.Context r4, android.util.AttributeSet r5) {
        /*
        r3 = this;
        r3.<init>(r4, r5);
        r5 = new android.view.animation.LinearInterpolator;
        r5.<init>();
        r3.mLinearInterpolator = r5;
        r4 = android.view.LayoutInflater.from(r4);
        r5 = androidx.leanback.R.layout.lb_playback_now_playing_bars;
        r0 = 1;
        r4.inflate(r5, r3, r0);
        r4 = androidx.leanback.R.id.bar1;
        r4 = r3.findViewById(r4);
        r4 = (android.widget.ImageView) r4;
        r3.mImage1 = r4;
        r4 = androidx.leanback.R.id.bar2;
        r4 = r3.findViewById(r4);
        r4 = (android.widget.ImageView) r4;
        r3.mImage2 = r4;
        r4 = androidx.leanback.R.id.bar3;
        r4 = r3.findViewById(r4);
        r4 = (android.widget.ImageView) r4;
        r3.mImage3 = r4;
        r4 = r3.mImage1;
        r5 = r4.getDrawable();
        r5 = r5.getIntrinsicHeight();
        r5 = (float) r5;
        r4.setPivotY(r5);
        r4 = r3.mImage2;
        r5 = r4.getDrawable();
        r5 = r5.getIntrinsicHeight();
        r5 = (float) r5;
        r4.setPivotY(r5);
        r4 = r3.mImage3;
        r5 = r4.getDrawable();
        r5 = r5.getIntrinsicHeight();
        r5 = (float) r5;
        r4.setPivotY(r5);
        r4 = r3.mImage1;
        setDropScale(r4);
        r4 = r3.mImage2;
        setDropScale(r4);
        r4 = r3.mImage3;
        setDropScale(r4);
        r4 = r3.mImage1;
        r5 = 30;
        r5 = new float[r5];
        r5 = {1054168405, 1048576000, 1054168405, 1058362709, 1061158912, 1062557013, 1063955115, 1065353216, 1063955115, 1065353216, 1062557013, 1059760811, 1056964608, 1051372203, 1042983595, 1051372203, 1056964608, 1058362709, 1061158912, 1063955115, 1061158912, 1058362709, 1054168405, 1048576000, 1054168405, 1059760811, 1054168405, 1048576000, 1051372203, 1054168405};
        r0 = "scaleY";
        r4 = android.animation.ObjectAnimator.ofFloat(r4, r0, r5);
        r3.mObjectAnimator1 = r4;
        r4 = r3.mObjectAnimator1;
        r5 = -1;
        r4.setRepeatCount(r5);
        r4 = r3.mObjectAnimator1;
        r1 = 2320; // 0x910 float:3.251E-42 double:1.146E-320;
        r4.setDuration(r1);
        r4 = r3.mObjectAnimator1;
        r1 = r3.mLinearInterpolator;
        r4.setInterpolator(r1);
        r4 = r3.mImage2;
        r1 = 27;
        r1 = new float[r1];
        r1 = {1065353216, 1063955115, 1062557013, 1063955115, 1065353216, 1063955115, 1061158912, 1058362709, 1061158912, 1063955115, 1065353216, 1062557013, 1059760811, 1062557013, 1065353216, 1063955115, 1061158912, 1054168405, 1048576000, 1054168405, 1059760811, 1062557013, 1065353216, 1062557013, 1061158912, 1059760811, 1065353216};
        r4 = android.animation.ObjectAnimator.ofFloat(r4, r0, r1);
        r3.mObjectAnimator2 = r4;
        r4 = r3.mObjectAnimator2;
        r4.setRepeatCount(r5);
        r4 = r3.mObjectAnimator2;
        r1 = 2080; // 0x820 float:2.915E-42 double:1.0277E-320;
        r4.setDuration(r1);
        r4 = r3.mObjectAnimator2;
        r1 = r3.mLinearInterpolator;
        r4.setInterpolator(r1);
        r4 = r3.mImage3;
        r1 = 26;
        r1 = new float[r1];
        r1 = {1059760811, 1061158912, 1062557013, 1065353216, 1063955115, 1061158912, 1058362709, 1054168405, 1058362709, 1059760811, 1061158912, 1065353216, 1063955115, 1065353216, 1061158912, 1058362709, 1061158912, 1063955115, 1065353216, 1062557013, 1059760811, 1061158912, 1058362709, 1054168405, 1048576000, 1059760811};
        r4 = android.animation.ObjectAnimator.ofFloat(r4, r0, r1);
        r3.mObjectAnimator3 = r4;
        r4 = r3.mObjectAnimator3;
        r4.setRepeatCount(r5);
        r4 = r3.mObjectAnimator3;
        r0 = 2000; // 0x7d0 float:2.803E-42 double:9.88E-321;
        r4.setDuration(r0);
        r4 = r3.mObjectAnimator3;
        r5 = r3.mLinearInterpolator;
        r4.setInterpolator(r5);
        return;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.MediaNowPlayingView.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    static void setDropScale(View view) {
        view.setScaleY(0.083333336f);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        if (i == 8) {
            stopAnimation();
        } else {
            startAnimation();
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (getVisibility() == 0) {
            startAnimation();
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopAnimation();
    }

    private void startAnimation() {
        startAnimation(this.mObjectAnimator1);
        startAnimation(this.mObjectAnimator2);
        startAnimation(this.mObjectAnimator3);
        this.mImage1.setVisibility(0);
        this.mImage2.setVisibility(0);
        this.mImage3.setVisibility(0);
    }

    private void stopAnimation() {
        stopAnimation(this.mObjectAnimator1, this.mImage1);
        stopAnimation(this.mObjectAnimator2, this.mImage2);
        stopAnimation(this.mObjectAnimator3, this.mImage3);
        this.mImage1.setVisibility(8);
        this.mImage2.setVisibility(8);
        this.mImage3.setVisibility(8);
    }

    private void startAnimation(Animator animator) {
        if (!animator.isStarted()) {
            animator.start();
        }
    }

    private void stopAnimation(Animator animator, View view) {
        if (animator.isStarted()) {
            animator.cancel();
            setDropScale(view);
        }
    }
}
