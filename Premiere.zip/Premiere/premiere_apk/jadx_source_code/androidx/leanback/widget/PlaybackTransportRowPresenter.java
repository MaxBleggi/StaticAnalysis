package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build.VERSION;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.leanback.R;
import androidx.leanback.widget.PlaybackControlsRow.OnPlaybackProgressCallback;
import androidx.leanback.widget.PlaybackControlsRow.PlayPauseAction;
import androidx.leanback.widget.PlaybackSeekDataProvider.ResultCallback;
import androidx.leanback.widget.PlaybackSeekUi.Client;
import androidx.leanback.widget.PlaybackTransportRowView.OnUnhandledKeyListener;
import androidx.leanback.widget.SeekBar.AccessibilitySeekListener;
import java.util.Arrays;

public class PlaybackTransportRowPresenter extends PlaybackRowPresenter {
    float mDefaultSeekIncrement = 0.01f;
    Presenter mDescriptionPresenter;
    OnActionClickedListener mOnActionClickedListener;
    private final OnControlClickedListener mOnControlClickedListener = new OnControlClickedListener() {
        public void onControlClicked(androidx.leanback.widget.Presenter.ViewHolder viewHolder, Object obj, BoundData boundData) {
            boundData = ((BoundData) boundData).mRowViewHolder;
            if (boundData.getOnItemViewClickedListener() != null) {
                boundData.getOnItemViewClickedListener().onItemClicked(viewHolder, obj, boundData, boundData.getRow());
            }
            if (PlaybackTransportRowPresenter.this.mOnActionClickedListener != null && (obj instanceof Action) != null) {
                PlaybackTransportRowPresenter.this.mOnActionClickedListener.onActionClicked((Action) obj);
            }
        }
    };
    private final OnControlSelectedListener mOnControlSelectedListener = new OnControlSelectedListener() {
        public void onControlSelected(androidx.leanback.widget.Presenter.ViewHolder viewHolder, Object obj, BoundData boundData) {
            boundData = ((BoundData) boundData).mRowViewHolder;
            if (boundData.mSelectedViewHolder != viewHolder || boundData.mSelectedItem != obj) {
                boundData.mSelectedViewHolder = viewHolder;
                boundData.mSelectedItem = obj;
                boundData.dispatchItemSelection();
            }
        }
    };
    ControlBarPresenter mPlaybackControlsPresenter;
    int mProgressColor = 0;
    boolean mProgressColorSet;
    ControlBarPresenter mSecondaryControlsPresenter;
    int mSecondaryProgressColor = 0;
    boolean mSecondaryProgressColorSet;

    static class BoundData extends BoundData {
        ViewHolder mRowViewHolder;

        BoundData() {
        }
    }

    public class ViewHolder extends androidx.leanback.widget.PlaybackRowPresenter.ViewHolder implements PlaybackSeekUi {
        BoundData mControlsBoundData = new BoundData();
        final ViewGroup mControlsDock;
        ViewHolder mControlsVh;
        final TextView mCurrentTime;
        long mCurrentTimeInMs = Long.MIN_VALUE;
        final ViewGroup mDescriptionDock;
        final androidx.leanback.widget.Presenter.ViewHolder mDescriptionViewHolder;
        final ImageView mImageView;
        boolean mInSeek;
        final OnPlaybackProgressCallback mListener = new OnPlaybackProgressCallback() {
            public void onCurrentPositionChanged(PlaybackControlsRow playbackControlsRow, long j) {
                ViewHolder.this.setCurrentPosition(j);
            }

            public void onDurationChanged(PlaybackControlsRow playbackControlsRow, long j) {
                ViewHolder.this.setTotalTime(j);
            }

            public void onBufferedPositionChanged(PlaybackControlsRow playbackControlsRow, long j) {
                ViewHolder.this.setBufferedPosition(j);
            }
        };
        PlayPauseAction mPlayPauseAction;
        long[] mPositions;
        int mPositionsLength;
        final SeekBar mProgressBar;
        BoundData mSecondaryBoundData = new BoundData();
        final ViewGroup mSecondaryControlsDock;
        ViewHolder mSecondaryControlsVh;
        long mSecondaryProgressInMs;
        Client mSeekClient;
        PlaybackSeekDataProvider mSeekDataProvider;
        Object mSelectedItem;
        androidx.leanback.widget.Presenter.ViewHolder mSelectedViewHolder;
        final StringBuilder mTempBuilder = new StringBuilder();
        int mThumbHeroIndex = -1;
        ResultCallback mThumbResult = new ResultCallback() {
            public void onThumbnailLoaded(Bitmap bitmap, int i) {
                i -= ViewHolder.this.mThumbHeroIndex - (ViewHolder.this.mThumbsBar.getChildCount() / 2);
                if (i < 0) {
                    return;
                }
                if (i < ViewHolder.this.mThumbsBar.getChildCount()) {
                    ViewHolder.this.mThumbsBar.setThumbBitmap(i, bitmap);
                }
            }
        };
        final ThumbsBar mThumbsBar;
        final TextView mTotalTime;
        long mTotalTimeInMs = Long.MIN_VALUE;

        void updateProgressInSeek(boolean z) {
            long j = this.mCurrentTimeInMs;
            int i = this.mPositionsLength;
            long j2 = 0;
            if (i > 0) {
                int i2 = 0;
                int binarySearch = Arrays.binarySearch(this.mPositions, 0, i, j);
                if (z) {
                    if (binarySearch < 0) {
                        binarySearch = -1 - binarySearch;
                        if (binarySearch <= this.mPositionsLength - 1) {
                            i2 = binarySearch;
                            j2 = this.mPositions[binarySearch];
                        } else {
                            long j3 = this.mTotalTimeInMs;
                            if (binarySearch > 0) {
                                i2 = binarySearch - 1;
                            }
                            j2 = j3;
                        }
                    } else if (binarySearch < this.mPositionsLength - 1) {
                        i2 = binarySearch + 1;
                        j2 = this.mPositions[i2];
                    } else {
                        j2 = this.mTotalTimeInMs;
                        i2 = binarySearch;
                    }
                } else if (binarySearch < 0) {
                    binarySearch = -1 - binarySearch;
                    if (binarySearch > 0) {
                        i2 = binarySearch - 1;
                        j2 = this.mPositions[i2];
                    }
                } else if (binarySearch > 0) {
                    i2 = binarySearch - 1;
                    j2 = this.mPositions[i2];
                }
                updateThumbsInSeek(i2, z);
            } else {
                long defaultSeekIncrement = (long) (((float) this.mTotalTimeInMs) * PlaybackTransportRowPresenter.this.getDefaultSeekIncrement());
                if (!z) {
                    defaultSeekIncrement = -defaultSeekIncrement;
                }
                j += defaultSeekIncrement;
                defaultSeekIncrement = this.mTotalTimeInMs;
                if (j > defaultSeekIncrement) {
                    j2 = defaultSeekIncrement;
                } else if (j >= 0) {
                    j2 = j;
                }
            }
            this.mProgressBar.setProgress((int) ((((double) j2) / ((double) this.mTotalTimeInMs)) * 2.147483647E9d));
            this.mSeekClient.onSeekPositionChanged(j2);
        }

        void updateThumbsInSeek(int i, boolean z) {
            if (this.mThumbHeroIndex != i) {
                int childCount = this.mThumbsBar.getChildCount();
                if (childCount < 0 || (childCount & 1) == 0) {
                    throw new RuntimeException();
                }
                int i2;
                int i3 = childCount / 2;
                boolean z2 = false;
                int max = Math.max(i - i3, 0);
                int min = Math.min(i + i3, this.mPositionsLength - 1);
                int i4 = this.mThumbHeroIndex;
                if (i4 < 0) {
                    i2 = max;
                } else {
                    z = i > i4;
                    i4 = Math.max(this.mThumbHeroIndex - i3, 0);
                    i2 = Math.min(this.mThumbHeroIndex + i3, this.mPositionsLength - 1);
                    ThumbsBar thumbsBar;
                    if (z) {
                        i4 = Math.max(i2 + 1, max);
                        for (i2 = max; i2 <= i4 - 1; i2++) {
                            thumbsBar = this.mThumbsBar;
                            thumbsBar.setThumbBitmap((i2 - i) + i3, thumbsBar.getThumbBitmap((i2 - this.mThumbHeroIndex) + i3));
                        }
                        i2 = i4;
                    } else {
                        i4 = Math.min(i4 - 1, min);
                        for (i2 = min; i2 >= i4 + 1; i2--) {
                            thumbsBar = this.mThumbsBar;
                            thumbsBar.setThumbBitmap((i2 - i) + i3, thumbsBar.getThumbBitmap((i2 - this.mThumbHeroIndex) + i3));
                        }
                        i2 = max;
                        this.mThumbHeroIndex = i;
                        if (z) {
                            while (i4 >= i2) {
                                this.mSeekDataProvider.getThumbnail(i4, this.mThumbResult);
                                i4--;
                            }
                        } else {
                            while (i2 <= i4) {
                                this.mSeekDataProvider.getThumbnail(i2, this.mThumbResult);
                                i2++;
                            }
                        }
                        while (true) {
                            i = this.mThumbHeroIndex;
                            if (z2 < (i3 - i) + max) {
                                break;
                            }
                            this.mThumbsBar.setThumbBitmap(z2, null);
                            z2++;
                        }
                        for (i3 = ((i3 + min) - i) + 1; i3 < childCount; i3++) {
                            this.mThumbsBar.setThumbBitmap(i3, null);
                        }
                    }
                }
                i4 = min;
                this.mThumbHeroIndex = i;
                if (z) {
                    while (i4 >= i2) {
                        this.mSeekDataProvider.getThumbnail(i4, this.mThumbResult);
                        i4--;
                    }
                } else {
                    while (i2 <= i4) {
                        this.mSeekDataProvider.getThumbnail(i2, this.mThumbResult);
                        i2++;
                    }
                }
                while (true) {
                    i = this.mThumbHeroIndex;
                    if (z2 < (i3 - i) + max) {
                        break;
                    }
                    this.mThumbsBar.setThumbBitmap(z2, null);
                    z2++;
                }
                for (i3 = ((i3 + min) - i) + 1; i3 < childCount; i3++) {
                    this.mThumbsBar.setThumbBitmap(i3, null);
                }
            }
        }

        boolean onForward() {
            if (!startSeek()) {
                return false;
            }
            updateProgressInSeek(true);
            return true;
        }

        boolean onBackward() {
            if (!startSeek()) {
                return false;
            }
            updateProgressInSeek(false);
            return true;
        }

        public ViewHolder(View view, Presenter presenter) {
            PlaybackTransportRowPresenter playbackTransportRowPresenter;
            super(view);
            this.mImageView = (ImageView) view.findViewById(R.id.image);
            this.mDescriptionDock = (ViewGroup) view.findViewById(R.id.description_dock);
            this.mCurrentTime = (TextView) view.findViewById(R.id.current_time);
            this.mTotalTime = (TextView) view.findViewById(R.id.total_time);
            this.mProgressBar = (SeekBar) view.findViewById(R.id.playback_progress);
            this.mProgressBar.setOnClickListener(new OnClickListener(PlaybackTransportRowPresenter.this) {
                public void onClick(View view) {
                    PlaybackTransportRowPresenter.this.onProgressBarClicked(ViewHolder.this);
                }
            });
            this.mProgressBar.setOnKeyListener(new OnKeyListener(PlaybackTransportRowPresenter.this) {
                public boolean onKey(View view, int i, KeyEvent keyEvent) {
                    boolean z = false;
                    if (i != 4) {
                        if (i != 66) {
                            if (i != 69) {
                                if (i != 81) {
                                    if (i != 111) {
                                        if (i != 89) {
                                            if (i != 90) {
                                                switch (i) {
                                                    case 19:
                                                    case 20:
                                                        return ViewHolder.this.mInSeek;
                                                    case 21:
                                                        break;
                                                    case 22:
                                                        break;
                                                    case 23:
                                                        break;
                                                    default:
                                                        return false;
                                                }
                                            }
                                        }
                                    }
                                }
                                if (keyEvent.getAction() == null) {
                                    ViewHolder.this.onForward();
                                }
                                return true;
                            }
                            if (keyEvent.getAction() == null) {
                                ViewHolder.this.onBackward();
                            }
                            return true;
                        }
                        if (ViewHolder.this.mInSeek == null) {
                            return false;
                        }
                        if (keyEvent.getAction() == 1) {
                            ViewHolder.this.stopSeek(false);
                        }
                        return true;
                    }
                    if (ViewHolder.this.mInSeek == null) {
                        return false;
                    }
                    if (keyEvent.getAction() == 1) {
                        view = ViewHolder.this;
                        if (VERSION.SDK_INT < 21 || ViewHolder.this.mProgressBar.isAccessibilityFocused() == 0) {
                            z = true;
                        }
                        view.stopSeek(z);
                    }
                    return true;
                }
            });
            this.mProgressBar.setAccessibilitySeekListener(new AccessibilitySeekListener(PlaybackTransportRowPresenter.this) {
                public boolean onAccessibilitySeekForward() {
                    return ViewHolder.this.onForward();
                }

                public boolean onAccessibilitySeekBackward() {
                    return ViewHolder.this.onBackward();
                }
            });
            this.mProgressBar.setMax(Integer.MAX_VALUE);
            this.mControlsDock = (ViewGroup) view.findViewById(R.id.controls_dock);
            this.mSecondaryControlsDock = (ViewGroup) view.findViewById(R.id.secondary_controls_dock);
            if (presenter == null) {
                playbackTransportRowPresenter = null;
            } else {
                playbackTransportRowPresenter = presenter.onCreateViewHolder(this.mDescriptionDock);
            }
            this.mDescriptionViewHolder = playbackTransportRowPresenter;
            playbackTransportRowPresenter = this.mDescriptionViewHolder;
            if (playbackTransportRowPresenter != null) {
                this.mDescriptionDock.addView(playbackTransportRowPresenter.view);
            }
            this.mThumbsBar = (ThumbsBar) view.findViewById(R.id.thumbs_row);
        }

        public final androidx.leanback.widget.Presenter.ViewHolder getDescriptionViewHolder() {
            return this.mDescriptionViewHolder;
        }

        public void setPlaybackSeekUiClient(Client client) {
            this.mSeekClient = client;
        }

        boolean startSeek() {
            if (this.mInSeek) {
                return true;
            }
            Client client = this.mSeekClient;
            if (client != null && client.isSeekEnabled()) {
                if (this.mTotalTimeInMs > 0) {
                    this.mInSeek = true;
                    this.mSeekClient.onSeekStarted();
                    this.mSeekDataProvider = this.mSeekClient.getPlaybackSeekDataProvider();
                    PlaybackSeekDataProvider playbackSeekDataProvider = this.mSeekDataProvider;
                    this.mPositions = playbackSeekDataProvider != null ? playbackSeekDataProvider.getSeekPositions() : null;
                    long[] jArr = this.mPositions;
                    if (jArr != null) {
                        int binarySearch = Arrays.binarySearch(jArr, this.mTotalTimeInMs);
                        if (binarySearch >= 0) {
                            this.mPositionsLength = binarySearch + 1;
                        } else {
                            this.mPositionsLength = -1 - binarySearch;
                        }
                    } else {
                        this.mPositionsLength = 0;
                    }
                    this.mControlsVh.view.setVisibility(8);
                    this.mSecondaryControlsVh.view.setVisibility(4);
                    this.mDescriptionViewHolder.view.setVisibility(4);
                    this.mThumbsBar.setVisibility(0);
                    return true;
                }
            }
            return false;
        }

        void stopSeek(boolean z) {
            if (this.mInSeek) {
                this.mInSeek = false;
                this.mSeekClient.onSeekFinished(z);
                z = this.mSeekDataProvider;
                if (z) {
                    z.reset();
                }
                this.mThumbHeroIndex = true;
                this.mThumbsBar.clearThumbBitmaps();
                this.mSeekDataProvider = null;
                this.mPositions = null;
                this.mPositionsLength = 0;
                this.mControlsVh.view.setVisibility(0);
                this.mSecondaryControlsVh.view.setVisibility(0);
                this.mDescriptionViewHolder.view.setVisibility(0);
                this.mThumbsBar.setVisibility(4);
            }
        }

        void dispatchItemSelection() {
            if (isSelected()) {
                if (this.mSelectedViewHolder == null) {
                    if (getOnItemViewSelectedListener() != null) {
                        getOnItemViewSelectedListener().onItemSelected(null, null, this, getRow());
                    }
                } else if (getOnItemViewSelectedListener() != null) {
                    getOnItemViewSelectedListener().onItemSelected(this.mSelectedViewHolder, this.mSelectedItem, this, getRow());
                }
            }
        }

        Presenter getPresenter(boolean z) {
            if (z) {
                z = ((PlaybackControlsRow) getRow()).getPrimaryActionsAdapter();
            } else {
                z = ((PlaybackControlsRow) getRow()).getSecondaryActionsAdapter();
            }
            Object obj = null;
            if (!z) {
                return null;
            }
            if (z.getPresenterSelector() instanceof ControlButtonPresenterSelector) {
                return ((ControlButtonPresenterSelector) z.getPresenterSelector()).getSecondaryPresenter();
            }
            if (z.size() > 0) {
                obj = z.get(0);
            }
            return z.getPresenter(obj);
        }

        public final TextView getDurationView() {
            return this.mTotalTime;
        }

        protected void onSetDurationLabel(long j) {
            if (this.mTotalTime != null) {
                PlaybackTransportRowPresenter.formatTime(j, this.mTempBuilder);
                this.mTotalTime.setText(this.mTempBuilder.toString());
            }
        }

        void setTotalTime(long j) {
            if (this.mTotalTimeInMs != j) {
                this.mTotalTimeInMs = j;
                onSetDurationLabel(j);
            }
        }

        public final TextView getCurrentPositionView() {
            return this.mCurrentTime;
        }

        protected void onSetCurrentPositionLabel(long j) {
            if (this.mCurrentTime != null) {
                PlaybackTransportRowPresenter.formatTime(j, this.mTempBuilder);
                this.mCurrentTime.setText(this.mTempBuilder.toString());
            }
        }

        void setCurrentPosition(long j) {
            if (j != this.mCurrentTimeInMs) {
                this.mCurrentTimeInMs = j;
                onSetCurrentPositionLabel(j);
            }
            if (this.mInSeek == null) {
                j = null;
                long j2 = this.mTotalTimeInMs;
                if (j2 > 0) {
                    j = (int) ((((double) this.mCurrentTimeInMs) / ((double) j2)) * 4746794007244308480L);
                }
                this.mProgressBar.setProgress(j);
            }
        }

        void setBufferedPosition(long j) {
            this.mSecondaryProgressInMs = j;
            this.mProgressBar.setSecondaryProgress((int) ((((double) j) / ((double) this.mTotalTimeInMs)) * 4746794007244308480L));
        }
    }

    static void formatTime(long j, StringBuilder stringBuilder) {
        stringBuilder.setLength(0);
        if (j < 0) {
            stringBuilder.append("--");
            return;
        }
        j /= 1000;
        long j2 = j / 60;
        long j3 = j2 / 60;
        j -= j2 * 60;
        j2 -= 60 * j3;
        if (j3 > 0) {
            stringBuilder.append(j3);
            stringBuilder.append(':');
            if (j2 < 10) {
                stringBuilder.append('0');
            }
        }
        stringBuilder.append(j2);
        stringBuilder.append(':');
        if (j < 10) {
            stringBuilder.append('0');
        }
        stringBuilder.append(j);
    }

    public PlaybackTransportRowPresenter() {
        setHeaderPresenter(null);
        setSelectEffectEnabled(false);
        this.mPlaybackControlsPresenter = new ControlBarPresenter(R.layout.lb_control_bar);
        this.mPlaybackControlsPresenter.setDefaultFocusToMiddle(false);
        this.mSecondaryControlsPresenter = new ControlBarPresenter(R.layout.lb_control_bar);
        this.mSecondaryControlsPresenter.setDefaultFocusToMiddle(false);
        this.mPlaybackControlsPresenter.setOnControlSelectedListener(this.mOnControlSelectedListener);
        this.mSecondaryControlsPresenter.setOnControlSelectedListener(this.mOnControlSelectedListener);
        this.mPlaybackControlsPresenter.setOnControlClickedListener(this.mOnControlClickedListener);
        this.mSecondaryControlsPresenter.setOnControlClickedListener(this.mOnControlClickedListener);
    }

    public void setDescriptionPresenter(Presenter presenter) {
        this.mDescriptionPresenter = presenter;
    }

    public void setOnActionClickedListener(OnActionClickedListener onActionClickedListener) {
        this.mOnActionClickedListener = onActionClickedListener;
    }

    public OnActionClickedListener getOnActionClickedListener() {
        return this.mOnActionClickedListener;
    }

    public void setProgressColor(int i) {
        this.mProgressColor = i;
        this.mProgressColorSet = true;
    }

    public int getProgressColor() {
        return this.mProgressColor;
    }

    public void setSecondaryProgressColor(int i) {
        this.mSecondaryProgressColor = i;
        this.mSecondaryProgressColorSet = true;
    }

    public int getSecondaryProgressColor() {
        return this.mSecondaryProgressColor;
    }

    public void onReappear(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        if (viewHolder2.view.hasFocus()) {
            viewHolder2.mProgressBar.requestFocus();
        }
    }

    private static int getDefaultProgressColor(Context context) {
        TypedValue typedValue = new TypedValue();
        if (context.getTheme().resolveAttribute(R.attr.playbackProgressPrimaryColor, typedValue, true)) {
            return context.getResources().getColor(typedValue.resourceId);
        }
        return context.getResources().getColor(R.color.lb_playback_progress_color_no_theme);
    }

    private static int getDefaultSecondaryProgressColor(Context context) {
        TypedValue typedValue = new TypedValue();
        if (context.getTheme().resolveAttribute(R.attr.playbackProgressSecondaryColor, typedValue, true)) {
            return context.getResources().getColor(typedValue.resourceId);
        }
        return context.getResources().getColor(R.color.lb_playback_progress_secondary_color_no_theme);
    }

    protected androidx.leanback.widget.RowPresenter.ViewHolder createRowViewHolder(ViewGroup viewGroup) {
        androidx.leanback.widget.RowPresenter.ViewHolder viewHolder = new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lb_playback_transport_controls_row, viewGroup, false), this.mDescriptionPresenter);
        initRow(viewHolder);
        return viewHolder;
    }

    private void initRow(final ViewHolder viewHolder) {
        int i;
        viewHolder.mControlsVh = (ViewHolder) this.mPlaybackControlsPresenter.onCreateViewHolder(viewHolder.mControlsDock);
        SeekBar seekBar = viewHolder.mProgressBar;
        if (this.mProgressColorSet) {
            i = this.mProgressColor;
        } else {
            i = getDefaultProgressColor(viewHolder.mControlsDock.getContext());
        }
        seekBar.setProgressColor(i);
        seekBar = viewHolder.mProgressBar;
        if (this.mSecondaryProgressColorSet) {
            i = this.mSecondaryProgressColor;
        } else {
            i = getDefaultSecondaryProgressColor(viewHolder.mControlsDock.getContext());
        }
        seekBar.setSecondaryProgressColor(i);
        viewHolder.mControlsDock.addView(viewHolder.mControlsVh.view);
        viewHolder.mSecondaryControlsVh = (ViewHolder) this.mSecondaryControlsPresenter.onCreateViewHolder(viewHolder.mSecondaryControlsDock);
        viewHolder.mSecondaryControlsDock.addView(viewHolder.mSecondaryControlsVh.view);
        ((PlaybackTransportRowView) viewHolder.view.findViewById(R.id.transport_row)).setOnUnhandledKeyListener(new OnUnhandledKeyListener() {
            public boolean onUnhandledKey(KeyEvent keyEvent) {
                return (viewHolder.getOnKeyListener() == null || viewHolder.getOnKeyListener().onKey(viewHolder.view, keyEvent.getKeyCode(), keyEvent) == null) ? null : true;
            }
        });
    }

    protected void onBindRowViewHolder(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, Object obj) {
        super.onBindRowViewHolder(viewHolder, obj);
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        PlaybackControlsRow playbackControlsRow = (PlaybackControlsRow) viewHolder2.getRow();
        if (playbackControlsRow.getItem() == null) {
            viewHolder2.mDescriptionDock.setVisibility(8);
        } else {
            viewHolder2.mDescriptionDock.setVisibility(0);
            if (viewHolder2.mDescriptionViewHolder != null) {
                this.mDescriptionPresenter.onBindViewHolder(viewHolder2.mDescriptionViewHolder, playbackControlsRow.getItem());
            }
        }
        if (playbackControlsRow.getImageDrawable() == null) {
            viewHolder2.mImageView.setVisibility(8);
        } else {
            viewHolder2.mImageView.setVisibility(0);
        }
        viewHolder2.mImageView.setImageDrawable(playbackControlsRow.getImageDrawable());
        viewHolder2.mControlsBoundData.adapter = playbackControlsRow.getPrimaryActionsAdapter();
        viewHolder2.mControlsBoundData.presenter = viewHolder2.getPresenter(true);
        viewHolder2.mControlsBoundData.mRowViewHolder = viewHolder2;
        this.mPlaybackControlsPresenter.onBindViewHolder(viewHolder2.mControlsVh, viewHolder2.mControlsBoundData);
        viewHolder2.mSecondaryBoundData.adapter = playbackControlsRow.getSecondaryActionsAdapter();
        viewHolder2.mSecondaryBoundData.presenter = viewHolder2.getPresenter(false);
        viewHolder2.mSecondaryBoundData.mRowViewHolder = viewHolder2;
        this.mSecondaryControlsPresenter.onBindViewHolder(viewHolder2.mSecondaryControlsVh, viewHolder2.mSecondaryBoundData);
        viewHolder2.setTotalTime(playbackControlsRow.getDuration());
        viewHolder2.setCurrentPosition(playbackControlsRow.getCurrentPosition());
        viewHolder2.setBufferedPosition(playbackControlsRow.getBufferedPosition());
        playbackControlsRow.setOnPlaybackProgressChangedListener(viewHolder2.mListener);
    }

    protected void onUnbindRowViewHolder(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        PlaybackControlsRow playbackControlsRow = (PlaybackControlsRow) viewHolder2.getRow();
        if (viewHolder2.mDescriptionViewHolder != null) {
            this.mDescriptionPresenter.onUnbindViewHolder(viewHolder2.mDescriptionViewHolder);
        }
        this.mPlaybackControlsPresenter.onUnbindViewHolder(viewHolder2.mControlsVh);
        this.mSecondaryControlsPresenter.onUnbindViewHolder(viewHolder2.mSecondaryControlsVh);
        playbackControlsRow.setOnPlaybackProgressChangedListener(null);
        super.onUnbindRowViewHolder(viewHolder);
    }

    protected void onProgressBarClicked(ViewHolder viewHolder) {
        if (viewHolder != null) {
            if (viewHolder.mPlayPauseAction == null) {
                viewHolder.mPlayPauseAction = new PlayPauseAction(viewHolder.view.getContext());
            }
            if (viewHolder.getOnItemViewClickedListener() != null) {
                viewHolder.getOnItemViewClickedListener().onItemClicked(viewHolder, viewHolder.mPlayPauseAction, viewHolder, viewHolder.getRow());
            }
            OnActionClickedListener onActionClickedListener = this.mOnActionClickedListener;
            if (onActionClickedListener != null) {
                onActionClickedListener.onActionClicked(viewHolder.mPlayPauseAction);
            }
        }
    }

    public void setDefaultSeekIncrement(float f) {
        this.mDefaultSeekIncrement = f;
    }

    public float getDefaultSeekIncrement() {
        return this.mDefaultSeekIncrement;
    }

    protected void onRowViewSelected(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder, boolean z) {
        super.onRowViewSelected(viewHolder, z);
        if (z) {
            ((ViewHolder) viewHolder).dispatchItemSelection();
        }
    }

    protected void onRowViewAttachedToWindow(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        super.onRowViewAttachedToWindow(viewHolder);
        Presenter presenter = this.mDescriptionPresenter;
        if (presenter != null) {
            presenter.onViewAttachedToWindow(((ViewHolder) viewHolder).mDescriptionViewHolder);
        }
    }

    protected void onRowViewDetachedFromWindow(androidx.leanback.widget.RowPresenter.ViewHolder viewHolder) {
        super.onRowViewDetachedFromWindow(viewHolder);
        Presenter presenter = this.mDescriptionPresenter;
        if (presenter != null) {
            presenter.onViewDetachedFromWindow(((ViewHolder) viewHolder).mDescriptionViewHolder);
        }
    }
}
