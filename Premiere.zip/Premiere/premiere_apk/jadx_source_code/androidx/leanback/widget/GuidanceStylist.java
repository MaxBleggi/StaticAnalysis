package androidx.leanback.widget;

import android.animation.Animator;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.leanback.R;
import java.util.List;

public class GuidanceStylist implements FragmentAnimationProvider {
    private TextView mBreadcrumbView;
    private TextView mDescriptionView;
    private View mGuidanceContainer;
    private ImageView mIconView;
    private TextView mTitleView;

    public static class Guidance {
        private final String mBreadcrumb;
        private final String mDescription;
        private final Drawable mIconDrawable;
        private final String mTitle;

        public Guidance(String str, String str2, String str3, Drawable drawable) {
            this.mBreadcrumb = str3;
            this.mTitle = str;
            this.mDescription = str2;
            this.mIconDrawable = drawable;
        }

        public String getTitle() {
            return this.mTitle;
        }

        public String getDescription() {
            return this.mDescription;
        }

        public String getBreadcrumb() {
            return this.mBreadcrumb;
        }

        public Drawable getIconDrawable() {
            return this.mIconDrawable;
        }
    }

    public void onImeAppearing(List<Animator> list) {
    }

    public void onImeDisappearing(List<Animator> list) {
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Guidance guidance) {
        layoutInflater = layoutInflater.inflate(onProvideLayoutId(), viewGroup, false);
        this.mTitleView = (TextView) layoutInflater.findViewById(R.id.guidance_title);
        this.mBreadcrumbView = (TextView) layoutInflater.findViewById(R.id.guidance_breadcrumb);
        this.mDescriptionView = (TextView) layoutInflater.findViewById(R.id.guidance_description);
        this.mIconView = (ImageView) layoutInflater.findViewById(R.id.guidance_icon);
        this.mGuidanceContainer = layoutInflater.findViewById(R.id.guidance_container);
        viewGroup = this.mTitleView;
        if (viewGroup != null) {
            viewGroup.setText(guidance.getTitle());
        }
        viewGroup = this.mBreadcrumbView;
        if (viewGroup != null) {
            viewGroup.setText(guidance.getBreadcrumb());
        }
        viewGroup = this.mDescriptionView;
        if (viewGroup != null) {
            viewGroup.setText(guidance.getDescription());
        }
        if (this.mIconView != null) {
            if (guidance.getIconDrawable() != null) {
                this.mIconView.setImageDrawable(guidance.getIconDrawable());
            } else {
                this.mIconView.setVisibility(8);
            }
        }
        viewGroup = this.mGuidanceContainer;
        if (!(viewGroup == null || TextUtils.isEmpty(viewGroup.getContentDescription()) == null)) {
            viewGroup = new StringBuilder();
            if (!TextUtils.isEmpty(guidance.getBreadcrumb())) {
                viewGroup.append(guidance.getBreadcrumb());
                viewGroup.append('\n');
            }
            if (!TextUtils.isEmpty(guidance.getTitle())) {
                viewGroup.append(guidance.getTitle());
                viewGroup.append('\n');
            }
            if (!TextUtils.isEmpty(guidance.getDescription())) {
                viewGroup.append(guidance.getDescription());
                viewGroup.append('\n');
            }
            this.mGuidanceContainer.setContentDescription(viewGroup);
        }
        return layoutInflater;
    }

    public void onDestroyView() {
        this.mBreadcrumbView = null;
        this.mDescriptionView = null;
        this.mIconView = null;
        this.mTitleView = null;
    }

    public int onProvideLayoutId() {
        return R.layout.lb_guidance;
    }

    public TextView getTitleView() {
        return this.mTitleView;
    }

    public TextView getDescriptionView() {
        return this.mDescriptionView;
    }

    public TextView getBreadcrumbView() {
        return this.mBreadcrumbView;
    }

    public ImageView getIconView() {
        return this.mIconView;
    }
}
