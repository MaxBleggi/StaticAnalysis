package androidx.leanback.widget;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import androidx.leanback.R;

public class DetailsOverviewLogoPresenter extends Presenter {

    public static class ViewHolder extends androidx.leanback.widget.Presenter.ViewHolder {
        protected FullWidthDetailsOverviewRowPresenter mParentPresenter;
        protected androidx.leanback.widget.FullWidthDetailsOverviewRowPresenter.ViewHolder mParentViewHolder;
        private boolean mSizeFromDrawableIntrinsic;

        public ViewHolder(View view) {
            super(view);
        }

        public FullWidthDetailsOverviewRowPresenter getParentPresenter() {
            return this.mParentPresenter;
        }

        public androidx.leanback.widget.FullWidthDetailsOverviewRowPresenter.ViewHolder getParentViewHolder() {
            return this.mParentViewHolder;
        }

        public boolean isSizeFromDrawableIntrinsic() {
            return this.mSizeFromDrawableIntrinsic;
        }

        public void setSizeFromDrawableIntrinsic(boolean z) {
            this.mSizeFromDrawableIntrinsic = z;
        }
    }

    public void onUnbindViewHolder(androidx.leanback.widget.Presenter.ViewHolder viewHolder) {
    }

    public View onCreateView(ViewGroup viewGroup) {
        return LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lb_fullwidth_details_overview_logo, viewGroup, false);
    }

    public androidx.leanback.widget.Presenter.ViewHolder onCreateViewHolder(ViewGroup viewGroup) {
        viewGroup = onCreateView(viewGroup);
        androidx.leanback.widget.Presenter.ViewHolder viewHolder = new ViewHolder(viewGroup);
        viewGroup = viewGroup.getLayoutParams();
        viewGroup = (viewGroup.width == -2 && viewGroup.height == -2) ? true : null;
        viewHolder.setSizeFromDrawableIntrinsic(viewGroup);
        return viewHolder;
    }

    public void setContext(ViewHolder viewHolder, androidx.leanback.widget.FullWidthDetailsOverviewRowPresenter.ViewHolder viewHolder2, FullWidthDetailsOverviewRowPresenter fullWidthDetailsOverviewRowPresenter) {
        viewHolder.mParentViewHolder = viewHolder2;
        viewHolder.mParentPresenter = fullWidthDetailsOverviewRowPresenter;
    }

    public boolean isBoundToImage(ViewHolder viewHolder, DetailsOverviewRow detailsOverviewRow) {
        return (detailsOverviewRow == null || detailsOverviewRow.getImageDrawable() == null) ? null : true;
    }

    public void onBindViewHolder(androidx.leanback.widget.Presenter.ViewHolder viewHolder, Object obj) {
        DetailsOverviewRow detailsOverviewRow = (DetailsOverviewRow) obj;
        ImageView imageView = (ImageView) viewHolder.view;
        imageView.setImageDrawable(detailsOverviewRow.getImageDrawable());
        ViewHolder viewHolder2 = (ViewHolder) viewHolder;
        if (isBoundToImage(viewHolder2, detailsOverviewRow)) {
            if (viewHolder2.isSizeFromDrawableIntrinsic()) {
                LayoutParams layoutParams = imageView.getLayoutParams();
                layoutParams.width = detailsOverviewRow.getImageDrawable().getIntrinsicWidth();
                layoutParams.height = detailsOverviewRow.getImageDrawable().getIntrinsicHeight();
                if (imageView.getMaxWidth() > null || imageView.getMaxHeight() > null) {
                    float f = 1.0f;
                    obj = (imageView.getMaxWidth() <= null || layoutParams.width <= imageView.getMaxWidth()) ? 1065353216 : ((float) imageView.getMaxWidth()) / ((float) layoutParams.width);
                    if (imageView.getMaxHeight() > 0 && layoutParams.height > imageView.getMaxHeight()) {
                        f = ((float) imageView.getMaxHeight()) / ((float) layoutParams.height);
                    }
                    obj = Math.min(obj, f);
                    layoutParams.width = (int) (((float) layoutParams.width) * obj);
                    layoutParams.height = (int) (((float) layoutParams.height) * obj);
                }
                imageView.setLayoutParams(layoutParams);
            }
            viewHolder2.mParentPresenter.notifyOnBindLogo(viewHolder2.mParentViewHolder);
        }
    }
}
