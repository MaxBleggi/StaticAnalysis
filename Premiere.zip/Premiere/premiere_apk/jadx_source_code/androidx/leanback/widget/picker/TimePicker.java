package androidx.leanback.widget.picker;

import android.content.Context;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import androidx.leanback.R;
import androidx.leanback.widget.picker.PickerUtility.TimeConstant;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TimePicker extends Picker {
    private static final int AM_INDEX = 0;
    private static final int HOURS_IN_HALF_DAY = 12;
    private static final int PM_INDEX = 1;
    static final String TAG = "TimePicker";
    PickerColumn mAmPmColumn;
    int mColAmPmIndex;
    int mColHourIndex;
    int mColMinuteIndex;
    private final TimeConstant mConstant;
    private int mCurrentAmPmIndex;
    private int mCurrentHour;
    private int mCurrentMinute;
    PickerColumn mHourColumn;
    private boolean mIs24hFormat;
    PickerColumn mMinuteColumn;
    private String mTimePickerFormat;

    public TimePicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public TimePicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mConstant = PickerUtility.getTimeConstantInstance(Locale.getDefault(), context.getResources());
        attributeSet = context.obtainStyledAttributes(attributeSet, R.styleable.lbTimePicker);
        this.mIs24hFormat = attributeSet.getBoolean(R.styleable.lbTimePicker_is24HourFormat, DateFormat.is24HourFormat(context));
        context = attributeSet.getBoolean(R.styleable.lbTimePicker_useCurrentTime, 1);
        updateColumns();
        updateColumnsRange();
        if (context != null) {
            context = PickerUtility.getCalendarForLocale(null, this.mConstant.locale);
            setHour(context.get(11));
            setMinute(context.get(12));
            setAmPmValue();
        }
    }

    private static boolean updateMin(PickerColumn pickerColumn, int i) {
        if (i == pickerColumn.getMinValue()) {
            return null;
        }
        pickerColumn.setMinValue(i);
        return true;
    }

    private static boolean updateMax(PickerColumn pickerColumn, int i) {
        if (i == pickerColumn.getMaxValue()) {
            return null;
        }
        pickerColumn.setMaxValue(i);
        return true;
    }

    String getBestHourMinutePattern() {
        String bestDateTimePattern;
        String str = "h:mma";
        if (PickerUtility.SUPPORTS_BEST_DATE_TIME_PATTERN) {
            bestDateTimePattern = DateFormat.getBestDateTimePattern(this.mConstant.locale, this.mIs24hFormat ? "Hma" : "hma");
        } else {
            java.text.DateFormat timeInstance = SimpleDateFormat.getTimeInstance(3, this.mConstant.locale);
            if (timeInstance instanceof SimpleDateFormat) {
                CharSequence charSequence = "";
                bestDateTimePattern = ((SimpleDateFormat) timeInstance).toPattern().replace("s", charSequence);
                if (this.mIs24hFormat) {
                    bestDateTimePattern = bestDateTimePattern.replace('h', 'H').replace("a", charSequence);
                }
            } else {
                bestDateTimePattern = this.mIs24hFormat ? "H:mma" : str;
            }
        }
        return TextUtils.isEmpty(bestDateTimePattern) ? str : bestDateTimePattern;
    }

    List<CharSequence> extractSeparators() {
        String bestHourMinutePattern = getBestHourMinutePattern();
        List<CharSequence> arrayList = new ArrayList();
        StringBuilder stringBuilder = new StringBuilder();
        char[] cArr = new char[]{'H', 'h', 'K', 'k', 'm', 'M', 'a'};
        Object obj = null;
        char c = '\u0000';
        for (int i = 0; i < bestHourMinutePattern.length(); i++) {
            char charAt = bestHourMinutePattern.charAt(i);
            if (charAt != ' ') {
                if (charAt != '\'') {
                    if (obj != null) {
                        stringBuilder.append(charAt);
                    } else if (!isAnyOf(charAt, cArr)) {
                        stringBuilder.append(charAt);
                    } else if (charAt != c) {
                        arrayList.add(stringBuilder.toString());
                        stringBuilder.setLength(0);
                    }
                    c = charAt;
                } else if (obj == null) {
                    stringBuilder.setLength(0);
                    obj = 1;
                } else {
                    obj = null;
                }
            }
        }
        arrayList.add(stringBuilder.toString());
        return arrayList;
    }

    private static boolean isAnyOf(char c, char[] cArr) {
        for (char c2 : cArr) {
            if (c == c2) {
                return true;
            }
        }
        return false;
    }

    private String extractTimeFields() {
        String bestHourMinutePattern = getBestHourMinutePattern();
        Object obj = 1;
        Object obj2 = TextUtils.getLayoutDirectionFromLocale(this.mConstant.locale) == 1 ? 1 : null;
        String str = "a";
        if (bestHourMinutePattern.indexOf(97) >= 0) {
            if (bestHourMinutePattern.indexOf(str) <= bestHourMinutePattern.indexOf("m")) {
                obj = null;
            }
        }
        bestHourMinutePattern = obj2 != null ? "mh" : "hm";
        if (is24Hour()) {
            return bestHourMinutePattern;
        }
        StringBuilder stringBuilder;
        if (obj != null) {
            stringBuilder = new StringBuilder();
            stringBuilder.append(bestHourMinutePattern);
            stringBuilder.append(str);
        } else {
            stringBuilder = new StringBuilder();
            stringBuilder.append(str);
            stringBuilder.append(bestHourMinutePattern);
        }
        return stringBuilder.toString();
    }

    private void updateColumns() {
        Object bestHourMinutePattern = getBestHourMinutePattern();
        if (!TextUtils.equals(bestHourMinutePattern, this.mTimePickerFormat)) {
            this.mTimePickerFormat = bestHourMinutePattern;
            String extractTimeFields = extractTimeFields();
            List extractSeparators = extractSeparators();
            if (extractSeparators.size() == extractTimeFields.length() + 1) {
                setSeparators(extractSeparators);
                extractTimeFields = extractTimeFields.toUpperCase();
                this.mAmPmColumn = null;
                this.mMinuteColumn = null;
                this.mHourColumn = null;
                this.mColAmPmIndex = -1;
                this.mColMinuteIndex = -1;
                this.mColHourIndex = -1;
                extractSeparators = new ArrayList(3);
                for (int i = 0; i < extractTimeFields.length(); i++) {
                    char charAt = extractTimeFields.charAt(i);
                    PickerColumn pickerColumn;
                    if (charAt == 'A') {
                        pickerColumn = new PickerColumn();
                        this.mAmPmColumn = pickerColumn;
                        extractSeparators.add(pickerColumn);
                        this.mAmPmColumn.setStaticLabels(this.mConstant.ampm);
                        this.mColAmPmIndex = i;
                        updateMin(this.mAmPmColumn, 0);
                        updateMax(this.mAmPmColumn, 1);
                    } else if (charAt == 'H') {
                        pickerColumn = new PickerColumn();
                        this.mHourColumn = pickerColumn;
                        extractSeparators.add(pickerColumn);
                        this.mHourColumn.setStaticLabels(this.mConstant.hours24);
                        this.mColHourIndex = i;
                    } else if (charAt == 'M') {
                        pickerColumn = new PickerColumn();
                        this.mMinuteColumn = pickerColumn;
                        extractSeparators.add(pickerColumn);
                        this.mMinuteColumn.setStaticLabels(this.mConstant.minutes);
                        this.mColMinuteIndex = i;
                    } else {
                        throw new IllegalArgumentException("Invalid time picker format.");
                    }
                }
                setColumns(extractSeparators);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Separators size: ");
            stringBuilder.append(extractSeparators.size());
            stringBuilder.append(" must equal");
            stringBuilder.append(" the size of timeFieldsPattern: ");
            stringBuilder.append(extractTimeFields.length());
            stringBuilder.append(" + 1");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    private void updateColumnsRange() {
        updateMin(this.mHourColumn, this.mIs24hFormat ^ 1);
        updateMax(this.mHourColumn, this.mIs24hFormat ? 23 : 12);
        updateMin(this.mMinuteColumn, 0);
        updateMax(this.mMinuteColumn, 59);
        PickerColumn pickerColumn = this.mAmPmColumn;
        if (pickerColumn != null) {
            updateMin(pickerColumn, 0);
            updateMax(this.mAmPmColumn, 1);
        }
    }

    private void setAmPmValue() {
        if (!is24Hour()) {
            setColumnValue(this.mColAmPmIndex, this.mCurrentAmPmIndex, false);
        }
    }

    public void setHour(int i) {
        if (i < 0 || i > 23) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("hour: ");
            stringBuilder.append(i);
            stringBuilder.append(" is not in [0-23] range in");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.mCurrentHour = i;
        if (is24Hour() == 0) {
            i = this.mCurrentHour;
            if (i >= 12) {
                this.mCurrentAmPmIndex = 1;
                if (i > 12) {
                    this.mCurrentHour = i - 12;
                }
            } else {
                this.mCurrentAmPmIndex = 0;
                if (i == 0) {
                    this.mCurrentHour = 12;
                }
            }
            setAmPmValue();
        }
        setColumnValue(this.mColHourIndex, this.mCurrentHour, false);
    }

    public int getHour() {
        if (this.mIs24hFormat) {
            return this.mCurrentHour;
        }
        if (this.mCurrentAmPmIndex == 0) {
            return this.mCurrentHour % 12;
        }
        return (this.mCurrentHour % 12) + 12;
    }

    public void setMinute(int i) {
        if (i < 0 || i > 59) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("minute: ");
            stringBuilder.append(i);
            stringBuilder.append(" is not in [0-59] range.");
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        this.mCurrentMinute = i;
        setColumnValue(this.mColMinuteIndex, this.mCurrentMinute, false);
    }

    public int getMinute() {
        return this.mCurrentMinute;
    }

    public void setIs24Hour(boolean z) {
        if (this.mIs24hFormat != z) {
            int hour = getHour();
            int minute = getMinute();
            this.mIs24hFormat = z;
            updateColumns();
            updateColumnsRange();
            setHour(hour);
            setMinute(minute);
            setAmPmValue();
        }
    }

    public boolean is24Hour() {
        return this.mIs24hFormat;
    }

    public boolean isPm() {
        return this.mCurrentAmPmIndex == 1;
    }

    public void onColumnValueChanged(int i, int i2) {
        if (i == this.mColHourIndex) {
            this.mCurrentHour = i2;
        } else if (i == this.mColMinuteIndex) {
            this.mCurrentMinute = i2;
        } else if (i == this.mColAmPmIndex) {
            this.mCurrentAmPmIndex = i2;
        } else {
            throw new IllegalArgumentException("Invalid column index.");
        }
    }
}
