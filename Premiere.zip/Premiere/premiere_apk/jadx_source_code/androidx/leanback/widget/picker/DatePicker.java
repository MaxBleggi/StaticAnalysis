package androidx.leanback.widget.picker;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import androidx.leanback.R;
import androidx.leanback.widget.picker.PickerUtility.DateConstant;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class DatePicker extends Picker {
    private static final int[] DATE_FIELDS = new int[]{5, 2, 1};
    static final String DATE_FORMAT = "MM/dd/yyyy";
    static final String LOG_TAG = "DatePicker";
    int mColDayIndex;
    int mColMonthIndex;
    int mColYearIndex;
    DateConstant mConstant;
    Calendar mCurrentDate;
    final DateFormat mDateFormat;
    private String mDatePickerFormat;
    PickerColumn mDayColumn;
    Calendar mMaxDate;
    Calendar mMinDate;
    PickerColumn mMonthColumn;
    Calendar mTempDate;
    PickerColumn mYearColumn;

    public DatePicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DatePicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mDateFormat = new SimpleDateFormat(DATE_FORMAT);
        updateCurrentLocale();
        attributeSet = context.obtainStyledAttributes(attributeSet, R.styleable.lbDatePicker);
        i = attributeSet.getString(R.styleable.lbDatePicker_android_minDate);
        Object string = attributeSet.getString(R.styleable.lbDatePicker_android_maxDate);
        this.mTempDate.clear();
        if (TextUtils.isEmpty(i)) {
            this.mTempDate.set(1900, 0, 1);
        } else if (parseDate(i, this.mTempDate) == 0) {
            this.mTempDate.set(1900, 0, 1);
        }
        this.mMinDate.setTimeInMillis(this.mTempDate.getTimeInMillis());
        this.mTempDate.clear();
        if (TextUtils.isEmpty(string) != 0) {
            this.mTempDate.set(2100, 0, 1);
        } else if (parseDate(string, this.mTempDate) == 0) {
            this.mTempDate.set(2100, 0, 1);
        }
        this.mMaxDate.setTimeInMillis(this.mTempDate.getTimeInMillis());
        attributeSet = attributeSet.getString(R.styleable.lbDatePicker_datePickerFormat);
        if (TextUtils.isEmpty(attributeSet) != 0) {
            attributeSet = new String(android.text.format.DateFormat.getDateFormatOrder(context));
        }
        setDatePickerFormat(attributeSet);
    }

    private boolean parseDate(java.lang.String r2, java.util.Calendar r3) {
        /* JADX: method processing error */
/*
Error: java.lang.NullPointerException
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.searchTryCatchDominators(ProcessTryCatchRegions.java:75)
	at jadx.core.dex.visitors.regions.ProcessTryCatchRegions.process(ProcessTryCatchRegions.java:45)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.postProcessRegions(RegionMakerVisitor.java:63)
	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:58)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = this;
        r0 = r1.mDateFormat;	 Catch:{ ParseException -> 0x000b }
        r0 = r0.parse(r2);	 Catch:{ ParseException -> 0x000b }
        r3.setTime(r0);	 Catch:{ ParseException -> 0x000b }
        r2 = 1;
        return r2;
    L_0x000b:
        r3 = new java.lang.StringBuilder;
        r3.<init>();
        r0 = "Date: ";
        r3.append(r0);
        r3.append(r2);
        r2 = " not in format: ";
        r3.append(r2);
        r2 = "MM/dd/yyyy";
        r3.append(r2);
        r2 = r3.toString();
        r3 = "DatePicker";
        android.util.Log.w(r3, r2);
        r2 = 0;
        return r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.picker.DatePicker.parseDate(java.lang.String, java.util.Calendar):boolean");
    }

    String getBestYearMonthDayPattern(String str) {
        boolean z = PickerUtility.SUPPORTS_BEST_DATE_TIME_PATTERN;
        String str2 = DATE_FORMAT;
        if (z) {
            str = android.text.format.DateFormat.getBestDateTimePattern(this.mConstant.locale, str);
        } else {
            str = android.text.format.DateFormat.getDateFormat(getContext());
            str = str instanceof SimpleDateFormat ? ((SimpleDateFormat) str).toLocalizedPattern() : str2;
        }
        return TextUtils.isEmpty(str) ? str2 : str;
    }

    List<CharSequence> extractSeparators() {
        String bestYearMonthDayPattern = getBestYearMonthDayPattern(this.mDatePickerFormat);
        List<CharSequence> arrayList = new ArrayList();
        StringBuilder stringBuilder = new StringBuilder();
        char[] cArr = new char[]{'Y', 'y', 'M', 'm', 'D', 'd'};
        Object obj = null;
        char c = '\u0000';
        for (int i = 0; i < bestYearMonthDayPattern.length(); i++) {
            char charAt = bestYearMonthDayPattern.charAt(i);
            if (charAt != ' ') {
                if (charAt != '\'') {
                    if (obj != null) {
                        stringBuilder.append(charAt);
                    } else if (!isAnyOf(charAt, cArr)) {
                        stringBuilder.append(charAt);
                    } else if (charAt != c) {
                        arrayList.add(stringBuilder.toString());
                        stringBuilder.setLength(0);
                    }
                    c = charAt;
                } else if (obj == null) {
                    stringBuilder.setLength(0);
                    obj = 1;
                } else {
                    obj = null;
                }
            }
        }
        arrayList.add(stringBuilder.toString());
        return arrayList;
    }

    private static boolean isAnyOf(char c, char[] cArr) {
        for (char c2 : cArr) {
            if (c == c2) {
                return true;
            }
        }
        return false;
    }

    public void setDatePickerFormat(String str) {
        if (TextUtils.isEmpty(str)) {
            str = new String(android.text.format.DateFormat.getDateFormatOrder(getContext()));
        }
        if (!TextUtils.equals(this.mDatePickerFormat, str)) {
            this.mDatePickerFormat = str;
            List extractSeparators = extractSeparators();
            if (extractSeparators.size() == str.length() + 1) {
                setSeparators(extractSeparators);
                this.mDayColumn = null;
                this.mMonthColumn = null;
                this.mYearColumn = null;
                this.mColMonthIndex = -1;
                this.mColDayIndex = -1;
                this.mColYearIndex = -1;
                str = str.toUpperCase();
                extractSeparators = new ArrayList(3);
                for (int i = 0; i < str.length(); i++) {
                    char charAt = str.charAt(i);
                    String str2 = "datePicker format error";
                    PickerColumn pickerColumn;
                    if (charAt != 'D') {
                        if (charAt != 'M') {
                            if (charAt != 'Y') {
                                throw new IllegalArgumentException(str2);
                            } else if (this.mYearColumn == null) {
                                pickerColumn = new PickerColumn();
                                this.mYearColumn = pickerColumn;
                                extractSeparators.add(pickerColumn);
                                this.mColYearIndex = i;
                                this.mYearColumn.setLabelFormat("%d");
                            } else {
                                throw new IllegalArgumentException(str2);
                            }
                        } else if (this.mMonthColumn == null) {
                            pickerColumn = new PickerColumn();
                            this.mMonthColumn = pickerColumn;
                            extractSeparators.add(pickerColumn);
                            this.mMonthColumn.setStaticLabels(this.mConstant.months);
                            this.mColMonthIndex = i;
                        } else {
                            throw new IllegalArgumentException(str2);
                        }
                    } else if (this.mDayColumn == null) {
                        pickerColumn = new PickerColumn();
                        this.mDayColumn = pickerColumn;
                        extractSeparators.add(pickerColumn);
                        this.mDayColumn.setLabelFormat("%02d");
                        this.mColDayIndex = i;
                    } else {
                        throw new IllegalArgumentException(str2);
                    }
                }
                setColumns(extractSeparators);
                updateSpinners(false);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Separators size: ");
            stringBuilder.append(extractSeparators.size());
            stringBuilder.append(" must equal");
            stringBuilder.append(" the size of datePickerFormat: ");
            stringBuilder.append(str.length());
            stringBuilder.append(" + 1");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    public String getDatePickerFormat() {
        return this.mDatePickerFormat;
    }

    private void updateCurrentLocale() {
        this.mConstant = PickerUtility.getDateConstantInstance(Locale.getDefault(), getContext().getResources());
        this.mTempDate = PickerUtility.getCalendarForLocale(this.mTempDate, this.mConstant.locale);
        this.mMinDate = PickerUtility.getCalendarForLocale(this.mMinDate, this.mConstant.locale);
        this.mMaxDate = PickerUtility.getCalendarForLocale(this.mMaxDate, this.mConstant.locale);
        this.mCurrentDate = PickerUtility.getCalendarForLocale(this.mCurrentDate, this.mConstant.locale);
        PickerColumn pickerColumn = this.mMonthColumn;
        if (pickerColumn != null) {
            pickerColumn.setStaticLabels(this.mConstant.months);
            setColumnAt(this.mColMonthIndex, this.mMonthColumn);
        }
    }

    public final void onColumnValueChanged(int i, int i2) {
        this.mTempDate.setTimeInMillis(this.mCurrentDate.getTimeInMillis());
        int currentValue = getColumnAt(i).getCurrentValue();
        if (i == this.mColDayIndex) {
            this.mTempDate.add(5, i2 - currentValue);
        } else if (i == this.mColMonthIndex) {
            this.mTempDate.add(2, i2 - currentValue);
        } else if (i == this.mColYearIndex) {
            this.mTempDate.add(1, i2 - currentValue);
        } else {
            throw new IllegalArgumentException();
        }
        setDate(this.mTempDate.get(1), this.mTempDate.get(2), this.mTempDate.get(5));
        updateSpinners(0);
    }

    public void setMinDate(long j) {
        this.mTempDate.setTimeInMillis(j);
        if (this.mTempDate.get(1) != this.mMinDate.get(1) || this.mTempDate.get(6) == this.mMinDate.get(6)) {
            this.mMinDate.setTimeInMillis(j);
            if (this.mCurrentDate.before(this.mMinDate) != null) {
                this.mCurrentDate.setTimeInMillis(this.mMinDate.getTimeInMillis());
            }
            updateSpinners(0);
        }
    }

    public long getMinDate() {
        return this.mMinDate.getTimeInMillis();
    }

    public void setMaxDate(long j) {
        this.mTempDate.setTimeInMillis(j);
        if (this.mTempDate.get(1) != this.mMaxDate.get(1) || this.mTempDate.get(6) == this.mMaxDate.get(6)) {
            this.mMaxDate.setTimeInMillis(j);
            if (this.mCurrentDate.after(this.mMaxDate) != null) {
                this.mCurrentDate.setTimeInMillis(this.mMaxDate.getTimeInMillis());
            }
            updateSpinners(0);
        }
    }

    public long getMaxDate() {
        return this.mMaxDate.getTimeInMillis();
    }

    public long getDate() {
        return this.mCurrentDate.getTimeInMillis();
    }

    private void setDate(int i, int i2, int i3) {
        this.mCurrentDate.set(i, i2, i3);
        if (this.mCurrentDate.before(this.mMinDate) != 0) {
            this.mCurrentDate.setTimeInMillis(this.mMinDate.getTimeInMillis());
        } else if (this.mCurrentDate.after(this.mMaxDate) != 0) {
            this.mCurrentDate.setTimeInMillis(this.mMaxDate.getTimeInMillis());
        }
    }

    public void updateDate(int i, int i2, int i3, boolean z) {
        if (isNewDate(i, i2, i3)) {
            setDate(i, i2, i3);
            updateSpinners(z);
        }
    }

    private boolean isNewDate(int i, int i2, int i3) {
        if (this.mCurrentDate.get(1) != i || this.mCurrentDate.get(2) != i3) {
            return true;
        }
        if (this.mCurrentDate.get(5) != i2) {
            return true;
        }
        return false;
    }

    private static boolean updateMin(PickerColumn pickerColumn, int i) {
        if (i == pickerColumn.getMinValue()) {
            return null;
        }
        pickerColumn.setMinValue(i);
        return true;
    }

    private static boolean updateMax(PickerColumn pickerColumn, int i) {
        if (i == pickerColumn.getMaxValue()) {
            return null;
        }
        pickerColumn.setMaxValue(i);
        return true;
    }

    void updateSpinnersImpl(boolean z) {
        int[] iArr = new int[]{this.mColDayIndex, this.mColMonthIndex, this.mColYearIndex};
        int i = 1;
        int i2 = 1;
        for (int length = DATE_FIELDS.length - 1; length >= 0; length--) {
            if (iArr[length] >= 0) {
                int updateMin;
                int updateMax;
                int i3 = DATE_FIELDS[length];
                PickerColumn columnAt = getColumnAt(iArr[length]);
                if (i != 0) {
                    updateMin = updateMin(columnAt, this.mMinDate.get(i3));
                } else {
                    updateMin = updateMin(columnAt, this.mCurrentDate.getActualMinimum(i3));
                }
                updateMin |= 0;
                if (i2 != 0) {
                    updateMax = updateMax(columnAt, this.mMaxDate.get(i3));
                } else {
                    updateMax = updateMax(columnAt, this.mCurrentDate.getActualMaximum(i3));
                }
                i &= this.mCurrentDate.get(i3) == this.mMinDate.get(i3) ? 1 : 0;
                i2 &= this.mCurrentDate.get(i3) == this.mMaxDate.get(i3) ? 1 : 0;
                if ((updateMin | updateMax) != 0) {
                    setColumnAt(iArr[length], columnAt);
                }
                setColumnValue(iArr[length], this.mCurrentDate.get(i3), z);
            }
        }
    }

    private void updateSpinners(final boolean z) {
        post(new Runnable() {
            public void run() {
                DatePicker.this.updateSpinnersImpl(z);
            }
        });
    }
}
