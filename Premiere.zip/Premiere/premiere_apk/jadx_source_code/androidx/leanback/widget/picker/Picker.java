package androidx.leanback.widget.picker;

import android.content.Context;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.leanback.R;
import androidx.leanback.widget.OnChildViewHolderSelectedListener;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Picker extends FrameLayout {
    private Interpolator mAccelerateInterpolator;
    private int mAlphaAnimDuration;
    private final OnChildViewHolderSelectedListener mColumnChangeListener = new OnChildViewHolderSelectedListener() {
        public void onChildViewHolderSelected(RecyclerView recyclerView, androidx.recyclerview.widget.RecyclerView.ViewHolder viewHolder, int i, int i2) {
            PickerScrollArrayAdapter pickerScrollArrayAdapter = (PickerScrollArrayAdapter) recyclerView.getAdapter();
            recyclerView = Picker.this.mColumnViews.indexOf(recyclerView);
            Picker.this.updateColumnAlpha(recyclerView, true);
            if (viewHolder != null) {
                Picker.this.onColumnValueChanged(recyclerView, ((PickerColumn) Picker.this.mColumns.get(recyclerView)).getMinValue() + i);
            }
        }
    };
    final List<VerticalGridView> mColumnViews = new ArrayList();
    ArrayList<PickerColumn> mColumns;
    private Interpolator mDecelerateInterpolator;
    private float mFocusedAlpha;
    private float mInvisibleColumnAlpha;
    private ArrayList<PickerValueListener> mListeners;
    private int mPickerItemLayoutId = R.layout.lb_picker_item;
    private int mPickerItemTextViewId = 0;
    private ViewGroup mPickerView;
    private ViewGroup mRootView;
    private int mSelectedColumn = 0;
    private List<CharSequence> mSeparators = new ArrayList();
    private float mUnfocusedAlpha;
    private float mVisibleColumnAlpha;
    private float mVisibleItems = 1.0f;
    private float mVisibleItemsActivated = 3.0f;

    public interface PickerValueListener {
        void onValueChanged(Picker picker, int i);
    }

    class PickerScrollArrayAdapter extends Adapter<ViewHolder> {
        private final int mColIndex;
        private PickerColumn mData;
        private final int mResource;
        private final int mTextViewResourceId;

        PickerScrollArrayAdapter(Context context, int i, int i2, int i3) {
            this.mResource = i;
            this.mColIndex = i3;
            this.mTextViewResourceId = i2;
            this.mData = (PickerColumn) Picker.this.mColumns.get(this.mColIndex);
        }

        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            viewGroup = LayoutInflater.from(viewGroup.getContext()).inflate(this.mResource, viewGroup, false);
            i = this.mTextViewResourceId;
            if (i != 0) {
                i = (TextView) viewGroup.findViewById(i);
            } else {
                i = (TextView) viewGroup;
            }
            return new ViewHolder(viewGroup, i);
        }

        public void onBindViewHolder(ViewHolder viewHolder, int i) {
            if (!(viewHolder.textView == null || this.mData == null)) {
                TextView textView = viewHolder.textView;
                PickerColumn pickerColumn = this.mData;
                textView.setText(pickerColumn.getLabelFor(pickerColumn.getMinValue() + i));
            }
            Picker.this.setOrAnimateAlpha(viewHolder.itemView, ((VerticalGridView) Picker.this.mColumnViews.get(this.mColIndex)).getSelectedPosition() == i ? 1 : 0, this.mColIndex, false);
        }

        public void onViewAttachedToWindow(ViewHolder viewHolder) {
            viewHolder.itemView.setFocusable(Picker.this.isActivated());
        }

        public int getItemCount() {
            PickerColumn pickerColumn = this.mData;
            return pickerColumn == null ? 0 : pickerColumn.getCount();
        }
    }

    static class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        final TextView textView;

        ViewHolder(View view, TextView textView) {
            super(view);
            this.textView = textView;
        }
    }

    public float getVisibleItemCount() {
        return 1.0f;
    }

    public final CharSequence getSeparator() {
        return (CharSequence) this.mSeparators.get(0);
    }

    public final void setSeparator(CharSequence charSequence) {
        setSeparators(Arrays.asList(new CharSequence[]{charSequence}));
    }

    public final List<CharSequence> getSeparators() {
        return this.mSeparators;
    }

    public final void setSeparators(List<CharSequence> list) {
        this.mSeparators.clear();
        this.mSeparators.addAll(list);
    }

    public final int getPickerItemLayoutId() {
        return this.mPickerItemLayoutId;
    }

    public final int getPickerItemTextViewId() {
        return this.mPickerItemTextViewId;
    }

    public final void setPickerItemTextViewId(int i) {
        this.mPickerItemTextViewId = i;
    }

    public Picker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        setEnabled(true);
        setDescendantFocusability(262144);
        this.mFocusedAlpha = 1.0f;
        this.mUnfocusedAlpha = 1.0f;
        this.mVisibleColumnAlpha = 0.5f;
        this.mInvisibleColumnAlpha = null;
        this.mAlphaAnimDuration = 200;
        this.mDecelerateInterpolator = new DecelerateInterpolator(2.5f);
        this.mAccelerateInterpolator = new AccelerateInterpolator(2.5f);
        this.mRootView = (ViewGroup) LayoutInflater.from(getContext()).inflate(R.layout.lb_picker, this, true);
        this.mPickerView = (ViewGroup) this.mRootView.findViewById(R.id.picker);
    }

    public PickerColumn getColumnAt(int i) {
        ArrayList arrayList = this.mColumns;
        if (arrayList == null) {
            return 0;
        }
        return (PickerColumn) arrayList.get(i);
    }

    public int getColumnsCount() {
        ArrayList arrayList = this.mColumns;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    public void setColumns(List<PickerColumn> list) {
        if (this.mSeparators.size() != 0) {
            if (this.mSeparators.size() == 1) {
                CharSequence charSequence = (CharSequence) this.mSeparators.get(0);
                this.mSeparators.clear();
                String str = "";
                this.mSeparators.add(str);
                for (int i = 0; i < list.size() - 1; i++) {
                    this.mSeparators.add(charSequence);
                }
                this.mSeparators.add(str);
            } else if (this.mSeparators.size() != list.size() + 1) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Separators size: ");
                stringBuilder.append(this.mSeparators.size());
                stringBuilder.append(" must");
                stringBuilder.append("equal the size of columns: ");
                stringBuilder.append(list.size());
                stringBuilder.append(" + 1");
                throw new IllegalStateException(stringBuilder.toString());
            }
            this.mColumnViews.clear();
            this.mPickerView.removeAllViews();
            this.mColumns = new ArrayList(list);
            if (this.mSelectedColumn > this.mColumns.size() - 1) {
                this.mSelectedColumn = this.mColumns.size() - 1;
            }
            list = LayoutInflater.from(getContext());
            int columnsCount = getColumnsCount();
            if (!TextUtils.isEmpty((CharSequence) this.mSeparators.get(0))) {
                TextView textView = (TextView) list.inflate(R.layout.lb_picker_separator, this.mPickerView, false);
                textView.setText((CharSequence) this.mSeparators.get(0));
                this.mPickerView.addView(textView);
            }
            int i2 = 0;
            while (i2 < columnsCount) {
                VerticalGridView verticalGridView = (VerticalGridView) list.inflate(R.layout.lb_picker_column, this.mPickerView, false);
                updateColumnSize(verticalGridView);
                verticalGridView.setWindowAlignment(0);
                verticalGridView.setHasFixedSize(false);
                verticalGridView.setFocusable(isActivated());
                verticalGridView.setItemViewCacheSize(0);
                this.mColumnViews.add(verticalGridView);
                this.mPickerView.addView(verticalGridView);
                int i3 = i2 + 1;
                if (!TextUtils.isEmpty((CharSequence) this.mSeparators.get(i3))) {
                    TextView textView2 = (TextView) list.inflate(R.layout.lb_picker_separator, this.mPickerView, false);
                    textView2.setText((CharSequence) this.mSeparators.get(i3));
                    this.mPickerView.addView(textView2);
                }
                verticalGridView.setAdapter(new PickerScrollArrayAdapter(getContext(), getPickerItemLayoutId(), getPickerItemTextViewId(), i2));
                verticalGridView.setOnChildViewHolderSelectedListener(this.mColumnChangeListener);
                i2 = i3;
            }
            return;
        }
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Separators size is: ");
        stringBuilder2.append(this.mSeparators.size());
        stringBuilder2.append(". At least one separator must be provided");
        throw new IllegalStateException(stringBuilder2.toString());
    }

    public void setColumnAt(int i, PickerColumn pickerColumn) {
        this.mColumns.set(i, pickerColumn);
        VerticalGridView verticalGridView = (VerticalGridView) this.mColumnViews.get(i);
        PickerScrollArrayAdapter pickerScrollArrayAdapter = (PickerScrollArrayAdapter) verticalGridView.getAdapter();
        if (pickerScrollArrayAdapter != null) {
            pickerScrollArrayAdapter.notifyDataSetChanged();
        }
        verticalGridView.setSelectedPosition(pickerColumn.getCurrentValue() - pickerColumn.getMinValue());
    }

    public void setColumnValue(int i, int i2, boolean z) {
        PickerColumn pickerColumn = (PickerColumn) this.mColumns.get(i);
        if (pickerColumn.getCurrentValue() != i2) {
            pickerColumn.setCurrentValue(i2);
            notifyValueChanged(i);
            VerticalGridView verticalGridView = (VerticalGridView) this.mColumnViews.get(i);
            if (verticalGridView != null) {
                i2 -= ((PickerColumn) this.mColumns.get(i)).getMinValue();
                if (z) {
                    verticalGridView.setSelectedPositionSmooth(i2);
                } else {
                    verticalGridView.setSelectedPosition(i2);
                }
            }
        }
    }

    private void notifyValueChanged(int i) {
        ArrayList arrayList = this.mListeners;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((PickerValueListener) this.mListeners.get(size)).onValueChanged(this, i);
            }
        }
    }

    public void addOnValueChangedListener(PickerValueListener pickerValueListener) {
        if (this.mListeners == null) {
            this.mListeners = new ArrayList();
        }
        this.mListeners.add(pickerValueListener);
    }

    public void removeOnValueChangedListener(PickerValueListener pickerValueListener) {
        ArrayList arrayList = this.mListeners;
        if (arrayList != null) {
            arrayList.remove(pickerValueListener);
        }
    }

    void updateColumnAlpha(int i, boolean z) {
        VerticalGridView verticalGridView = (VerticalGridView) this.mColumnViews.get(i);
        int selectedPosition = verticalGridView.getSelectedPosition();
        int i2 = 0;
        while (i2 < verticalGridView.getAdapter().getItemCount()) {
            View findViewByPosition = verticalGridView.getLayoutManager().findViewByPosition(i2);
            if (findViewByPosition != null) {
                setOrAnimateAlpha(findViewByPosition, selectedPosition == i2, i, z);
            }
            i2++;
        }
    }

    void setOrAnimateAlpha(View view, boolean z, int i, boolean z2) {
        Object obj;
        if (i != this.mSelectedColumn) {
            if (hasFocus()) {
                obj = null;
                if (z) {
                    if (obj == null) {
                        setOrAnimateAlpha(view, z2, this.mVisibleColumnAlpha, -1.0f, this.mDecelerateInterpolator);
                    }
                    setOrAnimateAlpha(view, z2, this.mInvisibleColumnAlpha, -1.0f, this.mDecelerateInterpolator);
                    return;
                } else if (obj == null) {
                    setOrAnimateAlpha(view, z2, this.mFocusedAlpha, -1.0f, this.mDecelerateInterpolator);
                } else {
                    setOrAnimateAlpha(view, z2, this.mUnfocusedAlpha, -1.0f, this.mDecelerateInterpolator);
                }
            }
        }
        obj = 1;
        if (z) {
            if (obj == null) {
                setOrAnimateAlpha(view, z2, this.mInvisibleColumnAlpha, -1.0f, this.mDecelerateInterpolator);
                return;
            }
            setOrAnimateAlpha(view, z2, this.mVisibleColumnAlpha, -1.0f, this.mDecelerateInterpolator);
        } else if (obj == null) {
            setOrAnimateAlpha(view, z2, this.mUnfocusedAlpha, -1.0f, this.mDecelerateInterpolator);
        } else {
            setOrAnimateAlpha(view, z2, this.mFocusedAlpha, -1.0f, this.mDecelerateInterpolator);
        }
    }

    private void setOrAnimateAlpha(View view, boolean z, float f, float f2, Interpolator interpolator) {
        view.animate().cancel();
        if (z) {
            if (f2 >= false) {
                view.setAlpha(f2);
            }
            view.animate().alpha(f).setDuration((long) this.mAlphaAnimDuration).setInterpolator(interpolator).start();
            return;
        }
        view.setAlpha(f);
    }

    public void onColumnValueChanged(int i, int i2) {
        PickerColumn pickerColumn = (PickerColumn) this.mColumns.get(i);
        if (pickerColumn.getCurrentValue() != i2) {
            pickerColumn.setCurrentValue(i2);
            notifyValueChanged(i);
        }
    }

    private float getFloat(int i) {
        TypedValue typedValue = new TypedValue();
        getContext().getResources().getValue(i, typedValue, true);
        return typedValue.getFloat();
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!isActivated()) {
            return super.dispatchKeyEvent(keyEvent);
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyCode != 23 && keyCode != 66) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (keyEvent.getAction() == 1) {
            performClick();
        }
        return true;
    }

    protected boolean onRequestFocusInDescendants(int i, Rect rect) {
        int selectedColumn = getSelectedColumn();
        return selectedColumn < this.mColumnViews.size() ? ((VerticalGridView) this.mColumnViews.get(selectedColumn)).requestFocus(i, rect) : false;
    }

    protected int getPickerItemHeightPixels() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.picker_item_height);
    }

    private void updateColumnSize() {
        for (int i = 0; i < getColumnsCount(); i++) {
            updateColumnSize((VerticalGridView) this.mColumnViews.get(i));
        }
    }

    private void updateColumnSize(VerticalGridView verticalGridView) {
        LayoutParams layoutParams = verticalGridView.getLayoutParams();
        float activatedVisibleItemCount = isActivated() ? getActivatedVisibleItemCount() : getVisibleItemCount();
        layoutParams.height = (int) ((((float) getPickerItemHeightPixels()) * activatedVisibleItemCount) + (((float) verticalGridView.getVerticalSpacing()) * (activatedVisibleItemCount - 1.0f)));
        verticalGridView.setLayoutParams(layoutParams);
    }

    private void updateItemFocusable() {
        boolean isActivated = isActivated();
        for (int i = 0; i < getColumnsCount(); i++) {
            VerticalGridView verticalGridView = (VerticalGridView) this.mColumnViews.get(i);
            for (int i2 = 0; i2 < verticalGridView.getChildCount(); i2++) {
                verticalGridView.getChildAt(i2).setFocusable(isActivated);
            }
        }
    }

    public float getActivatedVisibleItemCount() {
        return this.mVisibleItemsActivated;
    }

    public void setActivatedVisibleItemCount(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException();
        } else if (this.mVisibleItemsActivated != f) {
            this.mVisibleItemsActivated = f;
            if (isActivated() != null) {
                updateColumnSize();
            }
        }
    }

    public void setVisibleItemCount(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException();
        } else if (this.mVisibleItems != f) {
            this.mVisibleItems = f;
            if (isActivated() == null) {
                updateColumnSize();
            }
        }
    }

    public void setActivated(boolean z) {
        if (z == isActivated()) {
            super.setActivated(z);
            return;
        }
        super.setActivated(z);
        boolean hasFocus = hasFocus();
        int selectedColumn = getSelectedColumn();
        setDescendantFocusability(131072);
        if (!z && hasFocus && isFocusable()) {
            requestFocus();
        }
        for (int i = 0; i < getColumnsCount(); i++) {
            ((VerticalGridView) this.mColumnViews.get(i)).setFocusable(z);
        }
        updateColumnSize();
        updateItemFocusable();
        if (z && hasFocus && selectedColumn >= 0) {
            ((VerticalGridView) this.mColumnViews.get(selectedColumn)).requestFocus();
        }
        setDescendantFocusability(true);
    }

    public void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        for (view = null; view < this.mColumnViews.size(); view++) {
            if (((VerticalGridView) this.mColumnViews.get(view)).hasFocus() != null) {
                setSelectedColumn(view);
            }
        }
    }

    public void setSelectedColumn(int i) {
        if (this.mSelectedColumn != i) {
            this.mSelectedColumn = i;
            for (i = 0; i < this.mColumnViews.size(); i++) {
                updateColumnAlpha(i, true);
            }
        }
    }

    public int getSelectedColumn() {
        return this.mSelectedColumn;
    }
}
