package androidx.leanback.widget;

import android.view.View;
import android.view.ViewGroup;

@Deprecated
public interface OnChildSelectedListener {
    void onChildSelected(ViewGroup viewGroup, View view, int i, long j);
}
