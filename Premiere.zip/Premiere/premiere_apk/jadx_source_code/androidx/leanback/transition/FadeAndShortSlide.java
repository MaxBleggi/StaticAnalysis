package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.graphics.Rect;
import android.transition.Fade;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;
import android.transition.Transition.TransitionListener;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import androidx.core.view.GravityCompat;
import androidx.leanback.R;

public class FadeAndShortSlide extends Visibility {
    private static final String PROPNAME_SCREEN_POSITION = "android:fadeAndShortSlideTransition:screenPosition";
    static final CalculateSlide sCalculateBottom = new CalculateSlide() {
        public float getGoneY(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY() + fadeAndShortSlide.getVerticalDistance(viewGroup);
        }
    };
    static final CalculateSlide sCalculateEnd = new CalculateSlide() {
        public float getGoneX(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            Object obj = 1;
            if (viewGroup.getLayoutDirection() != 1) {
                obj = null;
            }
            if (obj != null) {
                return view.getTranslationX() - fadeAndShortSlide.getHorizontalDistance(viewGroup);
            }
            return view.getTranslationX() + fadeAndShortSlide.getHorizontalDistance(viewGroup);
        }
    };
    static final CalculateSlide sCalculateStart = new CalculateSlide() {
        public float getGoneX(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            Object obj = 1;
            if (viewGroup.getLayoutDirection() != 1) {
                obj = null;
            }
            if (obj != null) {
                return view.getTranslationX() + fadeAndShortSlide.getHorizontalDistance(viewGroup);
            }
            return view.getTranslationX() - fadeAndShortSlide.getHorizontalDistance(viewGroup);
        }
    };
    static final CalculateSlide sCalculateStartEnd = new CalculateSlide() {
        public float getGoneX(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            int width = iArr[0] + (view.getWidth() / 2);
            viewGroup.getLocationOnScreen(iArr);
            Rect epicenter = fadeAndShortSlide.getEpicenter();
            if (epicenter == null) {
                iArr = iArr[0] + (viewGroup.getWidth() / 2);
            } else {
                iArr = epicenter.centerX();
            }
            if (width < iArr) {
                return view.getTranslationX() - fadeAndShortSlide.getHorizontalDistance(viewGroup);
            }
            return view.getTranslationX() + fadeAndShortSlide.getHorizontalDistance(viewGroup);
        }
    };
    static final CalculateSlide sCalculateTop = new CalculateSlide() {
        public float getGoneY(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY() - fadeAndShortSlide.getVerticalDistance(viewGroup);
        }
    };
    private static final TimeInterpolator sDecelerate = new DecelerateInterpolator();
    private float mDistance;
    private Visibility mFade;
    private CalculateSlide mSlideCalculator;
    final CalculateSlide sCalculateTopBottom;

    private static abstract class CalculateSlide {
        CalculateSlide() {
        }

        float getGoneX(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationX();
        }

        float getGoneY(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY();
        }
    }

    float getHorizontalDistance(ViewGroup viewGroup) {
        float f = this.mDistance;
        return f >= 0.0f ? f : (float) (viewGroup.getWidth() / 4);
    }

    float getVerticalDistance(ViewGroup viewGroup) {
        float f = this.mDistance;
        return f >= 0.0f ? f : (float) (viewGroup.getHeight() / 4);
    }

    public FadeAndShortSlide() {
        this(GravityCompat.START);
    }

    public FadeAndShortSlide(int i) {
        this.mFade = new Fade();
        this.mDistance = -1.0f;
        this.sCalculateTopBottom = new CalculateSlide() {
            public float getGoneY(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
                int height = iArr[1] + (view.getHeight() / 2);
                viewGroup.getLocationOnScreen(iArr);
                Rect epicenter = FadeAndShortSlide.this.getEpicenter();
                if (epicenter == null) {
                    iArr = iArr[1] + (viewGroup.getHeight() / 2);
                } else {
                    iArr = epicenter.centerY();
                }
                if (height < iArr) {
                    return view.getTranslationY() - fadeAndShortSlide.getVerticalDistance(viewGroup);
                }
                return view.getTranslationY() + fadeAndShortSlide.getVerticalDistance(viewGroup);
            }
        };
        setSlideEdge(i);
    }

    public FadeAndShortSlide(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mFade = new Fade();
        this.mDistance = -1.0f;
        this.sCalculateTopBottom = /* anonymous class already generated */;
        context = context.obtainStyledAttributes(attributeSet, R.styleable.lbSlide);
        setSlideEdge(context.getInt(R.styleable.lbSlide_lb_slideEdge, GravityCompat.START));
        context.recycle();
    }

    public void setEpicenterCallback(EpicenterCallback epicenterCallback) {
        this.mFade.setEpicenterCallback(epicenterCallback);
        super.setEpicenterCallback(epicenterCallback);
    }

    private void captureValues(TransitionValues transitionValues) {
        Object obj = new int[2];
        transitionValues.view.getLocationOnScreen(obj);
        transitionValues.values.put(PROPNAME_SCREEN_POSITION, obj);
    }

    public void captureStartValues(TransitionValues transitionValues) {
        this.mFade.captureStartValues(transitionValues);
        super.captureStartValues(transitionValues);
        captureValues(transitionValues);
    }

    public void captureEndValues(TransitionValues transitionValues) {
        this.mFade.captureEndValues(transitionValues);
        super.captureEndValues(transitionValues);
        captureValues(transitionValues);
    }

    public void setSlideEdge(int i) {
        if (i == 48) {
            this.mSlideCalculator = sCalculateTop;
        } else if (i == 80) {
            this.mSlideCalculator = sCalculateBottom;
        } else if (i == 112) {
            this.mSlideCalculator = this.sCalculateTopBottom;
        } else if (i == GravityCompat.START) {
            this.mSlideCalculator = sCalculateStart;
        } else if (i == GravityCompat.END) {
            this.mSlideCalculator = sCalculateEnd;
        } else if (i == GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK) {
            this.mSlideCalculator = sCalculateStartEnd;
        } else {
            throw new IllegalArgumentException("Invalid slide direction");
        }
    }

    public Animator onAppear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        FadeAndShortSlide fadeAndShortSlide = this;
        View view2 = viewGroup;
        View view3 = view;
        TransitionValues transitionValues3 = transitionValues2;
        if (transitionValues3 == null || view2 == view3) {
            return null;
        }
        int[] iArr = (int[]) transitionValues3.values.get(PROPNAME_SCREEN_POSITION);
        int i = iArr[0];
        int i2 = iArr[1];
        float translationX = view.getTranslationX();
        View view4 = view;
        TransitionValues transitionValues4 = transitionValues2;
        Animator createAnimation = TranslationAnimationCreator.createAnimation(view4, transitionValues4, i, i2, fadeAndShortSlide.mSlideCalculator.getGoneX(this, viewGroup, view3, iArr), fadeAndShortSlide.mSlideCalculator.getGoneY(this, viewGroup, view3, iArr), translationX, view.getTranslationY(), sDecelerate, this);
        Animator onAppear = fadeAndShortSlide.mFade.onAppear(viewGroup, view3, transitionValues, transitionValues3);
        if (createAnimation == null) {
            return onAppear;
        }
        if (onAppear == null) {
            return createAnimation;
        }
        Animator animatorSet = new AnimatorSet();
        animatorSet.play(createAnimation).with(onAppear);
        return animatorSet;
    }

    public Animator onDisappear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        FadeAndShortSlide fadeAndShortSlide = this;
        View view2 = viewGroup;
        View view3 = view;
        TransitionValues transitionValues3 = transitionValues;
        if (transitionValues3 == null || view2 == view3) {
            return null;
        }
        int[] iArr = (int[]) transitionValues3.values.get(PROPNAME_SCREEN_POSITION);
        int i = iArr[0];
        int i2 = iArr[1];
        float translationX = view.getTranslationX();
        float goneX = fadeAndShortSlide.mSlideCalculator.getGoneX(this, viewGroup, view3, iArr);
        Animator createAnimation = TranslationAnimationCreator.createAnimation(view, transitionValues, i, i2, translationX, view.getTranslationY(), goneX, fadeAndShortSlide.mSlideCalculator.getGoneY(this, viewGroup, view3, iArr), sDecelerate, this);
        Animator onDisappear = fadeAndShortSlide.mFade.onDisappear(viewGroup, view3, transitionValues3, transitionValues2);
        if (createAnimation == null) {
            return onDisappear;
        }
        if (onDisappear == null) {
            return createAnimation;
        }
        Animator animatorSet = new AnimatorSet();
        animatorSet.play(createAnimation).with(onDisappear);
        return animatorSet;
    }

    public Transition addListener(TransitionListener transitionListener) {
        this.mFade.addListener(transitionListener);
        return super.addListener(transitionListener);
    }

    public Transition removeListener(TransitionListener transitionListener) {
        this.mFade.removeListener(transitionListener);
        return super.removeListener(transitionListener);
    }

    public float getDistance() {
        return this.mDistance;
    }

    public void setDistance(float f) {
        this.mDistance = f;
    }

    public Transition clone() {
        FadeAndShortSlide fadeAndShortSlide = (FadeAndShortSlide) super.clone();
        fadeAndShortSlide.mFade = (Visibility) this.mFade.clone();
        return fadeAndShortSlide;
    }
}
