package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.transition.Transition;
import android.transition.TransitionValues;
import android.view.View;
import android.view.ViewGroup;

class Scale extends Transition {
    private static final String PROPNAME_SCALE = "android:leanback:scale";

    private void captureValues(TransitionValues transitionValues) {
        View view = transitionValues.view;
        transitionValues.values.put(PROPNAME_SCALE, Float.valueOf(view.getScaleX()));
    }

    public void captureStartValues(TransitionValues transitionValues) {
        captureValues(transitionValues);
    }

    public void captureEndValues(TransitionValues transitionValues) {
        captureValues(transitionValues);
    }

    public Animator createAnimator(ViewGroup viewGroup, TransitionValues transitionValues, TransitionValues transitionValues2) {
        if (transitionValues != null) {
            if (transitionValues2 != null) {
                viewGroup = transitionValues.values;
                String str = PROPNAME_SCALE;
                viewGroup = ((Float) viewGroup.get(str)).floatValue();
                transitionValues2 = ((Float) transitionValues2.values.get(str)).floatValue();
                transitionValues = transitionValues.view;
                transitionValues.setScaleX(viewGroup);
                transitionValues.setScaleY(viewGroup);
                viewGroup = ValueAnimator.ofFloat(new float[]{viewGroup, transitionValues2});
                viewGroup.addUpdateListener(new AnimatorUpdateListener() {
                    public void onAnimationUpdate(ValueAnimator valueAnimator) {
                        valueAnimator = ((Float) valueAnimator.getAnimatedValue()).floatValue();
                        transitionValues.setScaleX(valueAnimator);
                        transitionValues.setScaleY(valueAnimator);
                    }
                });
                return viewGroup;
            }
        }
        return null;
    }
}
