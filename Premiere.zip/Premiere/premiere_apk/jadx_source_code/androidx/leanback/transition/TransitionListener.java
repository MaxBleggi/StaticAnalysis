package androidx.leanback.transition;

public class TransitionListener {
    protected Object mImpl;

    public void onTransitionCancel(Object obj) {
    }

    public void onTransitionEnd(Object obj) {
    }

    public void onTransitionPause(Object obj) {
    }

    public void onTransitionResume(Object obj) {
    }

    public void onTransitionStart(Object obj) {
    }
}
