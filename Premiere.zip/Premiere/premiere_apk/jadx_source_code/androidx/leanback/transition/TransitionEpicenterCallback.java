package androidx.leanback.transition;

import android.graphics.Rect;

public abstract class TransitionEpicenterCallback {
    public abstract Rect onGetEpicenter(Object obj);
}
