package androidx.leanback.app;

import android.view.SurfaceHolder.Callback;
import androidx.leanback.media.SurfaceHolderGlueHost;

@Deprecated
public class VideoFragmentGlueHost extends PlaybackFragmentGlueHost implements SurfaceHolderGlueHost {
    private final VideoFragment mFragment;

    public VideoFragmentGlueHost(VideoFragment videoFragment) {
        super(videoFragment);
        this.mFragment = videoFragment;
    }

    public void setSurfaceHolderCallback(Callback callback) {
        this.mFragment.setSurfaceHolderCallback(callback);
    }
}
