package androidx.leanback.app;

import android.view.View.OnKeyListener;
import androidx.leanback.media.PlaybackGlueHost;
import androidx.leanback.media.PlaybackGlueHost.HostCallback;
import androidx.leanback.media.PlaybackGlueHost.PlayerCallback;
import androidx.leanback.widget.Action;
import androidx.leanback.widget.OnActionClickedListener;
import androidx.leanback.widget.OnItemViewClickedListener;
import androidx.leanback.widget.PlaybackRowPresenter;
import androidx.leanback.widget.PlaybackSeekUi;
import androidx.leanback.widget.PlaybackSeekUi.Client;
import androidx.leanback.widget.Presenter.ViewHolder;
import androidx.leanback.widget.Row;
import androidx.leanback.widget.RowPresenter;

public class PlaybackSupportFragmentGlueHost extends PlaybackGlueHost implements PlaybackSeekUi {
    final PlaybackSupportFragment mFragment;
    final PlayerCallback mPlayerCallback = new PlayerCallback() {
        public void onBufferingStateChanged(boolean z) {
            PlaybackSupportFragmentGlueHost.this.mFragment.onBufferingStateChanged(z);
        }

        public void onError(int i, CharSequence charSequence) {
            PlaybackSupportFragmentGlueHost.this.mFragment.onError(i, charSequence);
        }

        public void onVideoSizeChanged(int i, int i2) {
            PlaybackSupportFragmentGlueHost.this.mFragment.onVideoSizeChanged(i, i2);
        }
    };

    public PlaybackSupportFragmentGlueHost(PlaybackSupportFragment playbackSupportFragment) {
        this.mFragment = playbackSupportFragment;
    }

    public void setControlsOverlayAutoHideEnabled(boolean z) {
        this.mFragment.setControlsOverlayAutoHideEnabled(z);
    }

    public boolean isControlsOverlayAutoHideEnabled() {
        return this.mFragment.isControlsOverlayAutoHideEnabled();
    }

    public void setOnKeyInterceptListener(OnKeyListener onKeyListener) {
        this.mFragment.setOnKeyInterceptListener(onKeyListener);
    }

    public void setOnActionClickedListener(final OnActionClickedListener onActionClickedListener) {
        if (onActionClickedListener == null) {
            this.mFragment.setOnPlaybackItemViewClickedListener(null);
        } else {
            this.mFragment.setOnPlaybackItemViewClickedListener(new OnItemViewClickedListener() {
                public void onItemClicked(ViewHolder viewHolder, Object obj, RowPresenter.ViewHolder viewHolder2, Row row) {
                    if ((obj instanceof Action) != null) {
                        onActionClickedListener.onActionClicked((Action) obj);
                    }
                }
            });
        }
    }

    public void setHostCallback(HostCallback hostCallback) {
        this.mFragment.setHostCallback(hostCallback);
    }

    public void notifyPlaybackRowChanged() {
        this.mFragment.notifyPlaybackRowChanged();
    }

    public void setPlaybackRowPresenter(PlaybackRowPresenter playbackRowPresenter) {
        this.mFragment.setPlaybackRowPresenter(playbackRowPresenter);
    }

    public void setPlaybackRow(Row row) {
        this.mFragment.setPlaybackRow(row);
    }

    public void fadeOut() {
        this.mFragment.fadeOut();
    }

    public boolean isControlsOverlayVisible() {
        return this.mFragment.isControlsOverlayVisible();
    }

    public void hideControlsOverlay(boolean z) {
        this.mFragment.hideControlsOverlay(z);
    }

    public void showControlsOverlay(boolean z) {
        this.mFragment.showControlsOverlay(z);
    }

    public void setPlaybackSeekUiClient(Client client) {
        this.mFragment.setPlaybackSeekUiClient(client);
    }

    public PlayerCallback getPlayerCallback() {
        return this.mPlayerCallback;
    }
}
