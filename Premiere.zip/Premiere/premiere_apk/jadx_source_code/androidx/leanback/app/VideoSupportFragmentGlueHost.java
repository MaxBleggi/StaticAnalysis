package androidx.leanback.app;

import android.view.SurfaceHolder.Callback;
import androidx.leanback.media.SurfaceHolderGlueHost;

public class VideoSupportFragmentGlueHost extends PlaybackSupportFragmentGlueHost implements SurfaceHolderGlueHost {
    private final VideoSupportFragment mFragment;

    public VideoSupportFragmentGlueHost(VideoSupportFragment videoSupportFragment) {
        super(videoSupportFragment);
        this.mFragment = videoSupportFragment;
    }

    public void setSurfaceHolderCallback(Callback callback) {
        this.mFragment.setSurfaceHolderCallback(callback);
    }
}
