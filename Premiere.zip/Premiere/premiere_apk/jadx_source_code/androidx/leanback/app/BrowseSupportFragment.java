package androidx.leanback.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewTreeObserver.OnPreDrawListener;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentManager.OnBackStackChangedListener;
import androidx.fragment.app.FragmentTransaction;
import androidx.leanback.R;
import androidx.leanback.app.HeadersSupportFragment.OnHeaderClickedListener;
import androidx.leanback.app.HeadersSupportFragment.OnHeaderViewSelectedListener;
import androidx.leanback.transition.TransitionHelper;
import androidx.leanback.transition.TransitionListener;
import androidx.leanback.util.StateMachine.Event;
import androidx.leanback.util.StateMachine.State;
import androidx.leanback.widget.BrowseFrameLayout;
import androidx.leanback.widget.BrowseFrameLayout.OnChildFocusListener;
import androidx.leanback.widget.BrowseFrameLayout.OnFocusSearchListener;
import androidx.leanback.widget.InvisibleRowPresenter;
import androidx.leanback.widget.ListRow;
import androidx.leanback.widget.ObjectAdapter;
import androidx.leanback.widget.OnItemViewClickedListener;
import androidx.leanback.widget.OnItemViewSelectedListener;
import androidx.leanback.widget.PageRow;
import androidx.leanback.widget.Presenter;
import androidx.leanback.widget.Presenter.ViewHolderTask;
import androidx.leanback.widget.PresenterSelector;
import androidx.leanback.widget.Row;
import androidx.leanback.widget.RowHeaderPresenter.ViewHolder;
import androidx.leanback.widget.RowPresenter;
import androidx.leanback.widget.ScaleFrameLayout;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.OnScrollListener;
import com.google.android.exoplayer2.extractor.ts.TsExtractor;
import java.util.HashMap;
import java.util.Map;

public class BrowseSupportFragment extends BaseSupportFragment {
    private static final String ARG_HEADERS_STATE;
    private static final String ARG_TITLE;
    private static final String CURRENT_SELECTED_POSITION = "currentSelectedPosition";
    static final boolean DEBUG = false;
    public static final int HEADERS_DISABLED = 3;
    public static final int HEADERS_ENABLED = 1;
    public static final int HEADERS_HIDDEN = 2;
    static final String HEADER_SHOW = "headerShow";
    static final String HEADER_STACK_INDEX = "headerStackIndex";
    private static final String IS_PAGE_ROW = "isPageRow";
    private static final String LB_HEADERS_BACKSTACK = "lbHeadersBackStack_";
    static final String TAG = "BrowseSupportFragment";
    final Event EVT_HEADER_VIEW_CREATED = new Event("headerFragmentViewCreated");
    final Event EVT_MAIN_FRAGMENT_VIEW_CREATED = new Event("mainFragmentViewCreated");
    final Event EVT_SCREEN_DATA_READY = new Event("screenDataReady");
    final State STATE_SET_ENTRANCE_START_STATE = new State("SET_ENTRANCE_START_STATE") {
        public void run() {
            BrowseSupportFragment.this.setEntranceTransitionStartState();
        }
    };
    private ObjectAdapter mAdapter;
    private PresenterSelector mAdapterPresenter;
    BackStackListener mBackStackChangedListener;
    private int mBrandColor = 0;
    private boolean mBrandColorSet;
    BrowseFrameLayout mBrowseFrame;
    BrowseTransitionListener mBrowseTransitionListener;
    boolean mCanShowHeaders = true;
    private int mContainerListAlignTop;
    private int mContainerListMarginStart;
    OnItemViewSelectedListener mExternalOnItemViewSelectedListener;
    private OnHeaderClickedListener mHeaderClickedListener = new OnHeaderClickedListener() {
        public void onHeaderClicked(ViewHolder viewHolder, Row row) {
            if (BrowseSupportFragment.this.mCanShowHeaders != null && BrowseSupportFragment.this.mShowingHeaders != null) {
                if (BrowseSupportFragment.this.isInHeadersTransition() == null) {
                    if (BrowseSupportFragment.this.mMainFragment == null) {
                        return;
                    }
                    if (BrowseSupportFragment.this.mMainFragment.getView() != null) {
                        BrowseSupportFragment.this.startHeadersTransitionInternal(null);
                        BrowseSupportFragment.this.mMainFragment.getView().requestFocus();
                    }
                }
            }
        }
    };
    private PresenterSelector mHeaderPresenterSelector;
    private OnHeaderViewSelectedListener mHeaderViewSelectedListener = new OnHeaderViewSelectedListener() {
        public void onHeaderSelected(ViewHolder viewHolder, Row row) {
            viewHolder = BrowseSupportFragment.this.mHeadersSupportFragment.getSelectedPosition();
            if (BrowseSupportFragment.this.mShowingHeaders != null) {
                BrowseSupportFragment.this.onRowSelected(viewHolder);
            }
        }
    };
    boolean mHeadersBackStackEnabled = true;
    private int mHeadersState = 1;
    HeadersSupportFragment mHeadersSupportFragment;
    Object mHeadersTransition;
    boolean mIsPageRow;
    Fragment mMainFragment;
    MainFragmentAdapter mMainFragmentAdapter;
    private MainFragmentAdapterRegistry mMainFragmentAdapterRegistry = new MainFragmentAdapterRegistry();
    ListRowDataAdapter mMainFragmentListRowDataAdapter;
    MainFragmentRowsAdapter mMainFragmentRowsAdapter;
    private boolean mMainFragmentScaleEnabled = true;
    private final OnChildFocusListener mOnChildFocusListener = new OnChildFocusListener() {
        public boolean onRequestFocusInDescendants(int i, Rect rect) {
            boolean z = true;
            if (BrowseSupportFragment.this.getChildFragmentManager().isDestroyed()) {
                return true;
            }
            if (BrowseSupportFragment.this.mCanShowHeaders && BrowseSupportFragment.this.mShowingHeaders && BrowseSupportFragment.this.mHeadersSupportFragment != null && BrowseSupportFragment.this.mHeadersSupportFragment.getView() != null && BrowseSupportFragment.this.mHeadersSupportFragment.getView().requestFocus(i, rect)) {
                return true;
            }
            if (BrowseSupportFragment.this.mMainFragment != null && BrowseSupportFragment.this.mMainFragment.getView() != null && BrowseSupportFragment.this.mMainFragment.getView().requestFocus(i, rect)) {
                return true;
            }
            if (BrowseSupportFragment.this.getTitleView() == null || BrowseSupportFragment.this.getTitleView().requestFocus(i, rect) == 0) {
                z = false;
            }
            return z;
        }

        public void onRequestChildFocus(View view, View view2) {
            if (BrowseSupportFragment.this.getChildFragmentManager().isDestroyed() == null && BrowseSupportFragment.this.mCanShowHeaders != null) {
                if (BrowseSupportFragment.this.isInHeadersTransition() == null) {
                    view = view.getId();
                    if (view == R.id.browse_container_dock && BrowseSupportFragment.this.mShowingHeaders != null) {
                        BrowseSupportFragment.this.startHeadersTransitionInternal(null);
                    } else if (view == R.id.browse_headers_dock && BrowseSupportFragment.this.mShowingHeaders == null) {
                        BrowseSupportFragment.this.startHeadersTransitionInternal(true);
                    }
                }
            }
        }
    };
    private final OnFocusSearchListener mOnFocusSearchListener = new OnFocusSearchListener() {
        public View onFocusSearch(View view, int i) {
            if (BrowseSupportFragment.this.mCanShowHeaders && BrowseSupportFragment.this.isInHeadersTransition()) {
                return view;
            }
            if (BrowseSupportFragment.this.getTitleView() != null && view != BrowseSupportFragment.this.getTitleView() && i == 33) {
                return BrowseSupportFragment.this.getTitleView();
            }
            if (BrowseSupportFragment.this.getTitleView() != null && BrowseSupportFragment.this.getTitleView().hasFocus() && i == TsExtractor.TS_STREAM_TYPE_HDMV_DTS) {
                view = (BrowseSupportFragment.this.mCanShowHeaders == null || BrowseSupportFragment.this.mShowingHeaders == null) ? BrowseSupportFragment.this.mMainFragment.getView() : BrowseSupportFragment.this.mHeadersSupportFragment.getVerticalGridView();
                return view;
            }
            Object obj = 1;
            if (ViewCompat.getLayoutDirection(view) != 1) {
                obj = null;
            }
            int i2 = 66;
            int i3 = obj != null ? 66 : 17;
            if (obj != null) {
                i2 = 17;
            }
            if (BrowseSupportFragment.this.mCanShowHeaders && i == i3) {
                if (BrowseSupportFragment.this.isVerticalScrolling() == 0 && BrowseSupportFragment.this.mShowingHeaders == 0) {
                    if (BrowseSupportFragment.this.isHeadersDataReady() != 0) {
                        view = BrowseSupportFragment.this.mHeadersSupportFragment.getVerticalGridView();
                    }
                }
                return view;
            } else if (i != i2) {
                return (i != TsExtractor.TS_STREAM_TYPE_HDMV_DTS || BrowseSupportFragment.this.mShowingHeaders == 0) ? null : view;
            } else {
                if (BrowseSupportFragment.this.isVerticalScrolling() != 0) {
                    return view;
                }
                if (!(BrowseSupportFragment.this.mMainFragment == 0 || BrowseSupportFragment.this.mMainFragment.getView() == 0)) {
                    view = BrowseSupportFragment.this.mMainFragment.getView();
                }
                return view;
            }
        }
    };
    private OnItemViewClickedListener mOnItemViewClickedListener;
    Object mPageRow;
    private float mScaleFactor;
    private ScaleFrameLayout mScaleFrameLayout;
    private Object mSceneAfterEntranceTransition;
    Object mSceneWithHeaders;
    Object mSceneWithoutHeaders;
    private int mSelectedPosition = -1;
    private final SetSelectionRunnable mSetSelectionRunnable = new SetSelectionRunnable();
    boolean mShowingHeaders = true;
    boolean mStopped = true;
    private final OnScrollListener mWaitScrollFinishAndCommitMainFragment = new OnScrollListener() {
        public void onScrollStateChanged(RecyclerView recyclerView, int i) {
            if (i == 0) {
                recyclerView.removeOnScrollListener(this);
                if (BrowseSupportFragment.this.mStopped == null) {
                    BrowseSupportFragment.this.commitMainFragment();
                }
            }
        }
    };
    String mWithHeadersBackStackName;

    public static class BrowseTransitionListener {
        public void onHeadersTransitionStart(boolean z) {
        }

        public void onHeadersTransitionStop(boolean z) {
        }
    }

    private class ExpandPreLayout implements OnPreDrawListener {
        static final int STATE_FIRST_DRAW = 1;
        static final int STATE_INIT = 0;
        static final int STATE_SECOND_DRAW = 2;
        private final Runnable mCallback;
        private int mState;
        private final View mView;
        private MainFragmentAdapter mainFragmentAdapter;

        ExpandPreLayout(Runnable runnable, MainFragmentAdapter mainFragmentAdapter, View view) {
            this.mView = view;
            this.mCallback = runnable;
            this.mainFragmentAdapter = mainFragmentAdapter;
        }

        void execute() {
            this.mView.getViewTreeObserver().addOnPreDrawListener(this);
            this.mainFragmentAdapter.setExpand(false);
            this.mView.invalidate();
            this.mState = 0;
        }

        public boolean onPreDraw() {
            if (BrowseSupportFragment.this.getView() != null) {
                if (BrowseSupportFragment.this.getContext() != null) {
                    int i = this.mState;
                    if (i == 0) {
                        this.mainFragmentAdapter.setExpand(true);
                        this.mView.invalidate();
                        this.mState = 1;
                    } else if (i == 1) {
                        this.mCallback.run();
                        this.mView.getViewTreeObserver().removeOnPreDrawListener(this);
                        this.mState = 2;
                    }
                    return false;
                }
            }
            this.mView.getViewTreeObserver().removeOnPreDrawListener(this);
            return true;
        }
    }

    public static abstract class FragmentFactory<T extends Fragment> {
        public abstract T createFragment(Object obj);
    }

    public interface FragmentHost {
        void notifyDataReady(MainFragmentAdapter mainFragmentAdapter);

        void notifyViewCreated(MainFragmentAdapter mainFragmentAdapter);

        void showTitleView(boolean z);
    }

    public static class MainFragmentAdapter<T extends Fragment> {
        private final T mFragment;
        FragmentHostImpl mFragmentHost;
        private boolean mScalingEnabled;

        public boolean isScrolling() {
            return false;
        }

        public void onTransitionEnd() {
        }

        public boolean onTransitionPrepare() {
            return false;
        }

        public void onTransitionStart() {
        }

        public void setAlignment(int i) {
        }

        public void setEntranceTransitionState(boolean z) {
        }

        public void setExpand(boolean z) {
        }

        public MainFragmentAdapter(T t) {
            this.mFragment = t;
        }

        public final T getFragment() {
            return this.mFragment;
        }

        public boolean isScalingEnabled() {
            return this.mScalingEnabled;
        }

        public void setScalingEnabled(boolean z) {
            this.mScalingEnabled = z;
        }

        public final FragmentHost getFragmentHost() {
            return this.mFragmentHost;
        }

        void setFragmentHost(FragmentHostImpl fragmentHostImpl) {
            this.mFragmentHost = fragmentHostImpl;
        }
    }

    public interface MainFragmentAdapterProvider {
        MainFragmentAdapter getMainFragmentAdapter();
    }

    public static final class MainFragmentAdapterRegistry {
        private static final FragmentFactory sDefaultFragmentFactory = new ListRowFragmentFactory();
        private final Map<Class, FragmentFactory> mItemToFragmentFactoryMapping = new HashMap();

        public MainFragmentAdapterRegistry() {
            registerFragment(ListRow.class, sDefaultFragmentFactory);
        }

        public void registerFragment(Class cls, FragmentFactory fragmentFactory) {
            this.mItemToFragmentFactoryMapping.put(cls, fragmentFactory);
        }

        public Fragment createFragment(Object obj) {
            FragmentFactory fragmentFactory;
            if (obj == null) {
                fragmentFactory = sDefaultFragmentFactory;
            } else {
                fragmentFactory = (FragmentFactory) this.mItemToFragmentFactoryMapping.get(obj.getClass());
            }
            if (fragmentFactory == null && !(obj instanceof PageRow)) {
                fragmentFactory = sDefaultFragmentFactory;
            }
            return fragmentFactory.createFragment(obj);
        }
    }

    public static class MainFragmentRowsAdapter<T extends Fragment> {
        private final T mFragment;

        public RowPresenter.ViewHolder findRowViewHolderByPosition(int i) {
            return null;
        }

        public int getSelectedPosition() {
            return 0;
        }

        public void setAdapter(ObjectAdapter objectAdapter) {
        }

        public void setOnItemViewClickedListener(OnItemViewClickedListener onItemViewClickedListener) {
        }

        public void setOnItemViewSelectedListener(OnItemViewSelectedListener onItemViewSelectedListener) {
        }

        public void setSelectedPosition(int i, boolean z) {
        }

        public void setSelectedPosition(int i, boolean z, ViewHolderTask viewHolderTask) {
        }

        public MainFragmentRowsAdapter(T t) {
            if (t != null) {
                this.mFragment = t;
                return;
            }
            throw new IllegalArgumentException("Fragment can't be null");
        }

        public final T getFragment() {
            return this.mFragment;
        }
    }

    public interface MainFragmentRowsAdapterProvider {
        MainFragmentRowsAdapter getMainFragmentRowsAdapter();
    }

    private final class SetSelectionRunnable implements Runnable {
        static final int TYPE_INTERNAL_SYNC = 0;
        static final int TYPE_INVALID = -1;
        static final int TYPE_USER_REQUEST = 1;
        private int mPosition;
        private boolean mSmooth;
        private int mType;

        SetSelectionRunnable() {
            reset();
        }

        void post(int i, int i2, boolean z) {
            if (i2 >= this.mType) {
                this.mPosition = i;
                this.mType = i2;
                this.mSmooth = z;
                BrowseSupportFragment.this.mBrowseFrame.removeCallbacks(this);
                if (BrowseSupportFragment.this.mStopped == 0) {
                    BrowseSupportFragment.this.mBrowseFrame.post(this);
                }
            }
        }

        public void run() {
            BrowseSupportFragment.this.setSelection(this.mPosition, this.mSmooth);
            reset();
        }

        public void stop() {
            BrowseSupportFragment.this.mBrowseFrame.removeCallbacks(this);
        }

        public void start() {
            if (this.mType != -1) {
                BrowseSupportFragment.this.mBrowseFrame.post(this);
            }
        }

        private void reset() {
            this.mPosition = -1;
            this.mType = -1;
            this.mSmooth = false;
        }
    }

    final class BackStackListener implements OnBackStackChangedListener {
        int mIndexOfHeadersBackStack = -1;
        int mLastEntryCount;

        BackStackListener() {
            this.mLastEntryCount = BrowseSupportFragment.this.getFragmentManager().getBackStackEntryCount();
        }

        void load(Bundle bundle) {
            if (bundle != null) {
                this.mIndexOfHeadersBackStack = bundle.getInt(BrowseSupportFragment.HEADER_STACK_INDEX, -1);
                BrowseSupportFragment.this.mShowingHeaders = this.mIndexOfHeadersBackStack == -1;
            } else if (BrowseSupportFragment.this.mShowingHeaders == null) {
                BrowseSupportFragment.this.getFragmentManager().beginTransaction().addToBackStack(BrowseSupportFragment.this.mWithHeadersBackStackName).commit();
            }
        }

        void save(Bundle bundle) {
            bundle.putInt(BrowseSupportFragment.HEADER_STACK_INDEX, this.mIndexOfHeadersBackStack);
        }

        public void onBackStackChanged() {
            if (BrowseSupportFragment.this.getFragmentManager() == null) {
                Log.w(BrowseSupportFragment.TAG, "getFragmentManager() is null, stack:", new Exception());
                return;
            }
            int backStackEntryCount = BrowseSupportFragment.this.getFragmentManager().getBackStackEntryCount();
            int i = this.mLastEntryCount;
            if (backStackEntryCount > i) {
                int i2 = backStackEntryCount - 1;
                if (BrowseSupportFragment.this.mWithHeadersBackStackName.equals(BrowseSupportFragment.this.getFragmentManager().getBackStackEntryAt(i2).getName())) {
                    this.mIndexOfHeadersBackStack = i2;
                }
            } else if (backStackEntryCount < i && this.mIndexOfHeadersBackStack >= backStackEntryCount) {
                if (BrowseSupportFragment.this.isHeadersDataReady()) {
                    this.mIndexOfHeadersBackStack = -1;
                    if (!BrowseSupportFragment.this.mShowingHeaders) {
                        BrowseSupportFragment.this.startHeadersTransitionInternal(true);
                    }
                } else {
                    BrowseSupportFragment.this.getFragmentManager().beginTransaction().addToBackStack(BrowseSupportFragment.this.mWithHeadersBackStackName).commit();
                    return;
                }
            }
            this.mLastEntryCount = backStackEntryCount;
        }
    }

    private final class FragmentHostImpl implements FragmentHost {
        boolean mShowTitleView = true;

        FragmentHostImpl() {
        }

        public void notifyViewCreated(MainFragmentAdapter mainFragmentAdapter) {
            BrowseSupportFragment.this.mStateMachine.fireEvent(BrowseSupportFragment.this.EVT_MAIN_FRAGMENT_VIEW_CREATED);
            if (BrowseSupportFragment.this.mIsPageRow == null) {
                BrowseSupportFragment.this.mStateMachine.fireEvent(BrowseSupportFragment.this.EVT_SCREEN_DATA_READY);
            }
        }

        public void notifyDataReady(MainFragmentAdapter mainFragmentAdapter) {
            if (BrowseSupportFragment.this.mMainFragmentAdapter != null) {
                if (BrowseSupportFragment.this.mMainFragmentAdapter.getFragmentHost() == this) {
                    if (BrowseSupportFragment.this.mIsPageRow != null) {
                        BrowseSupportFragment.this.mStateMachine.fireEvent(BrowseSupportFragment.this.EVT_SCREEN_DATA_READY);
                    }
                }
            }
        }

        public void showTitleView(boolean z) {
            this.mShowTitleView = z;
            if (BrowseSupportFragment.this.mMainFragmentAdapter) {
                if (BrowseSupportFragment.this.mMainFragmentAdapter.getFragmentHost() == this) {
                    if (BrowseSupportFragment.this.mIsPageRow) {
                        BrowseSupportFragment.this.updateTitleViewVisibility();
                    }
                }
            }
        }
    }

    public static class ListRowFragmentFactory extends FragmentFactory<RowsSupportFragment> {
        public RowsSupportFragment createFragment(Object obj) {
            return new RowsSupportFragment();
        }
    }

    class MainFragmentItemViewSelectedListener implements OnItemViewSelectedListener {
        MainFragmentRowsAdapter mMainFragmentRowsAdapter;

        public MainFragmentItemViewSelectedListener(MainFragmentRowsAdapter mainFragmentRowsAdapter) {
            this.mMainFragmentRowsAdapter = mainFragmentRowsAdapter;
        }

        public void onItemSelected(Presenter.ViewHolder viewHolder, Object obj, RowPresenter.ViewHolder viewHolder2, Row row) {
            BrowseSupportFragment.this.onRowSelected(this.mMainFragmentRowsAdapter.getSelectedPosition());
            if (BrowseSupportFragment.this.mExternalOnItemViewSelectedListener != null) {
                BrowseSupportFragment.this.mExternalOnItemViewSelectedListener.onItemSelected(viewHolder, obj, viewHolder2, row);
            }
        }
    }

    void createStateMachineStates() {
        super.createStateMachineStates();
        this.mStateMachine.addState(this.STATE_SET_ENTRANCE_START_STATE);
    }

    void createStateMachineTransitions() {
        super.createStateMachineTransitions();
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_PREPARED, this.STATE_SET_ENTRANCE_START_STATE, this.EVT_HEADER_VIEW_CREATED);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_PREPARED, this.STATE_ENTRANCE_ON_PREPARED_ON_CREATEVIEW, this.EVT_MAIN_FRAGMENT_VIEW_CREATED);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_PREPARED, this.STATE_ENTRANCE_PERFORM, this.EVT_SCREEN_DATA_READY);
    }

    private boolean createMainFragment(ObjectAdapter objectAdapter, int i) {
        Object obj = null;
        boolean z = true;
        if (this.mCanShowHeaders) {
            if (objectAdapter != null) {
                if (objectAdapter.size() != 0) {
                    if (i < 0) {
                        i = 0;
                    } else if (i >= objectAdapter.size()) {
                        throw new IllegalArgumentException(String.format("Invalid position %d requested", new Object[]{Integer.valueOf(i)}));
                    }
                    objectAdapter = objectAdapter.get(i);
                }
            }
            return false;
        }
        objectAdapter = null;
        i = this.mIsPageRow;
        Object obj2 = this.mPageRow;
        boolean z2 = this.mCanShowHeaders && (objectAdapter instanceof PageRow);
        this.mIsPageRow = z2;
        if (this.mIsPageRow) {
            obj = objectAdapter;
        }
        this.mPageRow = obj;
        if (this.mMainFragment != null) {
            if (i == 0) {
                z = this.mIsPageRow;
            } else if (this.mIsPageRow != 0) {
                if (obj2 == null || obj2 == this.mPageRow) {
                    z = false;
                }
            }
        }
        if (z) {
            this.mMainFragment = this.mMainFragmentAdapterRegistry.createFragment(objectAdapter);
            if ((this.mMainFragment instanceof MainFragmentAdapterProvider) != null) {
                setMainFragmentAdapter();
            } else {
                throw new IllegalArgumentException("Fragment must implement MainFragmentAdapterProvider");
            }
        }
        return z;
    }

    void setMainFragmentAdapter() {
        this.mMainFragmentAdapter = ((MainFragmentAdapterProvider) this.mMainFragment).getMainFragmentAdapter();
        this.mMainFragmentAdapter.setFragmentHost(new FragmentHostImpl());
        if (this.mIsPageRow) {
            setMainFragmentRowsAdapter(null);
            return;
        }
        Fragment fragment = this.mMainFragment;
        if (fragment instanceof MainFragmentRowsAdapterProvider) {
            setMainFragmentRowsAdapter(((MainFragmentRowsAdapterProvider) fragment).getMainFragmentRowsAdapter());
        } else {
            setMainFragmentRowsAdapter(null);
        }
        this.mIsPageRow = this.mMainFragmentRowsAdapter == null;
    }

    static {
        Class cls = BrowseSupportFragment.class;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(cls.getCanonicalName());
        stringBuilder.append(".title");
        ARG_TITLE = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(cls.getCanonicalName());
        stringBuilder.append(".headersState");
        ARG_HEADERS_STATE = stringBuilder.toString();
    }

    public static Bundle createArgs(Bundle bundle, String str, int i) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putString(ARG_TITLE, str);
        bundle.putInt(ARG_HEADERS_STATE, i);
        return bundle;
    }

    public void setBrandColor(int i) {
        this.mBrandColor = i;
        this.mBrandColorSet = true;
        i = this.mHeadersSupportFragment;
        if (i != 0) {
            i.setBackgroundColor(this.mBrandColor);
        }
    }

    public int getBrandColor() {
        return this.mBrandColor;
    }

    private void updateWrapperPresenter() {
        ObjectAdapter objectAdapter = this.mAdapter;
        if (objectAdapter == null) {
            this.mAdapterPresenter = null;
            return;
        }
        final PresenterSelector presenterSelector = objectAdapter.getPresenterSelector();
        if (presenterSelector == null) {
            throw new IllegalArgumentException("Adapter.getPresenterSelector() is null");
        } else if (presenterSelector != this.mAdapterPresenter) {
            this.mAdapterPresenter = presenterSelector;
            Object presenters = presenterSelector.getPresenters();
            final Presenter invisibleRowPresenter = new InvisibleRowPresenter();
            final Object obj = new Presenter[(presenters.length + 1)];
            System.arraycopy(obj, 0, presenters, 0, presenters.length);
            obj[obj.length - 1] = invisibleRowPresenter;
            this.mAdapter.setPresenterSelector(new PresenterSelector() {
                public Presenter getPresenter(Object obj) {
                    if (((Row) obj).isRenderedAsRowView()) {
                        return presenterSelector.getPresenter(obj);
                    }
                    return invisibleRowPresenter;
                }

                public Presenter[] getPresenters() {
                    return obj;
                }
            });
        }
    }

    public void setAdapter(ObjectAdapter objectAdapter) {
        this.mAdapter = objectAdapter;
        updateWrapperPresenter();
        if (getView() != null) {
            updateMainFragmentRowsAdapter();
            this.mHeadersSupportFragment.setAdapter(this.mAdapter);
        }
    }

    void setMainFragmentRowsAdapter(MainFragmentRowsAdapter mainFragmentRowsAdapter) {
        MainFragmentRowsAdapter mainFragmentRowsAdapter2 = this.mMainFragmentRowsAdapter;
        if (mainFragmentRowsAdapter != mainFragmentRowsAdapter2) {
            if (mainFragmentRowsAdapter2 != null) {
                mainFragmentRowsAdapter2.setAdapter(null);
            }
            this.mMainFragmentRowsAdapter = mainFragmentRowsAdapter;
            mainFragmentRowsAdapter = this.mMainFragmentRowsAdapter;
            if (mainFragmentRowsAdapter != null) {
                mainFragmentRowsAdapter.setOnItemViewSelectedListener(new MainFragmentItemViewSelectedListener(mainFragmentRowsAdapter));
                this.mMainFragmentRowsAdapter.setOnItemViewClickedListener(this.mOnItemViewClickedListener);
            }
            updateMainFragmentRowsAdapter();
        }
    }

    void updateMainFragmentRowsAdapter() {
        ListRowDataAdapter listRowDataAdapter = this.mMainFragmentListRowDataAdapter;
        ListRowDataAdapter listRowDataAdapter2 = null;
        if (listRowDataAdapter != null) {
            listRowDataAdapter.detach();
            this.mMainFragmentListRowDataAdapter = null;
        }
        if (this.mMainFragmentRowsAdapter != null) {
            ObjectAdapter objectAdapter = this.mAdapter;
            if (objectAdapter != null) {
                listRowDataAdapter2 = new ListRowDataAdapter(objectAdapter);
            }
            this.mMainFragmentListRowDataAdapter = listRowDataAdapter2;
            this.mMainFragmentRowsAdapter.setAdapter(this.mMainFragmentListRowDataAdapter);
        }
    }

    public final MainFragmentAdapterRegistry getMainFragmentRegistry() {
        return this.mMainFragmentAdapterRegistry;
    }

    public ObjectAdapter getAdapter() {
        return this.mAdapter;
    }

    public void setOnItemViewSelectedListener(OnItemViewSelectedListener onItemViewSelectedListener) {
        this.mExternalOnItemViewSelectedListener = onItemViewSelectedListener;
    }

    public OnItemViewSelectedListener getOnItemViewSelectedListener() {
        return this.mExternalOnItemViewSelectedListener;
    }

    public RowsSupportFragment getRowsSupportFragment() {
        Fragment fragment = this.mMainFragment;
        return fragment instanceof RowsSupportFragment ? (RowsSupportFragment) fragment : null;
    }

    public Fragment getMainFragment() {
        return this.mMainFragment;
    }

    public HeadersSupportFragment getHeadersSupportFragment() {
        return this.mHeadersSupportFragment;
    }

    public void setOnItemViewClickedListener(OnItemViewClickedListener onItemViewClickedListener) {
        this.mOnItemViewClickedListener = onItemViewClickedListener;
        MainFragmentRowsAdapter mainFragmentRowsAdapter = this.mMainFragmentRowsAdapter;
        if (mainFragmentRowsAdapter != null) {
            mainFragmentRowsAdapter.setOnItemViewClickedListener(onItemViewClickedListener);
        }
    }

    public OnItemViewClickedListener getOnItemViewClickedListener() {
        return this.mOnItemViewClickedListener;
    }

    public void startHeadersTransition(boolean z) {
        if (!this.mCanShowHeaders) {
            throw new IllegalStateException("Cannot start headers transition");
        } else if (!isInHeadersTransition()) {
            if (this.mShowingHeaders != z) {
                startHeadersTransitionInternal(z);
            }
        }
    }

    public boolean isInHeadersTransition() {
        return this.mHeadersTransition != null;
    }

    public boolean isShowingHeaders() {
        return this.mShowingHeaders;
    }

    public void setBrowseTransitionListener(BrowseTransitionListener browseTransitionListener) {
        this.mBrowseTransitionListener = browseTransitionListener;
    }

    @Deprecated
    public void enableRowScaling(boolean z) {
        enableMainFragmentScaling(z);
    }

    public void enableMainFragmentScaling(boolean z) {
        this.mMainFragmentScaleEnabled = z;
    }

    void startHeadersTransitionInternal(final boolean z) {
        if (!getFragmentManager().isDestroyed() && isHeadersDataReady()) {
            this.mShowingHeaders = z;
            this.mMainFragmentAdapter.onTransitionPrepare();
            this.mMainFragmentAdapter.onTransitionStart();
            onExpandTransitionStart(z ^ 1, new Runnable() {
                public void run() {
                    BrowseSupportFragment.this.mHeadersSupportFragment.onTransitionPrepare();
                    BrowseSupportFragment.this.mHeadersSupportFragment.onTransitionStart();
                    BrowseSupportFragment.this.createHeadersTransition();
                    if (BrowseSupportFragment.this.mBrowseTransitionListener != null) {
                        BrowseSupportFragment.this.mBrowseTransitionListener.onHeadersTransitionStart(z);
                    }
                    TransitionHelper.runTransition(z ? BrowseSupportFragment.this.mSceneWithHeaders : BrowseSupportFragment.this.mSceneWithoutHeaders, BrowseSupportFragment.this.mHeadersTransition);
                    if (!BrowseSupportFragment.this.mHeadersBackStackEnabled) {
                        return;
                    }
                    if (z) {
                        int i = BrowseSupportFragment.this.mBackStackChangedListener.mIndexOfHeadersBackStack;
                        if (i >= 0) {
                            BrowseSupportFragment.this.getFragmentManager().popBackStackImmediate(BrowseSupportFragment.this.getFragmentManager().getBackStackEntryAt(i).getId(), 1);
                            return;
                        }
                        return;
                    }
                    BrowseSupportFragment.this.getFragmentManager().beginTransaction().addToBackStack(BrowseSupportFragment.this.mWithHeadersBackStackName).commit();
                }
            });
        }
    }

    boolean isVerticalScrolling() {
        if (!this.mHeadersSupportFragment.isScrolling()) {
            if (!this.mMainFragmentAdapter.isScrolling()) {
                return false;
            }
        }
        return true;
    }

    final boolean isHeadersDataReady() {
        ObjectAdapter objectAdapter = this.mAdapter;
        return (objectAdapter == null || objectAdapter.size() == 0) ? false : true;
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(CURRENT_SELECTED_POSITION, this.mSelectedPosition);
        bundle.putBoolean(IS_PAGE_ROW, this.mIsPageRow);
        BackStackListener backStackListener = this.mBackStackChangedListener;
        if (backStackListener != null) {
            backStackListener.save(bundle);
            return;
        }
        bundle.putBoolean(HEADER_SHOW, this.mShowingHeaders);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Context context = getContext();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(R.styleable.LeanbackTheme);
        this.mContainerListMarginStart = (int) obtainStyledAttributes.getDimension(R.styleable.LeanbackTheme_browseRowsMarginStart, (float) context.getResources().getDimensionPixelSize(R.dimen.lb_browse_rows_margin_start));
        this.mContainerListAlignTop = (int) obtainStyledAttributes.getDimension(R.styleable.LeanbackTheme_browseRowsMarginTop, (float) context.getResources().getDimensionPixelSize(R.dimen.lb_browse_rows_margin_top));
        obtainStyledAttributes.recycle();
        readArguments(getArguments());
        if (this.mCanShowHeaders) {
            if (this.mHeadersBackStackEnabled) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(LB_HEADERS_BACKSTACK);
                stringBuilder.append(this);
                this.mWithHeadersBackStackName = stringBuilder.toString();
                this.mBackStackChangedListener = new BackStackListener();
                getFragmentManager().addOnBackStackChangedListener(this.mBackStackChangedListener);
                this.mBackStackChangedListener.load(bundle);
            } else if (bundle != null) {
                this.mShowingHeaders = bundle.getBoolean(HEADER_SHOW);
            }
        }
        this.mScaleFactor = getResources().getFraction(R.fraction.lb_browse_rows_scale, 1, 1);
    }

    public void onDestroyView() {
        setMainFragmentRowsAdapter(null);
        this.mPageRow = null;
        this.mMainFragmentAdapter = null;
        this.mMainFragment = null;
        this.mHeadersSupportFragment = null;
        super.onDestroyView();
    }

    public void onDestroy() {
        if (this.mBackStackChangedListener != null) {
            getFragmentManager().removeOnBackStackChangedListener(this.mBackStackChangedListener);
        }
        super.onDestroy();
    }

    public HeadersSupportFragment onCreateHeadersSupportFragment() {
        return new HeadersSupportFragment();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (getChildFragmentManager().findFragmentById(R.id.scale_frame) == null) {
            this.mHeadersSupportFragment = onCreateHeadersSupportFragment();
            createMainFragment(this.mAdapter, this.mSelectedPosition);
            FragmentTransaction replace = getChildFragmentManager().beginTransaction().replace(R.id.browse_headers_dock, this.mHeadersSupportFragment);
            if (this.mMainFragment != null) {
                replace.replace(R.id.scale_frame, this.mMainFragment);
            } else {
                this.mMainFragmentAdapter = new MainFragmentAdapter(null);
                this.mMainFragmentAdapter.setFragmentHost(new FragmentHostImpl());
            }
            replace.commit();
        } else {
            this.mHeadersSupportFragment = (HeadersSupportFragment) getChildFragmentManager().findFragmentById(R.id.browse_headers_dock);
            this.mMainFragment = getChildFragmentManager().findFragmentById(R.id.scale_frame);
            boolean z = bundle != null && bundle.getBoolean(IS_PAGE_ROW, false);
            this.mIsPageRow = z;
            this.mSelectedPosition = bundle != null ? bundle.getInt(CURRENT_SELECTED_POSITION, 0) : 0;
            setMainFragmentAdapter();
        }
        this.mHeadersSupportFragment.setHeadersGone(true ^ this.mCanShowHeaders);
        PresenterSelector presenterSelector = this.mHeaderPresenterSelector;
        if (presenterSelector != null) {
            this.mHeadersSupportFragment.setPresenterSelector(presenterSelector);
        }
        this.mHeadersSupportFragment.setAdapter(this.mAdapter);
        this.mHeadersSupportFragment.setOnHeaderViewSelectedListener(this.mHeaderViewSelectedListener);
        this.mHeadersSupportFragment.setOnHeaderClickedListener(this.mHeaderClickedListener);
        viewGroup = layoutInflater.inflate(R.layout.lb_browse_fragment, viewGroup, false);
        getProgressBarManager().setRootView(viewGroup);
        this.mBrowseFrame = (BrowseFrameLayout) viewGroup.findViewById(R.id.browse_frame);
        this.mBrowseFrame.setOnChildFocusListener(this.mOnChildFocusListener);
        this.mBrowseFrame.setOnFocusSearchListener(this.mOnFocusSearchListener);
        installTitleView(layoutInflater, this.mBrowseFrame, bundle);
        this.mScaleFrameLayout = (ScaleFrameLayout) viewGroup.findViewById(R.id.scale_frame);
        this.mScaleFrameLayout.setPivotX(null);
        this.mScaleFrameLayout.setPivotY((float) this.mContainerListAlignTop);
        if (this.mBrandColorSet != null) {
            this.mHeadersSupportFragment.setBackgroundColor(this.mBrandColor);
        }
        this.mSceneWithHeaders = TransitionHelper.createScene(this.mBrowseFrame, new Runnable() {
            public void run() {
                BrowseSupportFragment.this.showHeaders(true);
            }
        });
        this.mSceneWithoutHeaders = TransitionHelper.createScene(this.mBrowseFrame, new Runnable() {
            public void run() {
                BrowseSupportFragment.this.showHeaders(false);
            }
        });
        this.mSceneAfterEntranceTransition = TransitionHelper.createScene(this.mBrowseFrame, new Runnable() {
            public void run() {
                BrowseSupportFragment.this.setEntranceTransitionEndState();
            }
        });
        return viewGroup;
    }

    void createHeadersTransition() {
        this.mHeadersTransition = TransitionHelper.loadTransition(getContext(), this.mShowingHeaders ? R.transition.lb_browse_headers_in : R.transition.lb_browse_headers_out);
        TransitionHelper.addTransitionListener(this.mHeadersTransition, new TransitionListener() {
            public void onTransitionStart(Object obj) {
            }

            public void onTransitionEnd(Object obj) {
                obj = BrowseSupportFragment.this;
                obj.mHeadersTransition = null;
                if (obj.mMainFragmentAdapter != null) {
                    BrowseSupportFragment.this.mMainFragmentAdapter.onTransitionEnd();
                    if (BrowseSupportFragment.this.mShowingHeaders == null && BrowseSupportFragment.this.mMainFragment != null) {
                        obj = BrowseSupportFragment.this.mMainFragment.getView();
                        if (!(obj == null || obj.hasFocus())) {
                            obj.requestFocus();
                        }
                    }
                }
                if (BrowseSupportFragment.this.mHeadersSupportFragment != null) {
                    BrowseSupportFragment.this.mHeadersSupportFragment.onTransitionEnd();
                    if (BrowseSupportFragment.this.mShowingHeaders != null) {
                        obj = BrowseSupportFragment.this.mHeadersSupportFragment.getVerticalGridView();
                        if (!(obj == null || obj.hasFocus())) {
                            obj.requestFocus();
                        }
                    }
                }
                BrowseSupportFragment.this.updateTitleViewVisibility();
                if (BrowseSupportFragment.this.mBrowseTransitionListener != null) {
                    BrowseSupportFragment.this.mBrowseTransitionListener.onHeadersTransitionStop(BrowseSupportFragment.this.mShowingHeaders);
                }
            }
        });
    }

    void updateTitleViewVisibility() {
        MainFragmentAdapter mainFragmentAdapter;
        boolean z;
        if (this.mShowingHeaders) {
            boolean isFirstRowWithContentOrPageRow;
            int i;
            if (this.mIsPageRow) {
                mainFragmentAdapter = this.mMainFragmentAdapter;
                if (mainFragmentAdapter != null) {
                    z = mainFragmentAdapter.mFragmentHost.mShowTitleView;
                    isFirstRowWithContentOrPageRow = isFirstRowWithContentOrPageRow(this.mSelectedPosition);
                    i = z ? 2 : 0;
                    if (isFirstRowWithContentOrPageRow) {
                        i |= 4;
                    }
                    if (i == 0) {
                        showTitle(i);
                        return;
                    } else {
                        showTitle(false);
                        return;
                    }
                }
            }
            z = isFirstRowWithContent(this.mSelectedPosition);
            isFirstRowWithContentOrPageRow = isFirstRowWithContentOrPageRow(this.mSelectedPosition);
            if (z) {
            }
            if (isFirstRowWithContentOrPageRow) {
                i |= 4;
            }
            if (i == 0) {
                showTitle(false);
                return;
            } else {
                showTitle(i);
                return;
            }
        }
        if (this.mIsPageRow) {
            mainFragmentAdapter = this.mMainFragmentAdapter;
            if (mainFragmentAdapter != null) {
                z = mainFragmentAdapter.mFragmentHost.mShowTitleView;
                if (z) {
                    showTitle(false);
                } else {
                    showTitle(6);
                }
            }
        }
        z = isFirstRowWithContent(this.mSelectedPosition);
        if (z) {
            showTitle(false);
        } else {
            showTitle(6);
        }
    }

    boolean isFirstRowWithContentOrPageRow(int i) {
        ObjectAdapter objectAdapter = this.mAdapter;
        if (objectAdapter != null) {
            if (objectAdapter.size() != 0) {
                boolean z = false;
                int i2 = 0;
                while (i2 < this.mAdapter.size()) {
                    Row row = (Row) this.mAdapter.get(i2);
                    if (!row.isRenderedAsRowView()) {
                        if (!(row instanceof PageRow)) {
                            i2++;
                        }
                    }
                    if (i == i2) {
                        z = true;
                    }
                    return z;
                }
            }
        }
        return true;
    }

    boolean isFirstRowWithContent(int i) {
        ObjectAdapter objectAdapter = this.mAdapter;
        if (objectAdapter != null) {
            if (objectAdapter.size() != 0) {
                boolean z = false;
                for (int i2 = 0; i2 < this.mAdapter.size(); i2++) {
                    if (((Row) this.mAdapter.get(i2)).isRenderedAsRowView()) {
                        if (i == i2) {
                            z = true;
                        }
                        return z;
                    }
                }
            }
        }
        return true;
    }

    public void setHeaderPresenterSelector(PresenterSelector presenterSelector) {
        this.mHeaderPresenterSelector = presenterSelector;
        presenterSelector = this.mHeadersSupportFragment;
        if (presenterSelector != null) {
            presenterSelector.setPresenterSelector(this.mHeaderPresenterSelector);
        }
    }

    private void setHeadersOnScreen(boolean z) {
        View view = this.mHeadersSupportFragment.getView();
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) view.getLayoutParams();
        if (z) {
            z = false;
        } else {
            z = -this.mContainerListMarginStart;
        }
        marginLayoutParams.setMarginStart(z);
        view.setLayoutParams(marginLayoutParams);
    }

    void showHeaders(boolean z) {
        this.mHeadersSupportFragment.setHeadersEnabled(z);
        setHeadersOnScreen(z);
        expandMainFragment(z ^ 1);
    }

    private void expandMainFragment(boolean z) {
        MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.mScaleFrameLayout.getLayoutParams();
        marginLayoutParams.setMarginStart(!z ? this.mContainerListMarginStart : 0);
        this.mScaleFrameLayout.setLayoutParams(marginLayoutParams);
        this.mMainFragmentAdapter.setExpand(z);
        setMainFragmentAlignment();
        z = (!z && this.mMainFragmentScaleEnabled && this.mMainFragmentAdapter.isScalingEnabled()) ? this.mScaleFactor : true;
        this.mScaleFrameLayout.setLayoutScaleY(z);
        this.mScaleFrameLayout.setChildScale(z);
    }

    void onRowSelected(int i) {
        this.mSetSelectionRunnable.post(i, 0, true);
    }

    void setSelection(int i, boolean z) {
        if (i != -1) {
            this.mSelectedPosition = i;
            HeadersSupportFragment headersSupportFragment = this.mHeadersSupportFragment;
            if (headersSupportFragment != null) {
                if (this.mMainFragmentAdapter != null) {
                    headersSupportFragment.setSelectedPosition(i, z);
                    replaceMainFragment(i);
                    MainFragmentRowsAdapter mainFragmentRowsAdapter = this.mMainFragmentRowsAdapter;
                    if (mainFragmentRowsAdapter != null) {
                        mainFragmentRowsAdapter.setSelectedPosition(i, z);
                    }
                    updateTitleViewVisibility();
                }
            }
        }
    }

    private void replaceMainFragment(int i) {
        if (createMainFragment(this.mAdapter, i) != 0) {
            swapToMainFragment();
            if (this.mCanShowHeaders != 0) {
                if (this.mShowingHeaders != 0) {
                    i = 0;
                    expandMainFragment(i);
                }
            }
            i = 1;
            expandMainFragment(i);
        }
    }

    final void commitMainFragment() {
        FragmentManager childFragmentManager = getChildFragmentManager();
        if (childFragmentManager.findFragmentById(R.id.scale_frame) != this.mMainFragment) {
            childFragmentManager.beginTransaction().replace(R.id.scale_frame, this.mMainFragment).commit();
        }
    }

    private void swapToMainFragment() {
        if (!this.mStopped) {
            VerticalGridView verticalGridView = this.mHeadersSupportFragment.getVerticalGridView();
            if (!isShowingHeaders() || verticalGridView == null || verticalGridView.getScrollState() == 0) {
                commitMainFragment();
            } else {
                getChildFragmentManager().beginTransaction().replace(R.id.scale_frame, new Fragment()).commit();
                verticalGridView.removeOnScrollListener(this.mWaitScrollFinishAndCommitMainFragment);
                verticalGridView.addOnScrollListener(this.mWaitScrollFinishAndCommitMainFragment);
            }
        }
    }

    public void setSelectedPosition(int i) {
        setSelectedPosition(i, true);
    }

    public int getSelectedPosition() {
        return this.mSelectedPosition;
    }

    public RowPresenter.ViewHolder getSelectedRowViewHolder() {
        MainFragmentRowsAdapter mainFragmentRowsAdapter = this.mMainFragmentRowsAdapter;
        if (mainFragmentRowsAdapter == null) {
            return null;
        }
        return this.mMainFragmentRowsAdapter.findRowViewHolderByPosition(mainFragmentRowsAdapter.getSelectedPosition());
    }

    public void setSelectedPosition(int i, boolean z) {
        this.mSetSelectionRunnable.post(i, 1, z);
    }

    public void setSelectedPosition(int i, boolean z, ViewHolderTask viewHolderTask) {
        if (this.mMainFragmentAdapterRegistry != null) {
            if (viewHolderTask != null) {
                startHeadersTransition(false);
            }
            MainFragmentRowsAdapter mainFragmentRowsAdapter = this.mMainFragmentRowsAdapter;
            if (mainFragmentRowsAdapter != null) {
                mainFragmentRowsAdapter.setSelectedPosition(i, z, viewHolderTask);
            }
        }
    }

    public void onStart() {
        super.onStart();
        this.mHeadersSupportFragment.setAlignment(this.mContainerListAlignTop);
        setMainFragmentAlignment();
        if (this.mCanShowHeaders && this.mShowingHeaders) {
            HeadersSupportFragment headersSupportFragment = this.mHeadersSupportFragment;
            if (!(headersSupportFragment == null || headersSupportFragment.getView() == null)) {
                this.mHeadersSupportFragment.getView().requestFocus();
                if (this.mCanShowHeaders) {
                    showHeaders(this.mShowingHeaders);
                }
                this.mStateMachine.fireEvent(this.EVT_HEADER_VIEW_CREATED);
                this.mStopped = false;
                commitMainFragment();
                this.mSetSelectionRunnable.start();
            }
        }
        if (!(this.mCanShowHeaders && this.mShowingHeaders)) {
            Fragment fragment = this.mMainFragment;
            if (!(fragment == null || fragment.getView() == null)) {
                this.mMainFragment.getView().requestFocus();
            }
        }
        if (this.mCanShowHeaders) {
            showHeaders(this.mShowingHeaders);
        }
        this.mStateMachine.fireEvent(this.EVT_HEADER_VIEW_CREATED);
        this.mStopped = false;
        commitMainFragment();
        this.mSetSelectionRunnable.start();
    }

    public void onStop() {
        this.mStopped = true;
        this.mSetSelectionRunnable.stop();
        super.onStop();
    }

    private void onExpandTransitionStart(boolean z, Runnable runnable) {
        if (z) {
            runnable.run();
        } else {
            new ExpandPreLayout(runnable, this.mMainFragmentAdapter, getView()).execute();
        }
    }

    private void setMainFragmentAlignment() {
        int i = this.mContainerListAlignTop;
        if (this.mMainFragmentScaleEnabled && this.mMainFragmentAdapter.isScalingEnabled() && this.mShowingHeaders) {
            i = (int) ((((float) i) / this.mScaleFactor) + 0.5f);
        }
        this.mMainFragmentAdapter.setAlignment(i);
    }

    public final void setHeadersTransitionOnBackEnabled(boolean z) {
        this.mHeadersBackStackEnabled = z;
    }

    public final boolean isHeadersTransitionOnBackEnabled() {
        return this.mHeadersBackStackEnabled;
    }

    private void readArguments(Bundle bundle) {
        if (bundle != null) {
            if (bundle.containsKey(ARG_TITLE)) {
                setTitle(bundle.getString(ARG_TITLE));
            }
            if (bundle.containsKey(ARG_HEADERS_STATE)) {
                setHeadersState(bundle.getInt(ARG_HEADERS_STATE));
            }
        }
    }

    public void setHeadersState(int i) {
        StringBuilder stringBuilder;
        if (i < 1 || i > 3) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid headers state: ");
            stringBuilder.append(i);
            throw new IllegalArgumentException(stringBuilder.toString());
        } else if (i != this.mHeadersState) {
            this.mHeadersState = i;
            if (i == 1) {
                this.mCanShowHeaders = true;
                this.mShowingHeaders = true;
            } else if (i == 2) {
                this.mCanShowHeaders = true;
                this.mShowingHeaders = false;
            } else if (i != 3) {
                stringBuilder = new StringBuilder();
                stringBuilder.append("Unknown headers state: ");
                stringBuilder.append(i);
                Log.w(TAG, stringBuilder.toString());
            } else {
                this.mCanShowHeaders = false;
                this.mShowingHeaders = false;
            }
            i = this.mHeadersSupportFragment;
            if (i != 0) {
                i.setHeadersGone(true ^ this.mCanShowHeaders);
            }
        }
    }

    public int getHeadersState() {
        return this.mHeadersState;
    }

    protected Object createEntranceTransition() {
        return TransitionHelper.loadTransition(getContext(), R.transition.lb_browse_entrance_transition);
    }

    protected void runEntranceTransition(Object obj) {
        TransitionHelper.runTransition(this.mSceneAfterEntranceTransition, obj);
    }

    protected void onEntranceTransitionPrepare() {
        this.mHeadersSupportFragment.onTransitionPrepare();
        this.mMainFragmentAdapter.setEntranceTransitionState(false);
        this.mMainFragmentAdapter.onTransitionPrepare();
    }

    protected void onEntranceTransitionStart() {
        this.mHeadersSupportFragment.onTransitionStart();
        this.mMainFragmentAdapter.onTransitionStart();
    }

    protected void onEntranceTransitionEnd() {
        MainFragmentAdapter mainFragmentAdapter = this.mMainFragmentAdapter;
        if (mainFragmentAdapter != null) {
            mainFragmentAdapter.onTransitionEnd();
        }
        HeadersSupportFragment headersSupportFragment = this.mHeadersSupportFragment;
        if (headersSupportFragment != null) {
            headersSupportFragment.onTransitionEnd();
        }
    }

    void setSearchOrbViewOnScreen(boolean z) {
        View searchAffordanceView = getTitleViewAdapter().getSearchAffordanceView();
        if (searchAffordanceView != null) {
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) searchAffordanceView.getLayoutParams();
            if (z) {
                z = false;
            } else {
                z = -this.mContainerListMarginStart;
            }
            marginLayoutParams.setMarginStart(z);
            searchAffordanceView.setLayoutParams(marginLayoutParams);
        }
    }

    void setEntranceTransitionStartState() {
        setHeadersOnScreen(false);
        setSearchOrbViewOnScreen(false);
    }

    void setEntranceTransitionEndState() {
        setHeadersOnScreen(this.mShowingHeaders);
        setSearchOrbViewOnScreen(true);
        this.mMainFragmentAdapter.setEntranceTransitionState(true);
    }
}
