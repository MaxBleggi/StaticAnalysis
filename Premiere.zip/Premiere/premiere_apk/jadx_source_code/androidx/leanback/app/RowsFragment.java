package androidx.leanback.app;

import android.animation.TimeAnimator;
import android.animation.TimeAnimator.TimeListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.leanback.R;
import androidx.leanback.app.BrowseFragment.MainFragmentAdapterProvider;
import androidx.leanback.app.BrowseFragment.MainFragmentRowsAdapterProvider;
import androidx.leanback.widget.BaseOnItemViewClickedListener;
import androidx.leanback.widget.BaseOnItemViewSelectedListener;
import androidx.leanback.widget.HorizontalGridView;
import androidx.leanback.widget.ItemBridgeAdapter;
import androidx.leanback.widget.ItemBridgeAdapter.AdapterListener;
import androidx.leanback.widget.ItemBridgeAdapter.ViewHolder;
import androidx.leanback.widget.ListRowPresenter;
import androidx.leanback.widget.ObjectAdapter;
import androidx.leanback.widget.OnItemViewClickedListener;
import androidx.leanback.widget.OnItemViewSelectedListener;
import androidx.leanback.widget.Presenter;
import androidx.leanback.widget.Presenter.ViewHolderTask;
import androidx.leanback.widget.RowPresenter;
import androidx.leanback.widget.VerticalGridView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.RecycledViewPool;
import java.util.ArrayList;

@Deprecated
public class RowsFragment extends BaseRowFragment implements MainFragmentRowsAdapterProvider, MainFragmentAdapterProvider {
    static final int ALIGN_TOP_NOT_SET = Integer.MIN_VALUE;
    static final boolean DEBUG = false;
    static final String TAG = "RowsFragment";
    boolean mAfterEntranceTransition = true;
    private int mAlignedTop = Integer.MIN_VALUE;
    private final AdapterListener mBridgeAdapterListener = new AdapterListener() {
        public void onAddPresenter(Presenter presenter, int i) {
            if (RowsFragment.this.mExternalAdapterListener != null) {
                RowsFragment.this.mExternalAdapterListener.onAddPresenter(presenter, i);
            }
        }

        public void onCreate(ViewHolder viewHolder) {
            VerticalGridView verticalGridView = RowsFragment.this.getVerticalGridView();
            if (verticalGridView != null) {
                verticalGridView.setClipChildren(false);
            }
            RowsFragment.this.setupSharedViewPool(viewHolder);
            RowsFragment rowsFragment = RowsFragment.this;
            rowsFragment.mViewsCreated = true;
            viewHolder.setExtraObject(new RowViewHolderExtra(viewHolder));
            RowsFragment.setRowViewSelected(viewHolder, false, true);
            if (RowsFragment.this.mExternalAdapterListener != null) {
                RowsFragment.this.mExternalAdapterListener.onCreate(viewHolder);
            }
            viewHolder = ((RowPresenter) viewHolder.getPresenter()).getRowViewHolder(viewHolder.getViewHolder());
            viewHolder.setOnItemViewSelectedListener(RowsFragment.this.mOnItemViewSelectedListener);
            viewHolder.setOnItemViewClickedListener(RowsFragment.this.mOnItemViewClickedListener);
        }

        public void onAttachedToWindow(ViewHolder viewHolder) {
            RowsFragment.setRowViewExpanded(viewHolder, RowsFragment.this.mExpand);
            RowPresenter rowPresenter = (RowPresenter) viewHolder.getPresenter();
            RowPresenter.ViewHolder rowViewHolder = rowPresenter.getRowViewHolder(viewHolder.getViewHolder());
            rowPresenter.setEntranceTransitionState(rowViewHolder, RowsFragment.this.mAfterEntranceTransition);
            rowPresenter.freeze(rowViewHolder, RowsFragment.this.mFreezeRows);
            if (RowsFragment.this.mExternalAdapterListener != null) {
                RowsFragment.this.mExternalAdapterListener.onAttachedToWindow(viewHolder);
            }
        }

        public void onDetachedFromWindow(ViewHolder viewHolder) {
            if (RowsFragment.this.mSelectedViewHolder == viewHolder) {
                RowsFragment.setRowViewSelected(RowsFragment.this.mSelectedViewHolder, false, true);
                RowsFragment.this.mSelectedViewHolder = null;
            }
            if (RowsFragment.this.mExternalAdapterListener != null) {
                RowsFragment.this.mExternalAdapterListener.onDetachedFromWindow(viewHolder);
            }
        }

        public void onBind(ViewHolder viewHolder) {
            if (RowsFragment.this.mExternalAdapterListener != null) {
                RowsFragment.this.mExternalAdapterListener.onBind(viewHolder);
            }
        }

        public void onUnbind(ViewHolder viewHolder) {
            RowsFragment.setRowViewSelected(viewHolder, false, true);
            if (RowsFragment.this.mExternalAdapterListener != null) {
                RowsFragment.this.mExternalAdapterListener.onUnbind(viewHolder);
            }
        }
    };
    boolean mExpand = true;
    AdapterListener mExternalAdapterListener;
    boolean mFreezeRows;
    private MainFragmentAdapter mMainFragmentAdapter;
    private MainFragmentRowsAdapter mMainFragmentRowsAdapter;
    BaseOnItemViewClickedListener mOnItemViewClickedListener;
    BaseOnItemViewSelectedListener mOnItemViewSelectedListener;
    private ArrayList<Presenter> mPresenterMapper;
    private RecycledViewPool mRecycledViewPool;
    int mSelectAnimatorDuration;
    Interpolator mSelectAnimatorInterpolator = new DecelerateInterpolator(2.0f);
    ViewHolder mSelectedViewHolder;
    private int mSubPosition;
    boolean mViewsCreated;

    final class RowViewHolderExtra implements TimeListener {
        final RowPresenter mRowPresenter;
        final Presenter.ViewHolder mRowViewHolder;
        final TimeAnimator mSelectAnimator = new TimeAnimator();
        int mSelectAnimatorDurationInUse;
        Interpolator mSelectAnimatorInterpolatorInUse;
        float mSelectLevelAnimDelta;
        float mSelectLevelAnimStart;

        RowViewHolderExtra(ViewHolder viewHolder) {
            this.mRowPresenter = (RowPresenter) viewHolder.getPresenter();
            this.mRowViewHolder = viewHolder.getViewHolder();
            this.mSelectAnimator.setTimeListener(this);
        }

        public void onTimeUpdate(TimeAnimator timeAnimator, long j, long j2) {
            if (this.mSelectAnimator.isRunning() != null) {
                updateSelect(j, j2);
            }
        }

        void updateSelect(long j, long j2) {
            j2 = this.mSelectAnimatorDurationInUse;
            if (j >= ((long) j2)) {
                j = 1065353216;
                this.mSelectAnimator.end();
            } else {
                j = (float) (((double) j) / ((double) j2));
            }
            Interpolator interpolator = this.mSelectAnimatorInterpolatorInUse;
            if (interpolator != null) {
                j = interpolator.getInterpolation(j);
            }
            this.mRowPresenter.setSelectLevel(this.mRowViewHolder, this.mSelectLevelAnimStart + (j * this.mSelectLevelAnimDelta));
        }

        void animateSelect(boolean z, boolean z2) {
            this.mSelectAnimator.end();
            z = z ? true : false;
            if (z2) {
                this.mRowPresenter.setSelectLevel(this.mRowViewHolder, z);
            } else if (this.mRowPresenter.getSelectLevel(this.mRowViewHolder) != z) {
                this.mSelectAnimatorDurationInUse = RowsFragment.this.mSelectAnimatorDuration;
                this.mSelectAnimatorInterpolatorInUse = RowsFragment.this.mSelectAnimatorInterpolator;
                this.mSelectLevelAnimStart = this.mRowPresenter.getSelectLevel(this.mRowViewHolder);
                this.mSelectLevelAnimDelta = z - this.mSelectLevelAnimStart;
                this.mSelectAnimator.start();
            }
        }
    }

    public static class MainFragmentAdapter extends androidx.leanback.app.BrowseFragment.MainFragmentAdapter<RowsFragment> {
        public MainFragmentAdapter(RowsFragment rowsFragment) {
            super(rowsFragment);
            setScalingEnabled(true);
        }

        public boolean isScrolling() {
            return ((RowsFragment) getFragment()).isScrolling();
        }

        public void setExpand(boolean z) {
            ((RowsFragment) getFragment()).setExpand(z);
        }

        public void setEntranceTransitionState(boolean z) {
            ((RowsFragment) getFragment()).setEntranceTransitionState(z);
        }

        public void setAlignment(int i) {
            ((RowsFragment) getFragment()).setAlignment(i);
        }

        public boolean onTransitionPrepare() {
            return ((RowsFragment) getFragment()).onTransitionPrepare();
        }

        public void onTransitionStart() {
            ((RowsFragment) getFragment()).onTransitionStart();
        }

        public void onTransitionEnd() {
            ((RowsFragment) getFragment()).onTransitionEnd();
        }
    }

    @Deprecated
    public static class MainFragmentRowsAdapter extends androidx.leanback.app.BrowseFragment.MainFragmentRowsAdapter<RowsFragment> {
        public MainFragmentRowsAdapter(RowsFragment rowsFragment) {
            super(rowsFragment);
        }

        public void setAdapter(ObjectAdapter objectAdapter) {
            ((RowsFragment) getFragment()).setAdapter(objectAdapter);
        }

        public void setOnItemViewClickedListener(OnItemViewClickedListener onItemViewClickedListener) {
            ((RowsFragment) getFragment()).setOnItemViewClickedListener(onItemViewClickedListener);
        }

        public void setOnItemViewSelectedListener(OnItemViewSelectedListener onItemViewSelectedListener) {
            ((RowsFragment) getFragment()).setOnItemViewSelectedListener(onItemViewSelectedListener);
        }

        public void setSelectedPosition(int i, boolean z, ViewHolderTask viewHolderTask) {
            ((RowsFragment) getFragment()).setSelectedPosition(i, z, viewHolderTask);
        }

        public void setSelectedPosition(int i, boolean z) {
            ((RowsFragment) getFragment()).setSelectedPosition(i, z);
        }

        public int getSelectedPosition() {
            return ((RowsFragment) getFragment()).getSelectedPosition();
        }

        public RowPresenter.ViewHolder findRowViewHolderByPosition(int i) {
            return ((RowsFragment) getFragment()).findRowViewHolderByPosition(i);
        }
    }

    @Deprecated
    public void enableRowScaling(boolean z) {
    }

    public /* bridge */ /* synthetic */ int getSelectedPosition() {
        return super.getSelectedPosition();
    }

    public /* bridge */ /* synthetic */ View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return super.onCreateView(layoutInflater, viewGroup, bundle);
    }

    public /* bridge */ /* synthetic */ void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
    }

    public /* bridge */ /* synthetic */ void onTransitionStart() {
        super.onTransitionStart();
    }

    public /* bridge */ /* synthetic */ void setSelectedPosition(int i) {
        super.setSelectedPosition(i);
    }

    public /* bridge */ /* synthetic */ void setSelectedPosition(int i, boolean z) {
        super.setSelectedPosition(i, z);
    }

    public androidx.leanback.app.BrowseFragment.MainFragmentAdapter getMainFragmentAdapter() {
        if (this.mMainFragmentAdapter == null) {
            this.mMainFragmentAdapter = new MainFragmentAdapter(this);
        }
        return this.mMainFragmentAdapter;
    }

    public androidx.leanback.app.BrowseFragment.MainFragmentRowsAdapter getMainFragmentRowsAdapter() {
        if (this.mMainFragmentRowsAdapter == null) {
            this.mMainFragmentRowsAdapter = new MainFragmentRowsAdapter(this);
        }
        return this.mMainFragmentRowsAdapter;
    }

    protected VerticalGridView findGridViewFromRoot(View view) {
        return (VerticalGridView) view.findViewById(R.id.container_list);
    }

    public void setOnItemViewClickedListener(BaseOnItemViewClickedListener baseOnItemViewClickedListener) {
        this.mOnItemViewClickedListener = baseOnItemViewClickedListener;
        if (this.mViewsCreated != null) {
            throw new IllegalStateException("Item clicked listener must be set before views are created");
        }
    }

    public BaseOnItemViewClickedListener getOnItemViewClickedListener() {
        return this.mOnItemViewClickedListener;
    }

    public void setExpand(boolean z) {
        this.mExpand = z;
        z = getVerticalGridView();
        if (z) {
            int childCount = z.getChildCount();
            for (int i = 0; i < childCount; i++) {
                setRowViewExpanded((ViewHolder) z.getChildViewHolder(z.getChildAt(i)), this.mExpand);
            }
        }
    }

    public void setOnItemViewSelectedListener(BaseOnItemViewSelectedListener baseOnItemViewSelectedListener) {
        this.mOnItemViewSelectedListener = baseOnItemViewSelectedListener;
        baseOnItemViewSelectedListener = getVerticalGridView();
        if (baseOnItemViewSelectedListener != null) {
            int childCount = baseOnItemViewSelectedListener.getChildCount();
            for (int i = 0; i < childCount; i++) {
                getRowViewHolder((ViewHolder) baseOnItemViewSelectedListener.getChildViewHolder(baseOnItemViewSelectedListener.getChildAt(i))).setOnItemViewSelectedListener(this.mOnItemViewSelectedListener);
            }
        }
    }

    public BaseOnItemViewSelectedListener getOnItemViewSelectedListener() {
        return this.mOnItemViewSelectedListener;
    }

    void onRowSelected(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, int i, int i2) {
        boolean z = true;
        if (!(this.mSelectedViewHolder == viewHolder && this.mSubPosition == i2)) {
            this.mSubPosition = i2;
            recyclerView = this.mSelectedViewHolder;
            if (recyclerView != null) {
                setRowViewSelected(recyclerView, false, false);
            }
            this.mSelectedViewHolder = (ViewHolder) viewHolder;
            recyclerView = this.mSelectedViewHolder;
            if (recyclerView != null) {
                setRowViewSelected(recyclerView, true, false);
            }
        }
        recyclerView = this.mMainFragmentAdapter;
        if (recyclerView != null) {
            recyclerView = recyclerView.getFragmentHost();
            if (i > 0) {
                z = false;
            }
            recyclerView.showTitleView(z);
        }
    }

    public RowPresenter.ViewHolder getRowViewHolder(int i) {
        VerticalGridView verticalGridView = getVerticalGridView();
        if (verticalGridView == null) {
            return 0;
        }
        return getRowViewHolder((ViewHolder) verticalGridView.findViewHolderForAdapterPosition(i));
    }

    int getLayoutResourceId() {
        return R.layout.lb_rows_fragment;
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.mSelectAnimatorDuration = getResources().getInteger(R.integer.lb_browse_rows_anim_duration);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        getVerticalGridView().setItemAlignmentViewId(R.id.row_content);
        getVerticalGridView().setSaveChildrenPolicy(2);
        setAlignment(this.mAlignedTop);
        this.mRecycledViewPool = null;
        this.mPresenterMapper = null;
        view = this.mMainFragmentAdapter;
        if (view != null) {
            view.getFragmentHost().notifyViewCreated(this.mMainFragmentAdapter);
        }
    }

    public void onDestroyView() {
        this.mViewsCreated = false;
        super.onDestroyView();
    }

    void setExternalAdapterListener(AdapterListener adapterListener) {
        this.mExternalAdapterListener = adapterListener;
    }

    static void setRowViewExpanded(ViewHolder viewHolder, boolean z) {
        ((RowPresenter) viewHolder.getPresenter()).setRowViewExpanded(viewHolder.getViewHolder(), z);
    }

    static void setRowViewSelected(ViewHolder viewHolder, boolean z, boolean z2) {
        ((RowViewHolderExtra) viewHolder.getExtraObject()).animateSelect(z, z2);
        ((RowPresenter) viewHolder.getPresenter()).setRowViewSelected(viewHolder.getViewHolder(), z);
    }

    void setupSharedViewPool(ViewHolder viewHolder) {
        viewHolder = ((RowPresenter) viewHolder.getPresenter()).getRowViewHolder(viewHolder.getViewHolder());
        if (viewHolder instanceof ListRowPresenter.ViewHolder) {
            ListRowPresenter.ViewHolder viewHolder2 = (ListRowPresenter.ViewHolder) viewHolder;
            HorizontalGridView gridView = viewHolder2.getGridView();
            RecycledViewPool recycledViewPool = this.mRecycledViewPool;
            if (recycledViewPool == null) {
                this.mRecycledViewPool = gridView.getRecycledViewPool();
            } else {
                gridView.setRecycledViewPool(recycledViewPool);
            }
            viewHolder = viewHolder2.getBridgeAdapter();
            ArrayList arrayList = this.mPresenterMapper;
            if (arrayList == null) {
                this.mPresenterMapper = viewHolder.getPresenterMapper();
            } else {
                viewHolder.setPresenterMapper(arrayList);
            }
        }
    }

    void updateAdapter() {
        super.updateAdapter();
        this.mSelectedViewHolder = null;
        this.mViewsCreated = false;
        ItemBridgeAdapter bridgeAdapter = getBridgeAdapter();
        if (bridgeAdapter != null) {
            bridgeAdapter.setAdapterListener(this.mBridgeAdapterListener);
        }
    }

    public boolean onTransitionPrepare() {
        boolean onTransitionPrepare = super.onTransitionPrepare();
        if (onTransitionPrepare) {
            freezeRows(true);
        }
        return onTransitionPrepare;
    }

    public void onTransitionEnd() {
        super.onTransitionEnd();
        freezeRows(false);
    }

    private void freezeRows(boolean z) {
        this.mFreezeRows = z;
        VerticalGridView verticalGridView = getVerticalGridView();
        if (verticalGridView != null) {
            int childCount = verticalGridView.getChildCount();
            for (int i = 0; i < childCount; i++) {
                ViewHolder viewHolder = (ViewHolder) verticalGridView.getChildViewHolder(verticalGridView.getChildAt(i));
                RowPresenter rowPresenter = (RowPresenter) viewHolder.getPresenter();
                rowPresenter.freeze(rowPresenter.getRowViewHolder(viewHolder.getViewHolder()), z);
            }
        }
    }

    public void setEntranceTransitionState(boolean z) {
        this.mAfterEntranceTransition = z;
        z = getVerticalGridView();
        if (z) {
            int childCount = z.getChildCount();
            for (int i = 0; i < childCount; i++) {
                ViewHolder viewHolder = (ViewHolder) z.getChildViewHolder(z.getChildAt(i));
                RowPresenter rowPresenter = (RowPresenter) viewHolder.getPresenter();
                rowPresenter.setEntranceTransitionState(rowPresenter.getRowViewHolder(viewHolder.getViewHolder()), this.mAfterEntranceTransition);
            }
        }
    }

    public void setSelectedPosition(int i, boolean z, final ViewHolderTask viewHolderTask) {
        VerticalGridView verticalGridView = getVerticalGridView();
        if (verticalGridView != null) {
            androidx.leanback.widget.ViewHolderTask viewHolderTask2 = null;
            if (viewHolderTask != null) {
                viewHolderTask2 = new androidx.leanback.widget.ViewHolderTask() {
                    public void run(final RecyclerView.ViewHolder viewHolder) {
                        viewHolder.itemView.post(new Runnable() {
                            public void run() {
                                viewHolderTask.run(RowsFragment.getRowViewHolder((ViewHolder) viewHolder));
                            }
                        });
                    }
                };
            }
            if (z) {
                verticalGridView.setSelectedPositionSmooth(i, viewHolderTask2);
            } else {
                verticalGridView.setSelectedPosition(i, viewHolderTask2);
            }
        }
    }

    static RowPresenter.ViewHolder getRowViewHolder(ViewHolder viewHolder) {
        if (viewHolder == null) {
            return null;
        }
        return ((RowPresenter) viewHolder.getPresenter()).getRowViewHolder(viewHolder.getViewHolder());
    }

    public boolean isScrolling() {
        boolean z = false;
        if (getVerticalGridView() == null) {
            return false;
        }
        if (getVerticalGridView().getScrollState() != 0) {
            z = true;
        }
        return z;
    }

    public void setAlignment(int i) {
        if (i != Integer.MIN_VALUE) {
            this.mAlignedTop = i;
            i = getVerticalGridView();
            if (i != 0) {
                i.setItemAlignmentOffset(0);
                i.setItemAlignmentOffsetPercent(-1.0f);
                i.setItemAlignmentOffsetWithPadding(true);
                i.setWindowAlignmentOffset(this.mAlignedTop);
                i.setWindowAlignmentOffsetPercent(-1.0f);
                i.setWindowAlignment(0);
            }
        }
    }

    public RowPresenter.ViewHolder findRowViewHolderByPosition(int i) {
        if (this.mVerticalGridView == null) {
            return 0;
        }
        return getRowViewHolder((ViewHolder) this.mVerticalGridView.findViewHolderForAdapterPosition(i));
    }
}
