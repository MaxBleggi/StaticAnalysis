package androidx.leanback.app;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.LayerDrawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.interpolator.view.animation.FastOutLinearInInterpolator;
import androidx.leanback.R;
import androidx.leanback.widget.BackgroundHelper;
import java.lang.ref.WeakReference;

public final class BackgroundManager {
    private static final int CHANGE_BG_DELAY_MS = 500;
    static final boolean DEBUG = false;
    private static final int FADE_DURATION = 500;
    private static final String FRAGMENT_TAG = BackgroundManager.class.getCanonicalName();
    static final int FULL_ALPHA = 255;
    static final String TAG = "BackgroundManager";
    private final Interpolator mAccelerateInterpolator;
    private final AnimatorListener mAnimationListener = new AnimatorListener() {
        final Runnable mRunnable = new Runnable() {
            public void run() {
                BackgroundManager.this.postChangeRunnable();
            }
        };

        public void onAnimationCancel(Animator animator) {
        }

        public void onAnimationRepeat(Animator animator) {
        }

        public void onAnimationStart(Animator animator) {
        }

        public void onAnimationEnd(Animator animator) {
            if (BackgroundManager.this.mLayerDrawable != null) {
                BackgroundManager.this.mLayerDrawable.clearDrawable(R.id.background_imageout, BackgroundManager.this.mContext);
            }
            BackgroundManager.this.mHandler.post(this.mRunnable);
        }
    };
    private final AnimatorUpdateListener mAnimationUpdateListener = new AnimatorUpdateListener() {
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            valueAnimator = ((Integer) valueAnimator.getAnimatedValue()).intValue();
            if (BackgroundManager.this.mImageInWrapperIndex != -1) {
                BackgroundManager.this.mLayerDrawable.setWrapperAlpha(BackgroundManager.this.mImageInWrapperIndex, valueAnimator);
            }
        }
    };
    final ValueAnimator mAnimator;
    boolean mAttached;
    private boolean mAutoReleaseOnStop = true;
    int mBackgroundColor;
    Drawable mBackgroundDrawable;
    private View mBgView;
    ChangeBackgroundRunnable mChangeRunnable;
    private boolean mChangeRunnablePending;
    Activity mContext;
    private final Interpolator mDecelerateInterpolator;
    private BackgroundFragment mFragmentState;
    Handler mHandler;
    private int mHeightPx;
    int mImageInWrapperIndex;
    int mImageOutWrapperIndex;
    private long mLastSetTime;
    TranslucentLayerDrawable mLayerDrawable;
    private BackgroundContinuityService mService;
    private int mThemeDrawableResourceId;
    private int mWidthPx;

    private static class BackgroundContinuityService {
        private static final boolean DEBUG = false;
        private static final String TAG = "BackgroundContinuity";
        private static BackgroundContinuityService sService = new BackgroundContinuityService();
        private int mColor;
        private int mCount;
        private Drawable mDrawable;
        private int mLastThemeDrawableId;
        private WeakReference<ConstantState> mLastThemeDrawableState;

        private BackgroundContinuityService() {
            reset();
        }

        private void reset() {
            this.mColor = 0;
            this.mDrawable = null;
        }

        public static BackgroundContinuityService getInstance() {
            BackgroundContinuityService backgroundContinuityService = sService;
            backgroundContinuityService.mCount++;
            return backgroundContinuityService;
        }

        public void unref() {
            int i = this.mCount;
            if (i > 0) {
                i--;
                this.mCount = i;
                if (i == 0) {
                    reset();
                    return;
                }
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Can't unref, count ");
            stringBuilder.append(this.mCount);
            throw new IllegalStateException(stringBuilder.toString());
        }

        public int getColor() {
            return this.mColor;
        }

        public Drawable getDrawable() {
            return this.mDrawable;
        }

        public void setColor(int i) {
            this.mColor = i;
            this.mDrawable = 0;
        }

        public void setDrawable(Drawable drawable) {
            this.mDrawable = drawable;
        }

        public Drawable getThemeDrawable(Context context, int i) {
            Drawable newDrawable;
            WeakReference weakReference = this.mLastThemeDrawableState;
            if (weakReference != null && this.mLastThemeDrawableId == i) {
                ConstantState constantState = (ConstantState) weakReference.get();
                if (constantState != null) {
                    newDrawable = constantState.newDrawable();
                    if (newDrawable == null) {
                        return newDrawable;
                    }
                    newDrawable = ContextCompat.getDrawable(context, i);
                    this.mLastThemeDrawableState = new WeakReference(newDrawable.getConstantState());
                    this.mLastThemeDrawableId = i;
                    return newDrawable;
                }
            }
            newDrawable = null;
            if (newDrawable == null) {
                return newDrawable;
            }
            newDrawable = ContextCompat.getDrawable(context, i);
            this.mLastThemeDrawableState = new WeakReference(newDrawable.getConstantState());
            this.mLastThemeDrawableId = i;
            return newDrawable;
        }
    }

    static class BitmapDrawable extends Drawable {
        boolean mMutated;
        ConstantState mState;

        static final class ConstantState extends android.graphics.drawable.Drawable.ConstantState {
            final Bitmap mBitmap;
            final Matrix mMatrix;
            final Paint mPaint = new Paint();

            public int getChangingConfigurations() {
                return 0;
            }

            ConstantState(Bitmap bitmap, Matrix matrix) {
                this.mBitmap = bitmap;
                if (matrix == null) {
                    matrix = new Matrix();
                }
                this.mMatrix = matrix;
                this.mPaint.setFilterBitmap(true);
            }

            ConstantState(ConstantState constantState) {
                Matrix matrix;
                this.mBitmap = constantState.mBitmap;
                if (constantState.mMatrix != null) {
                    matrix = new Matrix(constantState.mMatrix);
                } else {
                    matrix = new Matrix();
                }
                this.mMatrix = matrix;
                if (constantState.mPaint.getAlpha() != 255) {
                    this.mPaint.setAlpha(constantState.mPaint.getAlpha());
                }
                if (constantState.mPaint.getColorFilter() != null) {
                    this.mPaint.setColorFilter(constantState.mPaint.getColorFilter());
                }
                this.mPaint.setFilterBitmap(true);
            }

            public Drawable newDrawable() {
                return new BitmapDrawable(this);
            }
        }

        public int getOpacity() {
            return -3;
        }

        BitmapDrawable(Resources resources, Bitmap bitmap) {
            this(resources, bitmap, null);
        }

        BitmapDrawable(Resources resources, Bitmap bitmap, Matrix matrix) {
            this.mState = new ConstantState(bitmap, matrix);
        }

        BitmapDrawable(ConstantState constantState) {
            this.mState = constantState;
        }

        Bitmap getBitmap() {
            return this.mState.mBitmap;
        }

        public void draw(Canvas canvas) {
            if (this.mState.mBitmap != null) {
                if (this.mState.mPaint.getAlpha() < 255) {
                    if (this.mState.mPaint.getColorFilter() != null) {
                        throw new IllegalStateException("Can't draw with translucent alpha and color filter");
                    }
                }
                canvas.drawBitmap(this.mState.mBitmap, this.mState.mMatrix, this.mState.mPaint);
            }
        }

        public void setAlpha(int i) {
            mutate();
            if (this.mState.mPaint.getAlpha() != i) {
                this.mState.mPaint.setAlpha(i);
                invalidateSelf();
            }
        }

        public void setColorFilter(ColorFilter colorFilter) {
            mutate();
            this.mState.mPaint.setColorFilter(colorFilter);
            invalidateSelf();
        }

        public ColorFilter getColorFilter() {
            return this.mState.mPaint.getColorFilter();
        }

        public ConstantState getConstantState() {
            return this.mState;
        }

        public Drawable mutate() {
            if (!this.mMutated) {
                this.mMutated = true;
                this.mState = new ConstantState(this.mState);
            }
            return this;
        }
    }

    final class ChangeBackgroundRunnable implements Runnable {
        final Drawable mDrawable;

        ChangeBackgroundRunnable(Drawable drawable) {
            this.mDrawable = drawable;
        }

        public void run() {
            runTask();
            BackgroundManager.this.mChangeRunnable = null;
        }

        private void runTask() {
            if (BackgroundManager.this.mLayerDrawable != null) {
                DrawableWrapper imageInWrapper = BackgroundManager.this.getImageInWrapper();
                if (imageInWrapper != null) {
                    if (!BackgroundManager.this.sameDrawable(this.mDrawable, imageInWrapper.getDrawable())) {
                        BackgroundManager.this.mLayerDrawable.clearDrawable(R.id.background_imagein, BackgroundManager.this.mContext);
                        BackgroundManager.this.mLayerDrawable.updateDrawable(R.id.background_imageout, imageInWrapper.getDrawable());
                    } else {
                        return;
                    }
                }
                applyBackgroundChanges();
            }
        }

        void applyBackgroundChanges() {
            if (BackgroundManager.this.mAttached) {
                if (BackgroundManager.this.getImageInWrapper() == null && this.mDrawable != null) {
                    BackgroundManager.this.mLayerDrawable.updateDrawable(R.id.background_imagein, this.mDrawable);
                    BackgroundManager.this.mLayerDrawable.setWrapperAlpha(BackgroundManager.this.mImageInWrapperIndex, 0);
                }
                BackgroundManager.this.mAnimator.setDuration(500);
                BackgroundManager.this.mAnimator.start();
            }
        }
    }

    static final class DrawableWrapper {
        int mAlpha = 255;
        final Drawable mDrawable;

        public DrawableWrapper(Drawable drawable) {
            this.mDrawable = drawable;
        }

        public DrawableWrapper(DrawableWrapper drawableWrapper, Drawable drawable) {
            this.mDrawable = drawable;
            this.mAlpha = drawableWrapper.mAlpha;
        }

        public Drawable getDrawable() {
            return this.mDrawable;
        }

        public void setColor(int i) {
            ((ColorDrawable) this.mDrawable).setColor(i);
        }
    }

    static final class TranslucentLayerDrawable extends LayerDrawable {
        int mAlpha = 255;
        WeakReference<BackgroundManager> mManagerWeakReference;
        boolean mSuspendInvalidation;
        DrawableWrapper[] mWrapper;

        public int getOpacity() {
            return -3;
        }

        TranslucentLayerDrawable(BackgroundManager backgroundManager, Drawable[] drawableArr) {
            super(drawableArr);
            this.mManagerWeakReference = new WeakReference(backgroundManager);
            backgroundManager = drawableArr.length;
            this.mWrapper = new DrawableWrapper[backgroundManager];
            for (int i = 0; i < backgroundManager; i++) {
                this.mWrapper[i] = new DrawableWrapper(drawableArr[i]);
            }
        }

        public void setAlpha(int i) {
            if (this.mAlpha != i) {
                this.mAlpha = i;
                invalidateSelf();
                BackgroundManager backgroundManager = (BackgroundManager) this.mManagerWeakReference.get();
                if (backgroundManager != null) {
                    backgroundManager.postChangeRunnable();
                }
            }
        }

        void setWrapperAlpha(int i, int i2) {
            DrawableWrapper[] drawableWrapperArr = this.mWrapper;
            if (drawableWrapperArr[i] != null) {
                drawableWrapperArr[i].mAlpha = i2;
                invalidateSelf();
            }
        }

        public int getAlpha() {
            return this.mAlpha;
        }

        public Drawable mutate() {
            Drawable mutate = super.mutate();
            int numberOfLayers = getNumberOfLayers();
            for (int i = 0; i < numberOfLayers; i++) {
                DrawableWrapper[] drawableWrapperArr = this.mWrapper;
                if (drawableWrapperArr[i] != null) {
                    drawableWrapperArr[i] = new DrawableWrapper(drawableWrapperArr[i], getDrawable(i));
                }
            }
            return mutate;
        }

        public boolean setDrawableByLayerId(int i, Drawable drawable) {
            return updateDrawable(i, drawable) != 0;
        }

        public DrawableWrapper updateDrawable(int i, Drawable drawable) {
            super.setDrawableByLayerId(i, drawable);
            for (int i2 = 0; i2 < getNumberOfLayers(); i2++) {
                if (getId(i2) == i) {
                    this.mWrapper[i2] = new DrawableWrapper(drawable);
                    invalidateSelf();
                    return this.mWrapper[i2];
                }
            }
            return 0;
        }

        public void clearDrawable(int i, Context context) {
            for (int i2 = 0; i2 < getNumberOfLayers(); i2++) {
                if (getId(i2) == i) {
                    this.mWrapper[i2] = null;
                    if (!(getDrawable(i2) instanceof EmptyDrawable)) {
                        super.setDrawableByLayerId(i, BackgroundManager.createEmptyDrawable(context));
                        return;
                    }
                    return;
                }
            }
        }

        public int findWrapperIndexById(int i) {
            for (int i2 = 0; i2 < getNumberOfLayers(); i2++) {
                if (getId(i2) == i) {
                    return i2;
                }
            }
            return -1;
        }

        public void invalidateDrawable(Drawable drawable) {
            if (!this.mSuspendInvalidation) {
                super.invalidateDrawable(drawable);
            }
        }

        public void draw(Canvas canvas) {
            int i = 0;
            while (true) {
                DrawableWrapper[] drawableWrapperArr = this.mWrapper;
                if (i < drawableWrapperArr.length) {
                    if (drawableWrapperArr[i] != null) {
                        Drawable drawable = drawableWrapperArr[i].getDrawable();
                        if (drawable == null) {
                            continue;
                        } else {
                            int i2;
                            int alpha = VERSION.SDK_INT >= 19 ? DrawableCompat.getAlpha(drawable) : 255;
                            int i3 = this.mAlpha;
                            if (i3 < 255) {
                                i3 *= alpha;
                                i2 = 1;
                            } else {
                                i3 = alpha;
                                i2 = 0;
                            }
                            if (this.mWrapper[i].mAlpha < 255) {
                                i3 *= this.mWrapper[i].mAlpha;
                                i2++;
                            }
                            if (i2 == 0) {
                                drawable.draw(canvas);
                            } else {
                                if (i2 == 1) {
                                    i3 /= 255;
                                } else if (i2 == 2) {
                                    i3 /= OggPageHeader.MAX_PAGE_PAYLOAD;
                                }
                                try {
                                    this.mSuspendInvalidation = true;
                                    drawable.setAlpha(i3);
                                    drawable.draw(canvas);
                                    drawable.setAlpha(alpha);
                                } finally {
                                    this.mSuspendInvalidation = false;
                                }
                            }
                        }
                    }
                    i++;
                } else {
                    return;
                }
            }
        }
    }

    static class EmptyDrawable extends BitmapDrawable {
        EmptyDrawable(Resources resources) {
            super(resources, (Bitmap) null);
        }
    }

    @Deprecated
    public Drawable getDimLayer() {
        return null;
    }

    @Deprecated
    public void setDimLayer(Drawable drawable) {
    }

    TranslucentLayerDrawable createTranslucentLayerDrawable(LayerDrawable layerDrawable) {
        int numberOfLayers = layerDrawable.getNumberOfLayers();
        Drawable[] drawableArr = new Drawable[numberOfLayers];
        for (int i = 0; i < numberOfLayers; i++) {
            drawableArr[i] = layerDrawable.getDrawable(i);
        }
        TranslucentLayerDrawable translucentLayerDrawable = new TranslucentLayerDrawable(this, drawableArr);
        for (int i2 = 0; i2 < numberOfLayers; i2++) {
            translucentLayerDrawable.setId(i2, layerDrawable.getId(i2));
        }
        return translucentLayerDrawable;
    }

    Drawable getDefaultDrawable() {
        int i = this.mBackgroundColor;
        if (i != 0) {
            return new ColorDrawable(i);
        }
        return getThemeDrawable();
    }

    private Drawable getThemeDrawable() {
        int i = this.mThemeDrawableResourceId;
        Drawable themeDrawable = i != -1 ? this.mService.getThemeDrawable(this.mContext, i) : null;
        return themeDrawable == null ? createEmptyDrawable(this.mContext) : themeDrawable;
    }

    public static BackgroundManager getInstance(Activity activity) {
        BackgroundFragment backgroundFragment = (BackgroundFragment) activity.getFragmentManager().findFragmentByTag(FRAGMENT_TAG);
        if (backgroundFragment != null) {
            BackgroundManager backgroundManager = backgroundFragment.getBackgroundManager();
            if (backgroundManager != null) {
                return backgroundManager;
            }
        }
        return new BackgroundManager(activity);
    }

    private BackgroundManager(Activity activity) {
        this.mContext = activity;
        this.mService = BackgroundContinuityService.getInstance();
        this.mHeightPx = this.mContext.getResources().getDisplayMetrics().heightPixels;
        this.mWidthPx = this.mContext.getResources().getDisplayMetrics().widthPixels;
        this.mHandler = new Handler();
        TimeInterpolator fastOutLinearInInterpolator = new FastOutLinearInInterpolator();
        this.mAccelerateInterpolator = AnimationUtils.loadInterpolator(this.mContext, 17432581);
        this.mDecelerateInterpolator = AnimationUtils.loadInterpolator(this.mContext, 17432582);
        this.mAnimator = ValueAnimator.ofInt(new int[]{0, 255});
        this.mAnimator.addListener(this.mAnimationListener);
        this.mAnimator.addUpdateListener(this.mAnimationUpdateListener);
        this.mAnimator.setInterpolator(fastOutLinearInInterpolator);
        TypedArray obtainStyledAttributes = activity.getTheme().obtainStyledAttributes(new int[]{16842836});
        this.mThemeDrawableResourceId = obtainStyledAttributes.getResourceId(0, -1);
        int i = this.mThemeDrawableResourceId;
        obtainStyledAttributes.recycle();
        createFragment(activity);
    }

    private void createFragment(Activity activity) {
        BackgroundFragment backgroundFragment = (BackgroundFragment) activity.getFragmentManager().findFragmentByTag(FRAGMENT_TAG);
        if (backgroundFragment == null) {
            backgroundFragment = new BackgroundFragment();
            activity.getFragmentManager().beginTransaction().add(backgroundFragment, FRAGMENT_TAG).commit();
        } else if (backgroundFragment.getBackgroundManager() != null) {
            throw new IllegalStateException("Created duplicated BackgroundManager for same activity, please use getInstance() instead");
        }
        backgroundFragment.setBackgroundManager(this);
        this.mFragmentState = backgroundFragment;
    }

    DrawableWrapper getImageInWrapper() {
        TranslucentLayerDrawable translucentLayerDrawable = this.mLayerDrawable;
        return translucentLayerDrawable == null ? null : translucentLayerDrawable.mWrapper[this.mImageInWrapperIndex];
    }

    DrawableWrapper getImageOutWrapper() {
        TranslucentLayerDrawable translucentLayerDrawable = this.mLayerDrawable;
        return translucentLayerDrawable == null ? null : translucentLayerDrawable.mWrapper[this.mImageOutWrapperIndex];
    }

    void onActivityStart() {
        updateImmediate();
    }

    void onStop() {
        if (isAutoReleaseOnStop()) {
            release();
        }
    }

    void onResume() {
        postChangeRunnable();
    }

    private void syncWithService() {
        Drawable drawable;
        int color = this.mService.getColor();
        Drawable drawable2 = this.mService.getDrawable();
        this.mBackgroundColor = color;
        if (drawable2 == null) {
            drawable = null;
        } else {
            drawable = drawable2.getConstantState().newDrawable().mutate();
        }
        this.mBackgroundDrawable = drawable;
        updateImmediate();
    }

    public void attach(Window window) {
        attachToViewInternal(window.getDecorView());
    }

    public void setThemeDrawableResourceId(int i) {
        this.mThemeDrawableResourceId = i;
    }

    public void attachToView(View view) {
        attachToViewInternal(view);
        this.mContext.getWindow().getDecorView().setBackground(VERSION.SDK_INT >= 26 ? null : new ColorDrawable(0));
    }

    void attachToViewInternal(View view) {
        if (this.mAttached) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Already attached to ");
            stringBuilder.append(this.mBgView);
            throw new IllegalStateException(stringBuilder.toString());
        }
        this.mBgView = view;
        this.mAttached = true;
        syncWithService();
    }

    public boolean isAttached() {
        return this.mAttached;
    }

    void detach() {
        release();
        this.mBgView = null;
        this.mAttached = false;
        BackgroundContinuityService backgroundContinuityService = this.mService;
        if (backgroundContinuityService != null) {
            backgroundContinuityService.unref();
            this.mService = null;
        }
    }

    public void release() {
        Runnable runnable = this.mChangeRunnable;
        if (runnable != null) {
            this.mHandler.removeCallbacks(runnable);
            this.mChangeRunnable = null;
        }
        if (this.mAnimator.isStarted()) {
            this.mAnimator.cancel();
        }
        TranslucentLayerDrawable translucentLayerDrawable = this.mLayerDrawable;
        if (translucentLayerDrawable != null) {
            translucentLayerDrawable.clearDrawable(R.id.background_imagein, this.mContext);
            this.mLayerDrawable.clearDrawable(R.id.background_imageout, this.mContext);
            this.mLayerDrawable = null;
        }
        this.mBackgroundDrawable = null;
    }

    @Deprecated
    public Drawable getDefaultDimLayer() {
        return ContextCompat.getDrawable(this.mContext, R.color.lb_background_protection);
    }

    void postChangeRunnable() {
        if (this.mChangeRunnable == null) {
            return;
        }
        if (!this.mChangeRunnablePending) {
            return;
        }
        if (!this.mAnimator.isStarted()) {
            if (!this.mFragmentState.isResumed()) {
                return;
            }
            if (this.mLayerDrawable.getAlpha() >= 255) {
                long runnableDelay = getRunnableDelay();
                this.mLastSetTime = System.currentTimeMillis();
                this.mHandler.postDelayed(this.mChangeRunnable, runnableDelay);
                this.mChangeRunnablePending = false;
            }
        }
    }

    private void lazyInit() {
        if (this.mLayerDrawable == null) {
            this.mLayerDrawable = createTranslucentLayerDrawable((LayerDrawable) ContextCompat.getDrawable(this.mContext, R.drawable.lb_background).mutate());
            this.mImageInWrapperIndex = this.mLayerDrawable.findWrapperIndexById(R.id.background_imagein);
            this.mImageOutWrapperIndex = this.mLayerDrawable.findWrapperIndexById(R.id.background_imageout);
            BackgroundHelper.setBackgroundPreservingAlpha(this.mBgView, this.mLayerDrawable);
        }
    }

    private void updateImmediate() {
        if (this.mAttached) {
            lazyInit();
            if (this.mBackgroundDrawable == null) {
                this.mLayerDrawable.updateDrawable(R.id.background_imagein, getDefaultDrawable());
            } else {
                this.mLayerDrawable.updateDrawable(R.id.background_imagein, this.mBackgroundDrawable);
            }
            this.mLayerDrawable.clearDrawable(R.id.background_imageout, this.mContext);
        }
    }

    public void setColor(int i) {
        this.mService.setColor(i);
        this.mBackgroundColor = i;
        this.mBackgroundDrawable = 0;
        if (this.mLayerDrawable != 0) {
            setDrawableInternal(getDefaultDrawable());
        }
    }

    public void setDrawable(Drawable drawable) {
        this.mService.setDrawable(drawable);
        this.mBackgroundDrawable = drawable;
        if (this.mLayerDrawable != null) {
            if (drawable == null) {
                setDrawableInternal(getDefaultDrawable());
            } else {
                setDrawableInternal(drawable);
            }
        }
    }

    public void clearDrawable() {
        setDrawable(null);
    }

    private void setDrawableInternal(Drawable drawable) {
        if (this.mAttached) {
            ChangeBackgroundRunnable changeBackgroundRunnable = this.mChangeRunnable;
            if (changeBackgroundRunnable != null) {
                if (!sameDrawable(drawable, changeBackgroundRunnable.mDrawable)) {
                    this.mHandler.removeCallbacks(this.mChangeRunnable);
                    this.mChangeRunnable = null;
                } else {
                    return;
                }
            }
            this.mChangeRunnable = new ChangeBackgroundRunnable(drawable);
            this.mChangeRunnablePending = true;
            postChangeRunnable();
            return;
        }
        throw new IllegalStateException("Must attach before setting background drawable");
    }

    private long getRunnableDelay() {
        return Math.max(0, (this.mLastSetTime + 500) - System.currentTimeMillis());
    }

    public void setBitmap(Bitmap bitmap) {
        Matrix matrix = null;
        if (bitmap == null) {
            setDrawable(null);
            return;
        }
        if (bitmap.getWidth() > 0) {
            if (bitmap.getHeight() > 0) {
                if (!(bitmap.getWidth() == this.mWidthPx && bitmap.getHeight() == this.mHeightPx)) {
                    int width = bitmap.getWidth();
                    int height = bitmap.getHeight();
                    int i = this.mHeightPx;
                    int i2 = width * i;
                    int i3 = this.mWidthPx;
                    float f = i2 > i3 * height ? ((float) i) / ((float) height) : ((float) i3) / ((float) width);
                    width = Math.max(0, (width - Math.min((int) (((float) this.mWidthPx) / f), width)) / 2);
                    Matrix matrix2 = new Matrix();
                    matrix2.setScale(f, f);
                    matrix2.preTranslate((float) (-width), 0.0f);
                    matrix = matrix2;
                }
                setDrawable(new BitmapDrawable(this.mContext.getResources(), bitmap, matrix));
            }
        }
    }

    public void setAutoReleaseOnStop(boolean z) {
        this.mAutoReleaseOnStop = z;
    }

    public boolean isAutoReleaseOnStop() {
        return this.mAutoReleaseOnStop;
    }

    public final int getColor() {
        return this.mBackgroundColor;
    }

    public Drawable getDrawable() {
        return this.mBackgroundDrawable;
    }

    boolean sameDrawable(Drawable drawable, Drawable drawable2) {
        if (drawable != null) {
            if (drawable2 != null) {
                if (drawable == drawable2) {
                    return true;
                }
                if ((drawable instanceof BitmapDrawable) && (drawable2 instanceof BitmapDrawable) && ((BitmapDrawable) drawable).getBitmap().sameAs(((BitmapDrawable) drawable2).getBitmap())) {
                    return true;
                }
                return (drawable instanceof ColorDrawable) && (drawable2 instanceof ColorDrawable) && ((ColorDrawable) drawable).getColor() == ((ColorDrawable) drawable2).getColor();
            }
        }
    }

    static Drawable createEmptyDrawable(Context context) {
        return new EmptyDrawable(context.getResources());
    }
}
