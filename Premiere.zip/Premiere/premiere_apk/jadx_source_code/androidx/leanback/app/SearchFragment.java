package androidx.leanback.app;

import android.app.Fragment;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.speech.SpeechRecognizer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.CompletionInfo;
import android.widget.FrameLayout;
import androidx.leanback.R;
import androidx.leanback.widget.ObjectAdapter;
import androidx.leanback.widget.ObjectAdapter.DataObserver;
import androidx.leanback.widget.OnItemViewClickedListener;
import androidx.leanback.widget.OnItemViewSelectedListener;
import androidx.leanback.widget.Presenter.ViewHolder;
import androidx.leanback.widget.Row;
import androidx.leanback.widget.RowPresenter;
import androidx.leanback.widget.SearchBar;
import androidx.leanback.widget.SearchBar.SearchBarListener;
import androidx.leanback.widget.SearchBar.SearchBarPermissionListener;
import androidx.leanback.widget.SearchOrbView.Colors;
import androidx.leanback.widget.SpeechRecognitionCallback;
import androidx.leanback.widget.VerticalGridView;
import java.util.List;

@Deprecated
public class SearchFragment extends Fragment {
    private static final String ARG_PREFIX;
    private static final String ARG_QUERY;
    private static final String ARG_TITLE;
    static final int AUDIO_PERMISSION_REQUEST_CODE = 0;
    static final boolean DEBUG = false;
    private static final String EXTRA_LEANBACK_BADGE_PRESENT = "LEANBACK_BADGE_PRESENT";
    static final int QUERY_COMPLETE = 2;
    static final int RESULTS_CHANGED = 1;
    static final long SPEECH_RECOGNITION_DELAY_MS = 300;
    static final String TAG;
    final DataObserver mAdapterObserver = new DataObserver() {
        public void onChanged() {
            SearchFragment.this.mHandler.removeCallbacks(SearchFragment.this.mResultsChangedCallback);
            SearchFragment.this.mHandler.post(SearchFragment.this.mResultsChangedCallback);
        }
    };
    boolean mAutoStartRecognition = true;
    private Drawable mBadgeDrawable;
    private ExternalQuery mExternalQuery;
    final Handler mHandler = new Handler();
    private boolean mIsPaused;
    private OnItemViewClickedListener mOnItemViewClickedListener;
    OnItemViewSelectedListener mOnItemViewSelectedListener;
    String mPendingQuery = null;
    private boolean mPendingStartRecognitionWhenPaused;
    private SearchBarPermissionListener mPermissionListener = new SearchBarPermissionListener() {
        public void requestAudioPermission() {
            PermissionHelper.requestPermissions(SearchFragment.this, new String[]{"android.permission.RECORD_AUDIO"}, 0);
        }
    };
    SearchResultProvider mProvider;
    ObjectAdapter mResultAdapter;
    final Runnable mResultsChangedCallback = new Runnable() {
        public void run() {
            if (!(SearchFragment.this.mRowsFragment == null || SearchFragment.this.mRowsFragment.getAdapter() == SearchFragment.this.mResultAdapter || (SearchFragment.this.mRowsFragment.getAdapter() == null && SearchFragment.this.mResultAdapter.size() == 0))) {
                SearchFragment.this.mRowsFragment.setAdapter(SearchFragment.this.mResultAdapter);
                SearchFragment.this.mRowsFragment.setSelectedPosition(0);
            }
            SearchFragment.this.updateSearchBarVisibility();
            SearchFragment searchFragment = SearchFragment.this;
            searchFragment.mStatus |= 1;
            if ((SearchFragment.this.mStatus & 2) != 0) {
                SearchFragment.this.updateFocus();
            }
            SearchFragment.this.updateSearchBarNextFocusId();
        }
    };
    RowsFragment mRowsFragment;
    SearchBar mSearchBar;
    private final Runnable mSetSearchResultProvider = new Runnable() {
        public void run() {
            if (SearchFragment.this.mRowsFragment != null) {
                ObjectAdapter resultsAdapter = SearchFragment.this.mProvider.getResultsAdapter();
                if (resultsAdapter != SearchFragment.this.mResultAdapter) {
                    Object obj = SearchFragment.this.mResultAdapter == null ? 1 : null;
                    SearchFragment.this.releaseAdapter();
                    SearchFragment searchFragment = SearchFragment.this;
                    searchFragment.mResultAdapter = resultsAdapter;
                    if (searchFragment.mResultAdapter != null) {
                        SearchFragment.this.mResultAdapter.registerObserver(SearchFragment.this.mAdapterObserver);
                    }
                    if (obj == null || !(SearchFragment.this.mResultAdapter == null || SearchFragment.this.mResultAdapter.size() == 0)) {
                        SearchFragment.this.mRowsFragment.setAdapter(SearchFragment.this.mResultAdapter);
                    }
                    SearchFragment.this.executePendingQuery();
                }
                SearchFragment.this.updateSearchBarNextFocusId();
                if (SearchFragment.this.mAutoStartRecognition) {
                    SearchFragment.this.mHandler.removeCallbacks(SearchFragment.this.mStartRecognitionRunnable);
                    SearchFragment.this.mHandler.postDelayed(SearchFragment.this.mStartRecognitionRunnable, SearchFragment.SPEECH_RECOGNITION_DELAY_MS);
                } else {
                    SearchFragment.this.updateFocus();
                }
            }
        }
    };
    private SpeechRecognitionCallback mSpeechRecognitionCallback;
    private SpeechRecognizer mSpeechRecognizer;
    final Runnable mStartRecognitionRunnable = new Runnable() {
        public void run() {
            SearchFragment searchFragment = SearchFragment.this;
            searchFragment.mAutoStartRecognition = false;
            searchFragment.mSearchBar.startRecognition();
        }
    };
    int mStatus;
    private String mTitle;

    static class ExternalQuery {
        String mQuery;
        boolean mSubmit;

        ExternalQuery(String str, boolean z) {
            this.mQuery = str;
            this.mSubmit = z;
        }
    }

    public interface SearchResultProvider {
        ObjectAdapter getResultsAdapter();

        boolean onQueryTextChange(String str);

        boolean onQueryTextSubmit(String str);
    }

    static {
        Class cls = SearchFragment.class;
        TAG = cls.getSimpleName();
        ARG_PREFIX = cls.getCanonicalName();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(ARG_PREFIX);
        stringBuilder.append(".query");
        ARG_QUERY = stringBuilder.toString();
        stringBuilder = new StringBuilder();
        stringBuilder.append(ARG_PREFIX);
        stringBuilder.append(".title");
        ARG_TITLE = stringBuilder.toString();
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        if (i == 0 && strArr.length > 0 && strArr[0].equals("android.permission.RECORD_AUDIO") != null && iArr[0] == 0) {
            startRecognition();
        }
    }

    public static Bundle createArgs(Bundle bundle, String str) {
        return createArgs(bundle, str, null);
    }

    public static Bundle createArgs(Bundle bundle, String str, String str2) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        bundle.putString(ARG_QUERY, str);
        bundle.putString(ARG_TITLE, str2);
        return bundle;
    }

    public static SearchFragment newInstance(String str) {
        SearchFragment searchFragment = new SearchFragment();
        searchFragment.setArguments(createArgs(null, str));
        return searchFragment;
    }

    public void onCreate(Bundle bundle) {
        if (this.mAutoStartRecognition) {
            this.mAutoStartRecognition = bundle == null;
        }
        super.onCreate(bundle);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        layoutInflater = layoutInflater.inflate(R.layout.lb_search_fragment, viewGroup, false);
        this.mSearchBar = (SearchBar) ((FrameLayout) layoutInflater.findViewById(R.id.lb_search_frame)).findViewById(R.id.lb_search_bar);
        this.mSearchBar.setSearchBarListener(new SearchBarListener() {
            public void onSearchQueryChange(String str) {
                if (SearchFragment.this.mProvider != null) {
                    SearchFragment.this.retrieveResults(str);
                } else {
                    SearchFragment.this.mPendingQuery = str;
                }
            }

            public void onSearchQuerySubmit(String str) {
                SearchFragment.this.submitQuery(str);
            }

            public void onKeyboardDismiss(String str) {
                SearchFragment.this.queryComplete();
            }
        });
        this.mSearchBar.setSpeechRecognitionCallback(this.mSpeechRecognitionCallback);
        this.mSearchBar.setPermissionListener(this.mPermissionListener);
        applyExternalQuery();
        readArguments(getArguments());
        viewGroup = this.mBadgeDrawable;
        if (viewGroup != null) {
            setBadgeDrawable(viewGroup);
        }
        viewGroup = this.mTitle;
        if (viewGroup != null) {
            setTitle(viewGroup);
        }
        if (getChildFragmentManager().findFragmentById(R.id.lb_results_frame) == null) {
            this.mRowsFragment = new RowsFragment();
            getChildFragmentManager().beginTransaction().replace(R.id.lb_results_frame, this.mRowsFragment).commit();
        } else {
            this.mRowsFragment = (RowsFragment) getChildFragmentManager().findFragmentById(R.id.lb_results_frame);
        }
        this.mRowsFragment.setOnItemViewSelectedListener(new OnItemViewSelectedListener() {
            public void onItemSelected(ViewHolder viewHolder, Object obj, RowPresenter.ViewHolder viewHolder2, Row row) {
                SearchFragment.this.updateSearchBarVisibility();
                if (SearchFragment.this.mOnItemViewSelectedListener != null) {
                    SearchFragment.this.mOnItemViewSelectedListener.onItemSelected(viewHolder, obj, viewHolder2, row);
                }
            }
        });
        this.mRowsFragment.setOnItemViewClickedListener(this.mOnItemViewClickedListener);
        this.mRowsFragment.setExpand(true);
        if (this.mProvider != null) {
            onSetSearchResultProvider();
        }
        return layoutInflater;
    }

    private void resultsAvailable() {
        if ((this.mStatus & 2) != 0) {
            focusOnResults();
        }
        updateSearchBarNextFocusId();
    }

    public void onStart() {
        super.onStart();
        VerticalGridView verticalGridView = this.mRowsFragment.getVerticalGridView();
        int dimensionPixelSize = getResources().getDimensionPixelSize(R.dimen.lb_search_browse_rows_align_top);
        verticalGridView.setItemAlignmentOffset(0);
        verticalGridView.setItemAlignmentOffsetPercent(-1.0f);
        verticalGridView.setWindowAlignmentOffset(dimensionPixelSize);
        verticalGridView.setWindowAlignmentOffsetPercent(-1.0f);
        verticalGridView.setWindowAlignment(0);
        verticalGridView.setFocusable(false);
        verticalGridView.setFocusableInTouchMode(false);
    }

    public void onResume() {
        super.onResume();
        this.mIsPaused = false;
        if (this.mSpeechRecognitionCallback == null && this.mSpeechRecognizer == null) {
            this.mSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(FragmentUtil.getContext(this));
            this.mSearchBar.setSpeechRecognizer(this.mSpeechRecognizer);
        }
        if (this.mPendingStartRecognitionWhenPaused) {
            this.mPendingStartRecognitionWhenPaused = false;
            this.mSearchBar.startRecognition();
            return;
        }
        this.mSearchBar.stopRecognition();
    }

    public void onPause() {
        releaseRecognizer();
        this.mIsPaused = true;
        super.onPause();
    }

    public void onDestroy() {
        releaseAdapter();
        super.onDestroy();
    }

    public RowsFragment getRowsFragment() {
        return this.mRowsFragment;
    }

    private void releaseRecognizer() {
        if (this.mSpeechRecognizer != null) {
            this.mSearchBar.setSpeechRecognizer(null);
            this.mSpeechRecognizer.destroy();
            this.mSpeechRecognizer = null;
        }
    }

    public void startRecognition() {
        if (this.mIsPaused) {
            this.mPendingStartRecognitionWhenPaused = true;
        } else {
            this.mSearchBar.startRecognition();
        }
    }

    public void setSearchResultProvider(SearchResultProvider searchResultProvider) {
        if (this.mProvider != searchResultProvider) {
            this.mProvider = searchResultProvider;
            onSetSearchResultProvider();
        }
    }

    public void setOnItemViewSelectedListener(OnItemViewSelectedListener onItemViewSelectedListener) {
        this.mOnItemViewSelectedListener = onItemViewSelectedListener;
    }

    public void setOnItemViewClickedListener(OnItemViewClickedListener onItemViewClickedListener) {
        if (onItemViewClickedListener != this.mOnItemViewClickedListener) {
            this.mOnItemViewClickedListener = onItemViewClickedListener;
            onItemViewClickedListener = this.mRowsFragment;
            if (onItemViewClickedListener != null) {
                onItemViewClickedListener.setOnItemViewClickedListener(this.mOnItemViewClickedListener);
            }
        }
    }

    public void setTitle(String str) {
        this.mTitle = str;
        SearchBar searchBar = this.mSearchBar;
        if (searchBar != null) {
            searchBar.setTitle(str);
        }
    }

    public String getTitle() {
        SearchBar searchBar = this.mSearchBar;
        return searchBar != null ? searchBar.getTitle() : null;
    }

    public void setBadgeDrawable(Drawable drawable) {
        this.mBadgeDrawable = drawable;
        SearchBar searchBar = this.mSearchBar;
        if (searchBar != null) {
            searchBar.setBadgeDrawable(drawable);
        }
    }

    public Drawable getBadgeDrawable() {
        SearchBar searchBar = this.mSearchBar;
        return searchBar != null ? searchBar.getBadgeDrawable() : null;
    }

    public void setSearchAffordanceColors(Colors colors) {
        SearchBar searchBar = this.mSearchBar;
        if (searchBar != null) {
            searchBar.setSearchAffordanceColors(colors);
        }
    }

    public void setSearchAffordanceColorsInListening(Colors colors) {
        SearchBar searchBar = this.mSearchBar;
        if (searchBar != null) {
            searchBar.setSearchAffordanceColorsInListening(colors);
        }
    }

    public void displayCompletions(List<String> list) {
        this.mSearchBar.displayCompletions((List) list);
    }

    public void displayCompletions(CompletionInfo[] completionInfoArr) {
        this.mSearchBar.displayCompletions(completionInfoArr);
    }

    @Deprecated
    public void setSpeechRecognitionCallback(SpeechRecognitionCallback speechRecognitionCallback) {
        this.mSpeechRecognitionCallback = speechRecognitionCallback;
        SearchBar searchBar = this.mSearchBar;
        if (searchBar != null) {
            searchBar.setSpeechRecognitionCallback(this.mSpeechRecognitionCallback);
        }
        if (speechRecognitionCallback != null) {
            releaseRecognizer();
        }
    }

    public void setSearchQuery(String str, boolean z) {
        if (str != null) {
            this.mExternalQuery = new ExternalQuery(str, z);
            applyExternalQuery();
            if (this.mAutoStartRecognition != null) {
                this.mAutoStartRecognition = null;
                this.mHandler.removeCallbacks(this.mStartRecognitionRunnable);
            }
        }
    }

    public void setSearchQuery(Intent intent, boolean z) {
        intent = intent.getStringArrayListExtra("android.speech.extra.RESULTS");
        if (intent != null && intent.size() > 0) {
            setSearchQuery((String) intent.get(0), z);
        }
    }

    public Intent getRecognizerIntent() {
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        boolean z = true;
        intent.putExtra("android.speech.extra.PARTIAL_RESULTS", true);
        SearchBar searchBar = this.mSearchBar;
        if (!(searchBar == null || searchBar.getHint() == null)) {
            intent.putExtra("android.speech.extra.PROMPT", this.mSearchBar.getHint());
        }
        if (this.mBadgeDrawable == null) {
            z = false;
        }
        intent.putExtra(EXTRA_LEANBACK_BADGE_PRESENT, z);
        return intent;
    }

    void retrieveResults(String str) {
        if (this.mProvider.onQueryTextChange(str) != null) {
            this.mStatus &= -3;
        }
    }

    void submitQuery(String str) {
        queryComplete();
        SearchResultProvider searchResultProvider = this.mProvider;
        if (searchResultProvider != null) {
            searchResultProvider.onQueryTextSubmit(str);
        }
    }

    void queryComplete() {
        this.mStatus |= 2;
        focusOnResults();
    }

    void updateSearchBarVisibility() {
        RowsFragment rowsFragment = this.mRowsFragment;
        int selectedPosition = rowsFragment != null ? rowsFragment.getSelectedPosition() : -1;
        SearchBar searchBar = this.mSearchBar;
        if (selectedPosition > 0) {
            ObjectAdapter objectAdapter = this.mResultAdapter;
            if (objectAdapter != null) {
                if (objectAdapter.size() != 0) {
                    selectedPosition = 8;
                    searchBar.setVisibility(selectedPosition);
                }
            }
        }
        selectedPosition = 0;
        searchBar.setVisibility(selectedPosition);
    }

    void updateSearchBarNextFocusId() {
        if (this.mSearchBar != null) {
            ObjectAdapter objectAdapter = this.mResultAdapter;
            if (objectAdapter != null) {
                int id;
                if (objectAdapter.size() != 0) {
                    RowsFragment rowsFragment = this.mRowsFragment;
                    if (rowsFragment != null) {
                        if (rowsFragment.getVerticalGridView() != null) {
                            id = this.mRowsFragment.getVerticalGridView().getId();
                            this.mSearchBar.setNextFocusDownId(id);
                        }
                    }
                }
                id = 0;
                this.mSearchBar.setNextFocusDownId(id);
            }
        }
    }

    void updateFocus() {
        ObjectAdapter objectAdapter = this.mResultAdapter;
        if (objectAdapter != null && objectAdapter.size() > 0) {
            RowsFragment rowsFragment = this.mRowsFragment;
            if (rowsFragment != null && rowsFragment.getAdapter() == this.mResultAdapter) {
                focusOnResults();
                return;
            }
        }
        this.mSearchBar.requestFocus();
    }

    private void focusOnResults() {
        RowsFragment rowsFragment = this.mRowsFragment;
        if (rowsFragment != null && rowsFragment.getVerticalGridView() != null) {
            if (this.mResultAdapter.size() != 0) {
                if (this.mRowsFragment.getVerticalGridView().requestFocus()) {
                    this.mStatus &= -2;
                }
            }
        }
    }

    private void onSetSearchResultProvider() {
        this.mHandler.removeCallbacks(this.mSetSearchResultProvider);
        this.mHandler.post(this.mSetSearchResultProvider);
    }

    void releaseAdapter() {
        ObjectAdapter objectAdapter = this.mResultAdapter;
        if (objectAdapter != null) {
            objectAdapter.unregisterObserver(this.mAdapterObserver);
            this.mResultAdapter = null;
        }
    }

    void executePendingQuery() {
        String str = this.mPendingQuery;
        if (str != null && this.mResultAdapter != null) {
            this.mPendingQuery = null;
            retrieveResults(str);
        }
    }

    private void applyExternalQuery() {
        ExternalQuery externalQuery = this.mExternalQuery;
        if (externalQuery != null) {
            SearchBar searchBar = this.mSearchBar;
            if (searchBar != null) {
                searchBar.setSearchQuery(externalQuery.mQuery);
                if (this.mExternalQuery.mSubmit) {
                    submitQuery(this.mExternalQuery.mQuery);
                }
                this.mExternalQuery = null;
            }
        }
    }

    private void readArguments(Bundle bundle) {
        if (bundle != null) {
            if (bundle.containsKey(ARG_QUERY)) {
                setSearchQuery(bundle.getString(ARG_QUERY));
            }
            if (bundle.containsKey(ARG_TITLE)) {
                setTitle(bundle.getString(ARG_TITLE));
            }
        }
    }

    private void setSearchQuery(String str) {
        this.mSearchBar.setSearchQuery(str);
    }
}
