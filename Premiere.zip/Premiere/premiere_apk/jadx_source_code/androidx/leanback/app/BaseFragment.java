package androidx.leanback.app;

import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver.OnPreDrawListener;
import androidx.leanback.transition.TransitionHelper;
import androidx.leanback.transition.TransitionListener;
import androidx.leanback.util.StateMachine;
import androidx.leanback.util.StateMachine.Condition;
import androidx.leanback.util.StateMachine.Event;
import androidx.leanback.util.StateMachine.State;

@Deprecated
public class BaseFragment extends BrandedFragment {
    final Condition COND_TRANSITION_NOT_SUPPORTED = new Condition("EntranceTransitionNotSupport") {
        public boolean canProceed() {
            return TransitionHelper.systemSupportsEntranceTransitions() ^ 1;
        }
    };
    final Event EVT_ENTRANCE_END = new Event("onEntranceTransitionEnd");
    final Event EVT_ON_CREATE = new Event("onCreate");
    final Event EVT_ON_CREATEVIEW = new Event("onCreateView");
    final Event EVT_PREPARE_ENTRANCE = new Event("prepareEntranceTransition");
    final Event EVT_START_ENTRANCE = new Event("startEntranceTransition");
    final State STATE_ENTRANCE_COMPLETE = new State("ENTRANCE_COMPLETE", true, false);
    final State STATE_ENTRANCE_INIT = new State("ENTRANCE_INIT");
    final State STATE_ENTRANCE_ON_ENDED = new State("ENTRANCE_ON_ENDED") {
        public void run() {
            BaseFragment.this.onEntranceTransitionEnd();
        }
    };
    final State STATE_ENTRANCE_ON_PREPARED = new State("ENTRANCE_ON_PREPARED", true, false) {
        public void run() {
            BaseFragment.this.mProgressBarManager.show();
        }
    };
    final State STATE_ENTRANCE_ON_PREPARED_ON_CREATEVIEW = new State("ENTRANCE_ON_PREPARED_ON_CREATEVIEW") {
        public void run() {
            BaseFragment.this.onEntranceTransitionPrepare();
        }
    };
    final State STATE_ENTRANCE_PERFORM = new State("STATE_ENTRANCE_PERFORM") {
        public void run() {
            BaseFragment.this.mProgressBarManager.hide();
            BaseFragment.this.onExecuteEntranceTransition();
        }
    };
    final State STATE_START = new State("START", true, false);
    Object mEntranceTransition;
    final ProgressBarManager mProgressBarManager = new ProgressBarManager();
    final StateMachine mStateMachine = new StateMachine();

    protected Object createEntranceTransition() {
        return null;
    }

    protected void onEntranceTransitionEnd() {
    }

    protected void onEntranceTransitionPrepare() {
    }

    protected void onEntranceTransitionStart() {
    }

    protected void runEntranceTransition(Object obj) {
    }

    BaseFragment() {
    }

    public void onCreate(Bundle bundle) {
        createStateMachineStates();
        createStateMachineTransitions();
        this.mStateMachine.start();
        super.onCreate(bundle);
        this.mStateMachine.fireEvent(this.EVT_ON_CREATE);
    }

    void createStateMachineStates() {
        this.mStateMachine.addState(this.STATE_START);
        this.mStateMachine.addState(this.STATE_ENTRANCE_INIT);
        this.mStateMachine.addState(this.STATE_ENTRANCE_ON_PREPARED);
        this.mStateMachine.addState(this.STATE_ENTRANCE_ON_PREPARED_ON_CREATEVIEW);
        this.mStateMachine.addState(this.STATE_ENTRANCE_PERFORM);
        this.mStateMachine.addState(this.STATE_ENTRANCE_ON_ENDED);
        this.mStateMachine.addState(this.STATE_ENTRANCE_COMPLETE);
    }

    void createStateMachineTransitions() {
        this.mStateMachine.addTransition(this.STATE_START, this.STATE_ENTRANCE_INIT, this.EVT_ON_CREATE);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_INIT, this.STATE_ENTRANCE_COMPLETE, this.COND_TRANSITION_NOT_SUPPORTED);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_INIT, this.STATE_ENTRANCE_COMPLETE, this.EVT_ON_CREATEVIEW);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_INIT, this.STATE_ENTRANCE_ON_PREPARED, this.EVT_PREPARE_ENTRANCE);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_PREPARED, this.STATE_ENTRANCE_ON_PREPARED_ON_CREATEVIEW, this.EVT_ON_CREATEVIEW);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_PREPARED, this.STATE_ENTRANCE_PERFORM, this.EVT_START_ENTRANCE);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_PREPARED_ON_CREATEVIEW, this.STATE_ENTRANCE_PERFORM);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_PERFORM, this.STATE_ENTRANCE_ON_ENDED, this.EVT_ENTRANCE_END);
        this.mStateMachine.addTransition(this.STATE_ENTRANCE_ON_ENDED, this.STATE_ENTRANCE_COMPLETE);
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        this.mStateMachine.fireEvent(this.EVT_ON_CREATEVIEW);
    }

    public void prepareEntranceTransition() {
        this.mStateMachine.fireEvent(this.EVT_PREPARE_ENTRANCE);
    }

    public void startEntranceTransition() {
        this.mStateMachine.fireEvent(this.EVT_START_ENTRANCE);
    }

    void onExecuteEntranceTransition() {
        final View view = getView();
        if (view != null) {
            view.getViewTreeObserver().addOnPreDrawListener(new OnPreDrawListener() {
                public boolean onPreDraw() {
                    view.getViewTreeObserver().removeOnPreDrawListener(this);
                    if (FragmentUtil.getContext(BaseFragment.this) != null) {
                        if (BaseFragment.this.getView() != null) {
                            BaseFragment.this.internalCreateEntranceTransition();
                            BaseFragment.this.onEntranceTransitionStart();
                            if (BaseFragment.this.mEntranceTransition != null) {
                                BaseFragment baseFragment = BaseFragment.this;
                                baseFragment.runEntranceTransition(baseFragment.mEntranceTransition);
                            } else {
                                BaseFragment.this.mStateMachine.fireEvent(BaseFragment.this.EVT_ENTRANCE_END);
                            }
                            return false;
                        }
                    }
                    return true;
                }
            });
            view.invalidate();
        }
    }

    void internalCreateEntranceTransition() {
        this.mEntranceTransition = createEntranceTransition();
        Object obj = this.mEntranceTransition;
        if (obj != null) {
            TransitionHelper.addTransitionListener(obj, new TransitionListener() {
                public void onTransitionEnd(Object obj) {
                    obj = BaseFragment.this;
                    obj.mEntranceTransition = null;
                    obj.mStateMachine.fireEvent(BaseFragment.this.EVT_ENTRANCE_END);
                }
            });
        }
    }

    public final ProgressBarManager getProgressBarManager() {
        return this.mProgressBarManager;
    }
}
