package androidx.leanback.app;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Property;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.core.view.GravityCompat;
import androidx.leanback.R;
import androidx.leanback.widget.PagingIndicator;
import java.util.ArrayList;
import java.util.Collection;

@Deprecated
public abstract class OnboardingFragment extends Fragment {
    private static final boolean DEBUG = false;
    private static final long DESCRIPTION_START_DELAY_MS = 33;
    private static final long HEADER_ANIMATION_DURATION_MS = 417;
    private static final long HEADER_APPEAR_DELAY_MS = 500;
    private static final TimeInterpolator HEADER_APPEAR_INTERPOLATOR = new DecelerateInterpolator();
    private static final TimeInterpolator HEADER_DISAPPEAR_INTERPOLATOR = new AccelerateInterpolator();
    private static final String KEY_CURRENT_PAGE_INDEX = "leanback.onboarding.current_page_index";
    private static final String KEY_ENTER_ANIMATION_FINISHED = "leanback.onboarding.enter_animation_finished";
    private static final String KEY_LOGO_ANIMATION_FINISHED = "leanback.onboarding.logo_animation_finished";
    private static final long LOGO_SPLASH_PAUSE_DURATION_MS = 1333;
    private static final int SLIDE_DISTANCE = 60;
    private static final String TAG = "OnboardingF";
    private static int sSlideDistance;
    private AnimatorSet mAnimator;
    private int mArrowBackgroundColor = 0;
    private boolean mArrowBackgroundColorSet;
    private int mArrowColor = 0;
    private boolean mArrowColorSet;
    int mCurrentPageIndex;
    TextView mDescriptionView;
    private int mDescriptionViewTextColor = 0;
    private boolean mDescriptionViewTextColorSet;
    private int mDotBackgroundColor = 0;
    private boolean mDotBackgroundColorSet;
    boolean mEnterAnimationFinished;
    private int mIconResourceId;
    boolean mIsLtr;
    boolean mLogoAnimationFinished;
    private int mLogoResourceId;
    private ImageView mLogoView;
    private ImageView mMainIconView;
    private final OnClickListener mOnClickListener = new OnClickListener() {
        public void onClick(View view) {
            if (OnboardingFragment.this.mLogoAnimationFinished != null) {
                if (OnboardingFragment.this.mCurrentPageIndex == OnboardingFragment.this.getPageCount() - 1) {
                    OnboardingFragment.this.onFinishFragment();
                } else {
                    OnboardingFragment.this.moveToNextPage();
                }
            }
        }
    };
    private final OnKeyListener mOnKeyListener = new OnKeyListener() {
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            boolean z = true;
            if (OnboardingFragment.this.mLogoAnimationFinished == null) {
                if (i == 4) {
                    z = false;
                }
                return z;
            } else if (keyEvent.getAction() == null) {
                return false;
            } else {
                if (i != 4) {
                    if (i == 21) {
                        if (OnboardingFragment.this.mIsLtr != null) {
                            OnboardingFragment.this.moveToPreviousPage();
                        } else {
                            OnboardingFragment.this.moveToNextPage();
                        }
                        return true;
                    } else if (i != 22) {
                        return false;
                    } else {
                        if (OnboardingFragment.this.mIsLtr != null) {
                            OnboardingFragment.this.moveToNextPage();
                        } else {
                            OnboardingFragment.this.moveToPreviousPage();
                        }
                        return true;
                    }
                } else if (OnboardingFragment.this.mCurrentPageIndex == null) {
                    return false;
                } else {
                    OnboardingFragment.this.moveToPreviousPage();
                    return true;
                }
            }
        }
    };
    PagingIndicator mPageIndicator;
    View mStartButton;
    private CharSequence mStartButtonText;
    private boolean mStartButtonTextSet;
    private ContextThemeWrapper mThemeWrapper;
    TextView mTitleView;
    private int mTitleViewTextColor = 0;
    private boolean mTitleViewTextColorSet;

    protected abstract int getPageCount();

    protected abstract CharSequence getPageDescription(int i);

    protected abstract CharSequence getPageTitle(int i);

    protected abstract View onCreateBackgroundView(LayoutInflater layoutInflater, ViewGroup viewGroup);

    protected abstract View onCreateContentView(LayoutInflater layoutInflater, ViewGroup viewGroup);

    protected Animator onCreateEnterAnimation() {
        return null;
    }

    protected abstract View onCreateForegroundView(LayoutInflater layoutInflater, ViewGroup viewGroup);

    protected Animator onCreateLogoAnimation() {
        return null;
    }

    protected void onFinishFragment() {
    }

    protected void onPageChanged(int i, int i2) {
    }

    public int onProvideTheme() {
        return -1;
    }

    protected void moveToPreviousPage() {
        if (this.mLogoAnimationFinished) {
            int i = this.mCurrentPageIndex;
            if (i > 0) {
                this.mCurrentPageIndex = i - 1;
                onPageChangedInternal(this.mCurrentPageIndex + 1);
            }
        }
    }

    protected void moveToNextPage() {
        if (this.mLogoAnimationFinished && this.mCurrentPageIndex < getPageCount() - 1) {
            this.mCurrentPageIndex++;
            onPageChangedInternal(this.mCurrentPageIndex - 1);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        resolveTheme();
        boolean z = false;
        ViewGroup viewGroup2 = (ViewGroup) getThemeInflater(layoutInflater).inflate(R.layout.lb_onboarding_fragment, viewGroup, false);
        if (getResources().getConfiguration().getLayoutDirection() == null) {
            z = true;
        }
        this.mIsLtr = z;
        this.mPageIndicator = (PagingIndicator) viewGroup2.findViewById(R.id.page_indicator);
        this.mPageIndicator.setOnClickListener(this.mOnClickListener);
        this.mPageIndicator.setOnKeyListener(this.mOnKeyListener);
        this.mStartButton = viewGroup2.findViewById(R.id.button_start);
        this.mStartButton.setOnClickListener(this.mOnClickListener);
        this.mStartButton.setOnKeyListener(this.mOnKeyListener);
        this.mMainIconView = (ImageView) viewGroup2.findViewById(R.id.main_icon);
        this.mLogoView = (ImageView) viewGroup2.findViewById(R.id.logo);
        this.mTitleView = (TextView) viewGroup2.findViewById(R.id.title);
        this.mDescriptionView = (TextView) viewGroup2.findViewById(R.id.description);
        if (this.mTitleViewTextColorSet != null) {
            this.mTitleView.setTextColor(this.mTitleViewTextColor);
        }
        if (this.mDescriptionViewTextColorSet != null) {
            this.mDescriptionView.setTextColor(this.mDescriptionViewTextColor);
        }
        if (this.mDotBackgroundColorSet != null) {
            this.mPageIndicator.setDotBackgroundColor(this.mDotBackgroundColor);
        }
        if (this.mArrowColorSet != null) {
            this.mPageIndicator.setArrowColor(this.mArrowColor);
        }
        if (this.mArrowBackgroundColorSet != null) {
            this.mPageIndicator.setDotBackgroundColor(this.mArrowBackgroundColor);
        }
        if (this.mStartButtonTextSet != null) {
            ((Button) this.mStartButton).setText(this.mStartButtonText);
        }
        viewGroup = FragmentUtil.getContext(this);
        if (sSlideDistance == null) {
            sSlideDistance = (int) (viewGroup.getResources().getDisplayMetrics().scaledDensity * 1114636288);
        }
        viewGroup2.requestFocus();
        return viewGroup2;
    }

    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (bundle == null) {
            this.mCurrentPageIndex = 0;
            this.mLogoAnimationFinished = false;
            this.mEnterAnimationFinished = false;
            this.mPageIndicator.onPageSelected(0, false);
            view.getViewTreeObserver().addOnPreDrawListener(new OnPreDrawListener() {
                public boolean onPreDraw() {
                    OnboardingFragment.this.getView().getViewTreeObserver().removeOnPreDrawListener(this);
                    if (!OnboardingFragment.this.startLogoAnimation()) {
                        OnboardingFragment onboardingFragment = OnboardingFragment.this;
                        onboardingFragment.mLogoAnimationFinished = true;
                        onboardingFragment.onLogoAnimationFinished();
                    }
                    return true;
                }
            });
            return;
        }
        this.mCurrentPageIndex = bundle.getInt(KEY_CURRENT_PAGE_INDEX);
        this.mLogoAnimationFinished = bundle.getBoolean(KEY_LOGO_ANIMATION_FINISHED);
        this.mEnterAnimationFinished = bundle.getBoolean(KEY_ENTER_ANIMATION_FINISHED);
        if (this.mLogoAnimationFinished != null) {
            onLogoAnimationFinished();
        } else if (startLogoAnimation() == null) {
            this.mLogoAnimationFinished = true;
            onLogoAnimationFinished();
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(KEY_CURRENT_PAGE_INDEX, this.mCurrentPageIndex);
        bundle.putBoolean(KEY_LOGO_ANIMATION_FINISHED, this.mLogoAnimationFinished);
        bundle.putBoolean(KEY_ENTER_ANIMATION_FINISHED, this.mEnterAnimationFinished);
    }

    public void setTitleViewTextColor(int i) {
        this.mTitleViewTextColor = i;
        this.mTitleViewTextColorSet = true;
        TextView textView = this.mTitleView;
        if (textView != null) {
            textView.setTextColor(i);
        }
    }

    public final int getTitleViewTextColor() {
        return this.mTitleViewTextColor;
    }

    public void setDescriptionViewTextColor(int i) {
        this.mDescriptionViewTextColor = i;
        this.mDescriptionViewTextColorSet = true;
        TextView textView = this.mDescriptionView;
        if (textView != null) {
            textView.setTextColor(i);
        }
    }

    public final int getDescriptionViewTextColor() {
        return this.mDescriptionViewTextColor;
    }

    public void setDotBackgroundColor(int i) {
        this.mDotBackgroundColor = i;
        this.mDotBackgroundColorSet = true;
        PagingIndicator pagingIndicator = this.mPageIndicator;
        if (pagingIndicator != null) {
            pagingIndicator.setDotBackgroundColor(i);
        }
    }

    public final int getDotBackgroundColor() {
        return this.mDotBackgroundColor;
    }

    public void setArrowColor(int i) {
        this.mArrowColor = i;
        this.mArrowColorSet = true;
        PagingIndicator pagingIndicator = this.mPageIndicator;
        if (pagingIndicator != null) {
            pagingIndicator.setArrowColor(i);
        }
    }

    public final int getArrowColor() {
        return this.mArrowColor;
    }

    public void setArrowBackgroundColor(int i) {
        this.mArrowBackgroundColor = i;
        this.mArrowBackgroundColorSet = true;
        PagingIndicator pagingIndicator = this.mPageIndicator;
        if (pagingIndicator != null) {
            pagingIndicator.setArrowBackgroundColor(i);
        }
    }

    public final int getArrowBackgroundColor() {
        return this.mArrowBackgroundColor;
    }

    public final CharSequence getStartButtonText() {
        return this.mStartButtonText;
    }

    public void setStartButtonText(CharSequence charSequence) {
        this.mStartButtonText = charSequence;
        this.mStartButtonTextSet = true;
        charSequence = this.mStartButton;
        if (charSequence != null) {
            ((Button) charSequence).setText(this.mStartButtonText);
        }
    }

    private void resolveTheme() {
        Context context = FragmentUtil.getContext(this);
        int onProvideTheme = onProvideTheme();
        if (onProvideTheme == -1) {
            onProvideTheme = R.attr.onboardingTheme;
            TypedValue typedValue = new TypedValue();
            if (context.getTheme().resolveAttribute(onProvideTheme, typedValue, true)) {
                this.mThemeWrapper = new ContextThemeWrapper(context, typedValue.resourceId);
                return;
            }
            return;
        }
        this.mThemeWrapper = new ContextThemeWrapper(context, onProvideTheme);
    }

    private LayoutInflater getThemeInflater(LayoutInflater layoutInflater) {
        Context context = this.mThemeWrapper;
        return context == null ? layoutInflater : layoutInflater.cloneInContext(context);
    }

    public final void setLogoResourceId(int i) {
        this.mLogoResourceId = i;
    }

    public final int getLogoResourceId() {
        return this.mLogoResourceId;
    }

    boolean startLogoAnimation() {
        final Context context = FragmentUtil.getContext(this);
        if (context == null) {
            return false;
        }
        Animator animatorSet;
        if (this.mLogoResourceId != 0) {
            this.mLogoView.setVisibility(0);
            this.mLogoView.setImageResource(this.mLogoResourceId);
            Animator loadAnimator = AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_logo_enter);
            AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_logo_exit).setStartDelay(LOGO_SPLASH_PAUSE_DURATION_MS);
            animatorSet = new AnimatorSet();
            animatorSet.playSequentially(new Animator[]{loadAnimator, r4});
            animatorSet.setTarget(this.mLogoView);
        } else {
            animatorSet = onCreateLogoAnimation();
        }
        if (animatorSet == null) {
            return false;
        }
        animatorSet.addListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animator) {
                if (context != null) {
                    animator = OnboardingFragment.this;
                    animator.mLogoAnimationFinished = true;
                    animator.onLogoAnimationFinished();
                }
            }
        });
        animatorSet.start();
        return true;
    }

    void hideLogoView() {
        this.mLogoView.setVisibility(8);
        int i = this.mIconResourceId;
        if (i != 0) {
            this.mMainIconView.setImageResource(i);
            this.mMainIconView.setVisibility(0);
        }
        View view = getView();
        LayoutInflater themeInflater = getThemeInflater(LayoutInflater.from(FragmentUtil.getContext(this)));
        ViewGroup viewGroup = (ViewGroup) view.findViewById(R.id.background_container);
        View onCreateBackgroundView = onCreateBackgroundView(themeInflater, viewGroup);
        if (onCreateBackgroundView != null) {
            viewGroup.setVisibility(0);
            viewGroup.addView(onCreateBackgroundView);
        }
        viewGroup = (ViewGroup) view.findViewById(R.id.content_container);
        onCreateBackgroundView = onCreateContentView(themeInflater, viewGroup);
        if (onCreateBackgroundView != null) {
            viewGroup.setVisibility(0);
            viewGroup.addView(onCreateBackgroundView);
        }
        viewGroup = (ViewGroup) view.findViewById(R.id.foreground_container);
        View onCreateForegroundView = onCreateForegroundView(themeInflater, viewGroup);
        if (onCreateForegroundView != null) {
            viewGroup.setVisibility(0);
            viewGroup.addView(onCreateForegroundView);
        }
        view.findViewById(R.id.page_container).setVisibility(0);
        view.findViewById(R.id.content_container).setVisibility(0);
        if (getPageCount() > 1) {
            this.mPageIndicator.setPageCount(getPageCount());
            this.mPageIndicator.onPageSelected(this.mCurrentPageIndex, false);
        }
        if (this.mCurrentPageIndex == getPageCount() - 1) {
            this.mStartButton.setVisibility(0);
        } else {
            this.mPageIndicator.setVisibility(0);
        }
        this.mTitleView.setText(getPageTitle(this.mCurrentPageIndex));
        this.mDescriptionView.setText(getPageDescription(this.mCurrentPageIndex));
    }

    protected void onLogoAnimationFinished() {
        startEnterAnimation(false);
    }

    protected final void startEnterAnimation(boolean z) {
        Context context = FragmentUtil.getContext(this);
        if (context != null) {
            hideLogoView();
            if (!this.mEnterAnimationFinished || z) {
                z = new ArrayList();
                Animator loadAnimator = AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_page_indicator_enter);
                loadAnimator.setTarget(getPageCount() <= 1 ? this.mStartButton : this.mPageIndicator);
                z.add(loadAnimator);
                loadAnimator = onCreateTitleAnimator();
                if (loadAnimator != null) {
                    loadAnimator.setTarget(this.mTitleView);
                    z.add(loadAnimator);
                }
                loadAnimator = onCreateDescriptionAnimator();
                if (loadAnimator != null) {
                    loadAnimator.setTarget(this.mDescriptionView);
                    z.add(loadAnimator);
                }
                loadAnimator = onCreateEnterAnimation();
                if (loadAnimator != null) {
                    z.add(loadAnimator);
                }
                if (!z.isEmpty()) {
                    this.mAnimator = new AnimatorSet();
                    this.mAnimator.playTogether(z);
                    this.mAnimator.start();
                    this.mAnimator.addListener(new AnimatorListenerAdapter() {
                        public void onAnimationEnd(Animator animator) {
                            OnboardingFragment.this.mEnterAnimationFinished = true;
                        }
                    });
                    getView().requestFocus();
                }
            }
        }
    }

    protected Animator onCreateDescriptionAnimator() {
        return AnimatorInflater.loadAnimator(FragmentUtil.getContext(this), R.animator.lb_onboarding_description_enter);
    }

    protected Animator onCreateTitleAnimator() {
        return AnimatorInflater.loadAnimator(FragmentUtil.getContext(this), R.animator.lb_onboarding_title_enter);
    }

    protected final boolean isLogoAnimationFinished() {
        return this.mLogoAnimationFinished;
    }

    protected final int getCurrentPageIndex() {
        return this.mCurrentPageIndex;
    }

    private void onPageChangedInternal(int i) {
        Animator createAnimator;
        AnimatorSet animatorSet = this.mAnimator;
        if (animatorSet != null) {
            animatorSet.end();
        }
        this.mPageIndicator.onPageSelected(this.mCurrentPageIndex, true);
        Collection arrayList = new ArrayList();
        if (i < getCurrentPageIndex()) {
            arrayList.add(createAnimator(this.mTitleView, false, GravityCompat.START, 0));
            createAnimator = createAnimator(this.mDescriptionView, false, GravityCompat.START, DESCRIPTION_START_DELAY_MS);
            arrayList.add(createAnimator);
            arrayList.add(createAnimator(this.mTitleView, true, GravityCompat.END, HEADER_APPEAR_DELAY_MS));
            arrayList.add(createAnimator(this.mDescriptionView, true, GravityCompat.END, 533));
        } else {
            arrayList.add(createAnimator(this.mTitleView, false, GravityCompat.END, 0));
            createAnimator = createAnimator(this.mDescriptionView, false, GravityCompat.END, DESCRIPTION_START_DELAY_MS);
            arrayList.add(createAnimator);
            arrayList.add(createAnimator(this.mTitleView, true, GravityCompat.START, HEADER_APPEAR_DELAY_MS));
            arrayList.add(createAnimator(this.mDescriptionView, true, GravityCompat.START, 533));
        }
        final int currentPageIndex = getCurrentPageIndex();
        createAnimator.addListener(new AnimatorListenerAdapter() {
            public void onAnimationEnd(Animator animator) {
                OnboardingFragment.this.mTitleView.setText(OnboardingFragment.this.getPageTitle(currentPageIndex));
                OnboardingFragment.this.mDescriptionView.setText(OnboardingFragment.this.getPageDescription(currentPageIndex));
            }
        });
        Context context = FragmentUtil.getContext(this);
        Animator loadAnimator;
        if (getCurrentPageIndex() == getPageCount() - 1) {
            this.mStartButton.setVisibility(0);
            loadAnimator = AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_page_indicator_fade_out);
            loadAnimator.setTarget(this.mPageIndicator);
            loadAnimator.addListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animator) {
                    OnboardingFragment.this.mPageIndicator.setVisibility(8);
                }
            });
            arrayList.add(loadAnimator);
            createAnimator = AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_start_button_fade_in);
            createAnimator.setTarget(this.mStartButton);
            arrayList.add(createAnimator);
        } else if (i == getPageCount() - 1) {
            this.mPageIndicator.setVisibility(0);
            loadAnimator = AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_page_indicator_fade_in);
            loadAnimator.setTarget(this.mPageIndicator);
            arrayList.add(loadAnimator);
            createAnimator = AnimatorInflater.loadAnimator(context, R.animator.lb_onboarding_start_button_fade_out);
            createAnimator.setTarget(this.mStartButton);
            createAnimator.addListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator animator) {
                    OnboardingFragment.this.mStartButton.setVisibility(8);
                }
            });
            arrayList.add(createAnimator);
        }
        this.mAnimator = new AnimatorSet();
        this.mAnimator.playTogether(arrayList);
        this.mAnimator.start();
        onPageChanged(this.mCurrentPageIndex, i);
    }

    private Animator createAnimator(View view, boolean z, int i, long j) {
        Object obj = getView().getLayoutDirection() == 0 ? 1 : null;
        i = ((obj == null || i != GravityCompat.END) && !((obj == null && i == GravityCompat.START) || i == 5)) ? 0 : 1;
        Property property;
        float[] fArr;
        if (z) {
            z = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{0.0f, 1.0f});
            property = View.TRANSLATION_X;
            fArr = new float[2];
            fArr[0] = (float) (i != 0 ? sSlideDistance : -sSlideDistance);
            fArr[1] = 0.0f;
            i = ObjectAnimator.ofFloat(view, property, fArr);
            z.setInterpolator(HEADER_APPEAR_INTERPOLATOR);
            i.setInterpolator(HEADER_APPEAR_INTERPOLATOR);
        } else {
            z = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{1.0f, 0.0f});
            property = View.TRANSLATION_X;
            fArr = new float[2];
            fArr[0] = 0.0f;
            fArr[1] = (float) (i != 0 ? sSlideDistance : -sSlideDistance);
            i = ObjectAnimator.ofFloat(view, property, fArr);
            z.setInterpolator(HEADER_DISAPPEAR_INTERPOLATOR);
            i.setInterpolator(HEADER_DISAPPEAR_INTERPOLATOR);
        }
        z.setDuration(HEADER_ANIMATION_DURATION_MS);
        z.setTarget(view);
        i.setDuration(HEADER_ANIMATION_DURATION_MS);
        i.setTarget(view);
        view = new AnimatorSet();
        view.playTogether(new Animator[]{z, i});
        if (j > false) {
            view.setStartDelay(j);
        }
        return view;
    }

    public final void setIconResouceId(int i) {
        this.mIconResourceId = i;
        ImageView imageView = this.mMainIconView;
        if (imageView != null) {
            imageView.setImageResource(i);
            this.mMainIconView.setVisibility(0);
        }
    }

    public final int getIconResourceId() {
        return this.mIconResourceId;
    }
}
